#!/usr/bin/env python3
"""
Step 1 - Dataset inspection and leakage-free preprocessing setup for KNN
(VANET Sybil attack detection, comparable with the Random Forest experiment).

What this script DOES
  * loads two_bsm_clean.csv and validates schema / labels / folds
  * writes an inspection summary, feature manifest, raw eligible features,
    metadata (fold, label, ids, duplicate flags) and a preprocessing config
  * provides reusable functions to fit StandardScaler on each fold's TRAINING
    partition only, and to apply it to that fold's test partition
  * runs automated leakage / consistency assertions

What this script does NOT do
  * train, tune or evaluate KNN
  * resample anything
  * delete duplicate rows (it only FLAGS them; see DUPLICATE_MODE)

Usage
  python knn_preprocessing.py --input two_bsm_clean.csv --outdir knn_step1_outputs
  # in Step 2:
  #   from knn_preprocessing import load_prepared, iter_fold_data
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler

# --------------------------------------------------------------------------
# Configuration (all decisions are explicit here)
# --------------------------------------------------------------------------
TARGET = "label"                       # 0 = Genuine, 1 = Attack
FOLD_COL = "fold"                      # predefined fold id found in the raw file
EXCLUDE_FROM_FEATURES = ["label", "attack_type", "reported_id"]  # per project spec
NON_FEATURE_COLS = EXCLUDE_FROM_FEATURES + [FOLD_COL]            # fold is never an input
EXPECTED_N_FEATURES = 60
EXPECTED_FOLDS = [0, 1, 2, 3, 4]
LABEL_MEANING = {0: "Genuine", 1: "Attack"}

# Duplicate handling is NOT decided here. Two modes are supported downstream:
#   "raw"            -> use all rows exactly as in the CSV (9,049 rows)
#   "rf_reconstructed" -> drop rows that duplicate an earlier row on the 60
#                         features (keep first).  This reproduces the previously
#                         reported 8,931 / 8,784 / 147 counts, but it is an
#                         INFERENCE until confirmed against the RF pipeline.
DUPLICATE_MODES = ("raw", "rf_reconstructed")

# Sentinel: columns containing the value -20 as an apparent "not available /
# not computable" code.  Reported only; values are NOT altered.
SENTINEL_VALUE = -20.0


# --------------------------------------------------------------------------
# Loading and validation
# --------------------------------------------------------------------------
def load_raw(path: str | Path) -> pd.DataFrame:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(path)
    df = pd.read_csv(path)
    df.insert(0, "row_id", np.arange(len(df)))  # stable id = original row order
    return df


def get_feature_columns(df: pd.DataFrame) -> list[str]:
    missing = [c for c in [TARGET, FOLD_COL] if c not in df.columns]
    if missing:
        raise KeyError(f"Required columns missing: {missing}")
    feats = [c for c in df.columns if c not in NON_FEATURE_COLS and c != "row_id"]
    return feats


def validate_raw(df: pd.DataFrame, feats: list[str]) -> None:
    # target
    assert set(df[TARGET].unique()) <= set(LABEL_MEANING), "Unexpected label values"
    # label <-> attack_type consistency (Genuine <=> label 0)
    if "attack_type" in df.columns:
        assert (df.loc[df[TARGET] == 0, "attack_type"] == "Genuine").all()
        assert (df.loc[df[TARGET] == 1, "attack_type"] != "Genuine").all()
    # features
    assert len(feats) == EXPECTED_N_FEATURES, f"{len(feats)} features, expected {EXPECTED_N_FEATURES}"
    for c in NON_FEATURE_COLS:
        assert c not in feats, f"{c} leaked into feature list"
    non_numeric = [c for c in feats if not pd.api.types.is_numeric_dtype(df[c])]
    assert not non_numeric, f"Non-numeric features: {non_numeric}"
    X = df[feats]
    assert not X.isna().any().any(), "Missing values in features"
    assert np.isfinite(X.to_numpy(dtype=float)).all(), "Non-finite values in features"
    # folds
    assert sorted(df[FOLD_COL].unique()) == EXPECTED_FOLDS, "Unexpected fold ids"
    assert df[FOLD_COL].notna().all()


def duplicate_flags(df: pd.DataFrame, feats: list[str]) -> pd.DataFrame:
    """Flag (do not drop) rows whose 60-feature vector repeats."""
    out = pd.DataFrame({"row_id": df["row_id"].to_numpy()})
    out["is_feature_duplicate_of_earlier"] = df.duplicated(subset=feats, keep="first").to_numpy()
    out["in_duplicate_group"] = df.duplicated(subset=feats, keep=False).to_numpy()
    return out


# --------------------------------------------------------------------------
# Prepared-data container (raw features + meta kept separately)
# --------------------------------------------------------------------------
def split_features_meta(df: pd.DataFrame, feats: list[str]):
    X = df[["row_id"] + feats].copy()
    meta_cols = ["row_id", FOLD_COL, TARGET, "reported_id", "attack_type"]
    meta = df[meta_cols].copy()
    meta = meta.merge(duplicate_flags(df, feats), on="row_id")
    return X, meta


def load_prepared(outdir: str | Path, duplicate_mode: str = "raw"):
    """Reload saved artifacts for Step 2. Returns X (60 raw features), y, fold, meta."""
    assert duplicate_mode in DUPLICATE_MODES
    outdir = Path(outdir)
    X = pd.read_csv(outdir / "knn_features_raw.csv")
    meta = pd.read_csv(outdir / "knn_meta.csv")
    assert (X["row_id"].to_numpy() == meta["row_id"].to_numpy()).all()
    if duplicate_mode == "rf_reconstructed":
        keep = ~meta["is_feature_duplicate_of_earlier"].to_numpy()
        X, meta = X[keep].reset_index(drop=True), meta[keep].reset_index(drop=True)
    feats = [c for c in X.columns if c != "row_id"]
    return X[feats], meta[TARGET].to_numpy(), meta[FOLD_COL].to_numpy(), meta


# --------------------------------------------------------------------------
# Preprocessing (fitted per fold, on training partition only)
# --------------------------------------------------------------------------
def make_preprocessor(feature_names: list[str]) -> ColumnTransformer:
    """
    All 60 eligible features are numeric with no missing/non-finite values, so no
    imputer and no categorical encoder is needed. StandardScaler is applied to
    every feature. remainder='drop' guarantees nothing else can pass through.
    """
    pre = ColumnTransformer(
        transformers=[("num", StandardScaler(), list(feature_names))],
        remainder="drop",
        verbose_feature_names_out=False,
    )
    pre.set_output(transform="pandas")
    return pre


def iter_fold_data(X: pd.DataFrame, y: np.ndarray, fold: np.ndarray):
    """
    Yield (k, X_train_scaled, X_test_scaled, y_train, y_test, fitted_preprocessor).
    Test set = rows whose predefined fold == k; train = all other rows.
    The scaler is fitted on X_train ONLY.  No resampling is applied.
    """
    feats = list(X.columns)
    for k in sorted(np.unique(fold)):
        te = fold == k
        tr = ~te
        pre = make_preprocessor(feats)
        Xtr = pre.fit_transform(X.loc[tr])          # fit on training partition only
        Xte = pre.transform(X.loc[te])              # transform only, no refit
        yield int(k), Xtr, Xte, y[tr], y[te], pre


def fold_class_table(y: np.ndarray, fold: np.ndarray) -> pd.DataFrame:
    t = pd.crosstab(pd.Series(fold, name="fold"), pd.Series(y, name="label"))
    t = t.reindex(columns=[0, 1], fill_value=0)
    t.columns = ["genuine_0", "attack_1"]
    t["total"] = t.sum(axis=1)
    t["genuine_pct"] = (100 * t["genuine_0"] / t["total"]).round(3)
    return t


# --------------------------------------------------------------------------
# Validation of the prepared data
# --------------------------------------------------------------------------
def run_validation(X: pd.DataFrame, y: np.ndarray, fold: np.ndarray, mode: str) -> dict:
    res = {}
    feats = list(X.columns)
    assert len(feats) == EXPECTED_N_FEATURES; res["n_features_60"] = True
    for c in NON_FEATURE_COLS + ["row_id"]:
        assert c not in feats
    res["no_label_attack_type_reported_id_fold_rowid_in_features"] = True
    assert len(X) == len(y) == len(fold); res["row_counts_match"] = True
    assert set(np.unique(y)) <= {0, 1}; res["labels_binary"] = True
    assert not X.isna().any().any() and np.isfinite(X.to_numpy(float)).all()
    res["no_missing_or_nonfinite"] = True

    seen_test_rows = np.zeros(len(X), dtype=int)
    for k, Xtr, Xte, ytr, yte, pre in iter_fold_data(X, y, fold):
        te = fold == k
        # fold structure preserved
        assert Xte.shape[0] == te.sum() and Xtr.shape[0] == (~te).sum()
        assert len(ytr) == Xtr.shape[0] and len(yte) == Xte.shape[0]
        seen_test_rows[te] += 1
        # scaler statistics equal TRAINING-partition statistics (not full-data, not test)
        sc: StandardScaler = pre.named_transformers_["num"]
        tr_mean = X.loc[~te].mean().to_numpy()
        assert np.allclose(sc.mean_, tr_mean, rtol=1e-9, atol=1e-9)
        assert not np.allclose(sc.mean_, X.mean().to_numpy(), rtol=1e-12, atol=1e-12), \
            "scaler mean equals full-data mean -> possible leakage"
        # transform of test must equal manual (x - train_mean)/train_scale
        manual = (X.loc[te].to_numpy() - sc.mean_) / np.where(sc.scale_ == 0, 1, sc.scale_)
        assert np.allclose(Xte.to_numpy(), manual, rtol=1e-8, atol=1e-8)
        # training data standardised (mean 0), test data generally not
        assert np.allclose(Xtr.to_numpy().mean(axis=0), 0, atol=1e-8)
        # class distribution untouched (no resampling)
        assert yte.sum() == y[te].sum() and len(yte) == te.sum()
        assert Xtr.shape[1] == EXPECTED_N_FEATURES
    assert (seen_test_rows == 1).all(), "every row must be in exactly one test fold"
    res["each_row_in_exactly_one_test_fold"] = True
    res["scaler_fit_on_train_partition_only"] = True
    res["no_resampling_applied"] = True
    res["mode"] = mode
    return res


# --------------------------------------------------------------------------
# Inspection summary
# --------------------------------------------------------------------------
def build_inspection(df: pd.DataFrame, feats: list[str], src: str) -> dict:
    X = df[feats]
    n = len(df)
    n_att = int((df[TARGET] == 1).sum()); n_gen = int((df[TARGET] == 0).sum())
    dup_full = int(df.drop(columns="row_id").duplicated().sum())
    dup_feat = int(df.duplicated(subset=feats).sum())
    dup_groups = df[df.duplicated(subset=feats, keep=False)]
    conflicting = int((dup_groups.groupby(feats)[TARGET].nunique() > 1).sum())
    cross_meta = int((dup_groups.groupby(feats)[["reported_id", FOLD_COL]].nunique().max(axis=1) > 1).sum())
    dd = df.drop_duplicates(subset=feats, keep="first")
    ids_across_folds = int((df.groupby("reported_id")[FOLD_COL].nunique() > 1).sum())
    sentinel_cols = {c: int((X[c] == SENTINEL_VALUE).sum()) for c in feats if (X[c] == SENTINEL_VALUE).any()}
    return {
        "source_file": Path(src).name,
        "format": "CSV (comma separated, header row)",
        "n_rows": n, "n_columns_raw": int(df.shape[1] - 1),  # minus row_id
        "columns_raw": [c for c in df.columns if c != "row_id"],
        "target": TARGET,
        "label_values_found": sorted(int(v) for v in df[TARGET].unique()),
        "label_meaning_confirmed_via_attack_type": {"0": "Genuine", "1": "Attack (19 attack_type values)"},
        "n_genuine": n_gen, "n_attack": n_att,
        "pct_genuine": round(100 * n_gen / n, 4), "pct_attack": round(100 * n_att / n, 4),
        "imbalance_ratio_attack_to_genuine": round(n_att / n_gen, 2),
        "n_eligible_features": len(feats),
        "excluded_columns": {
            "label": "target", "attack_type": "attack metadata (leaks class; 'Genuine' <=> label 0)",
            "reported_id": "identifier; ids are disjoint across folds and never mix labels",
            "fold": "evaluation split indicator, not a predictive attribute"},
        "dtypes_features": {str(k): int(v) for k, v in X.dtypes.astype(str).value_counts().items()},
        "n_missing": int(X.isna().sum().sum()),
        "n_inf": int(np.isinf(X.to_numpy(float)).sum()),
        "constant_features": [c for c in feats if X[c].nunique() <= 1],
        "low_cardinality_features(<=5 unique)": {c: int(X[c].nunique()) for c in feats if X[c].nunique() <= 5},
        "categorical_features_among_inputs": [c for c in feats if not pd.api.types.is_numeric_dtype(X[c])],
        "sentinel_minus20_counts": sentinel_cols,
        "duplicates": {
            "full_row_duplicates_excluding_row_id": dup_full,
            "feature_vector_duplicates_(60 features, later copies)": dup_feat,
            "rows_in_duplicate_groups": int(len(dup_groups)),
            "duplicate_groups": int(dup_groups.groupby(feats).ngroups),
            "all_duplicates_are_attack": bool((dup_groups[TARGET] == 1).all()),
            "groups_with_conflicting_labels": conflicting,
            "groups_whose_metadata_(reported_id/fold)_differs": cross_meta,
            "rows_after_dropping_feature_duplicates_keep_first": int(len(dd)),
            "attack_after": int((dd[TARGET] == 1).sum()), "genuine_after": int((dd[TARGET] == 0).sum()),
        },
        "folds": {
            "fold_column_present": True, "fold_ids": EXPECTED_FOLDS,
            "raw_class_table": fold_class_table(df[TARGET].to_numpy(), df[FOLD_COL].to_numpy()).reset_index().to_dict("records"),
            "dedup_class_table": fold_class_table(dd[TARGET].to_numpy(), dd[FOLD_COL].to_numpy()).reset_index().to_dict("records"),
            "folds_with_zero_genuine_in_test": [int(k) for k, v in
                df[df[TARGET] == 0][FOLD_COL].value_counts().reindex(EXPECTED_FOLDS, fill_value=0).items() if v == 0],
            "reported_ids_spanning_multiple_folds": ids_across_folds,
        },
        "rf_comparison": {
            "rf_total": 8931, "rf_features": 60, "rf_attack": 8784, "rf_genuine": 147,
            "raw_total": n, "raw_features": len(feats), "raw_attack": n_att, "raw_genuine": n_gen,
            "dedup_matches_rf_counts": bool(len(dd) == 8931 and (dd[TARGET] == 1).sum() == 8784 and (dd[TARGET] == 0).sum() == 147),
        },
    }


# --------------------------------------------------------------------------
# Main: write artifacts, run validation
# --------------------------------------------------------------------------
def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="two_bsm_clean.csv")
    ap.add_argument("--outdir", default="knn_step1_outputs")
    ap.add_argument("--save-fold-preprocessors", action="store_true",
                    help="also dump per-fold scalers (fit on that fold's training rows only)")
    a = ap.parse_args(argv)
    out = Path(a.outdir); out.mkdir(parents=True, exist_ok=True)

    df = load_raw(a.input)
    feats = get_feature_columns(df)
    validate_raw(df, feats)

    # 1. inspection summary
    insp = build_inspection(df, feats, a.input)
    (out / "dataset_inspection_summary.json").write_text(json.dumps(insp, indent=2, default=str))

    # 2. feature manifest
    pd.DataFrame({
        "feature": feats,
        "dtype": [str(df[c].dtype) for c in feats],
        "n_unique": [int(df[c].nunique()) for c in feats],
        "min": [float(df[c].min()) for c in feats],
        "max": [float(df[c].max()) for c in feats],
        "n_minus20_sentinel": [int((df[c] == SENTINEL_VALUE).sum()) for c in feats],
        "preprocessing": "StandardScaler (fit per fold, train partition only)",
    }).to_csv(out / "feature_manifest.csv", index=False)

    # 3. raw eligible features (UNSCALED) + metadata kept separately
    X, meta = split_features_meta(df, feats)
    X.to_csv(out / "knn_features_raw.csv", index=False)
    meta.to_csv(out / "knn_meta.csv", index=False)

    # 4. validation, once per duplicate mode, using the artifacts as reloaded from disk
    validation = {}
    for mode in DUPLICATE_MODES:
        Xm, ym, fm, _ = load_prepared(out, mode)
        validation[mode] = run_validation(Xm, ym, fm, mode)
        validation[mode]["n_rows"] = int(len(Xm))
        validation[mode]["fold_class_table"] = fold_class_table(ym, fm).reset_index().to_dict("records")
        if a.save_fold_preprocessors:
            d = out / "fold_preprocessors" / mode; d.mkdir(parents=True, exist_ok=True)
            for k, *_rest, pre in iter_fold_data(Xm, ym, fm):
                joblib.dump(pre, d / f"scaler_fold{k}.joblib")
    (out / "validation_results.json").write_text(json.dumps(validation, indent=2, default=str))

    # 5. preprocessing configuration record
    import sklearn
    config = {
        "target": TARGET, "label_mapping": {"0": "Genuine", "1": "Attack"},
        "fold_column": FOLD_COL, "folds": EXPECTED_FOLDS,
        "excluded_from_features": NON_FEATURE_COLS,
        "feature_list": feats, "n_features": len(feats),
        "imputation": "none required (0 missing, 0 non-finite)",
        "categorical_encoding": "none required (all 60 features numeric)",
        "scaling": {"method": "StandardScaler", "fit_on": "training partition of each fold only",
                    "applied_to_test": "transform only", "persisted_full_data_scaler": False},
        "resampling": "none applied in Step 1; test folds never modified",
        "duplicate_policy": "flagged only; decision pending user confirmation (modes: raw | rf_reconstructed)",
        "sentinel_value_minus20": "left unchanged",
        "versions": {"python": sys.version.split()[0], "pandas": pd.__version__,
                     "numpy": np.__version__, "sklearn": sklearn.__version__},
        "artifacts": ["dataset_inspection_summary.json", "feature_manifest.csv",
                      "knn_features_raw.csv", "knn_meta.csv", "validation_results.json"],
    }
    (out / "preprocessing_config.json").write_text(json.dumps(config, indent=2))

    print("Raw rows:", len(df), "| features:", len(feats))
    for mode in DUPLICATE_MODES:
        print(f"\n[{mode}] validation passed; rows =", validation[mode]["n_rows"])
        print(pd.DataFrame(validation[mode]["fold_class_table"]).to_string(index=False))
    print("\nAll assertions passed. Artifacts in:", out.resolve())
    return 0


if __name__ == "__main__":
    sys.exit(main())
