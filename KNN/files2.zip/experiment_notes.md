# KNN Experiment Notes (Step 2)

All numbers below come from `knn_experiment.py` run on the Step-1 files (single CPU, scikit-learn 1.8.0, seed 42). Pooled values were independently recomputed from `oof_predictions.csv`; they match.

## 1. Data validation and decisions

| Item | Finding | Decision |
|---|---|---|
| Matrix / labels / folds | 9,049 x 60 raw; labels {0,1}; `fold` in 0-4; `reported_id` never spans folds (group-disjoint) | Use the predefined `fold` column unchanged |
| Duplicates | Dropping later copies of identical 60-feature vectors gives 8,931 / 8,784 / 147, which matches the prepared-set size you reported. This is evidence, not proof | **Primary analysis: de-duplicated set (8,931 rows, keep-first).** Rationale: it matches the reported prepared dataset, and removes exact copies that could otherwise sit in both training and test. **Sensitivity:** baseline repeated on all 9,049 rows |
| Duplicate effect | Baseline accuracy 0.9711 (8,931) vs 0.9712 (9,049); genuine TN/FP identical (27/120) | Immaterial; conclusions do not depend on this choice |
| One cross-fold duplicate pair (rows 641 / 643) | Keep-first retains the fold-4 copy. The alternative would move one Attack row between folds 3 and 4 | Documented; cannot be resolved without external information |
| `-20` sentinel | Appears in many plausibility-check features (e.g. 3,311 rows in `bsm1_pC`). Looks like a "not computable" code, but meaning is not documented | **Left unchanged** (its meaning is not documented, so any replacement or imputation would be invented information; Step 1 also left it unchanged). Because KNN is distance-based, these values may influence neighbours; a sensitivity test is a possible future step, not done here |
| Genuine records | 147 records come from only **8 distinct `reported_id` values**; fold 2 has none, fold 4 has 5 | Folds kept as-is; undefined metrics reported as NaN |

## 2. Method

- **Pipeline:** StandardScaler -> optional training-only resampler -> `KNeighborsClassifier(algorithm="brute")`. No imputer or encoder (no missing values, all features numeric).
- **Baseline:** k=5, uniform voting, Euclidean, no resampling.
- **Tuning (nested):** for each outer test fold, k in {1,3,5,7,9,11,15,21,31} x weights {uniform, distance} x metric {euclidean, manhattan, chebyshev} (54 configurations) was scored by leave-one-fold-out CV over the **other four folds only**. Criterion: pooled inner out-of-fold macro-F1 (ties: balanced accuracy, smaller k, uniform, Euclidean). Scaler and resampler were refitted inside every inner split. The outer test fold was never used for selection.
- **Tuning speed-up:** one neighbour query per metric supplies all (k, weights) predictions. This was checked against `KNeighborsClassifier` (agreement 1.0 in all 24 checked configurations, `fast_vote_equivalence_check.csv`). All reported outer-fold results use real scikit-learn pipelines.
- **Imbalance strategies (training partition only, after scaling):** none; random undersampling to Genuine:Attack = 1:1 and 1:5 (`rus_1.0`, `rus_0.2`); SMOTE (k=5 neighbours) to 1:1 and 1:5 (`smote_1.0`, `smote_0.2`). Each was evaluated (a) with the baseline hyper-parameters (`k5_*`) and (b) with nested tuning (`tuned_*`). KNN has no `class_weight`; distance weighting is part of the tuned grid, but it does not rebalance classes.
- **Prediction rule:** P(Attack) > 0.5 -> Attack; ties go to Genuine (scikit-learn behaviour). Positive class for confusion matrices = Attack. Specificity = Genuine recall = TN/(TN+FP); FPR = Genuine records flagged as Attack; FNR = Attack records missed.

## 3. Handling of undefined metrics

- Fold 2 contains no Genuine records, so every Genuine-class metric, specificity, FPR, balanced accuracy, macro-F1 and both PR-AUC values are **NaN** there (not 0). Fold-mean / std use only folds where a metric is defined (`n_valid_folds_*` columns).
- Fold 4 has only 5 Genuine records; its Genuine metrics are extremely noisy (e.g. recall can only be 0, 0.2, 0.4 ...).
- Pooled out-of-fold metrics combine predictions from five different fold models; pooled PR-AUC therefore mixes score scales across models and should be read as indicative.
- Pooled Genuine recall is based on 147 records from 8 vehicles; it is much less precise than the number of rows suggests.

## 4. Caveats

1. "Always predict Attack" would reach 98.35% accuracy (8,784 / 8,931). Several KNN configurations score below that, so accuracy is not a useful ranking metric here.
2. PR-AUC for Attack is close to its no-skill level (Attack prevalence is 98.35%); PR-AUC for Genuine (no-skill about 0.016) is more informative.
3. Selected hyper-parameters differ from fold to fold (k from 1 to 31; Chebyshev and distance weighting are frequent) and inner macro-F1 values are only about 0.48-0.68. Selection is unstable, so small differences between tuned configurations should not be over-interpreted.
4. Comparing the five imbalance strategies using outer-fold results is a mild form of selection on the evaluation data. Each strategy's own tuning is leakage-free.
5. No Random Forest results were used or reproduced, so **no comparison with Random Forest is made**.
6. The explanation that Genuine records are hard to detect because they come from only 8 vehicles and folds are vehicle-disjoint is a hypothesis consistent with the data. It was not tested here.

## 5. Files

| File | Content |
|---|---|
| `knn_experiment.py` (in the parent folder, with `knn_preprocessing.py`) | Executable implementation |
| `fold_results.csv` | Per-fold metrics, hyper-parameters, confusion counts, timings |
| `oof_predictions.csv` | Out-of-fold predictions and P(Attack) for every experiment |
| `metrics_summary.csv` | Pooled OOF metrics plus fold mean/std and total timings |
| `confusion_matrices.csv` | Confusion counts per fold and pooled |
| `hyperparameter_results.csv` | Inner-CV score of all 54 configurations, per outer fold and strategy, selected flag |
| `selected_hyperparameters.csv` | Chosen configuration per outer fold |
| `attack_type_recall.csv` | Pooled recall per attack type |
| `knn_step2_preprocessing_config.json` | Full experiment configuration and environment |
| `fast_vote_equivalence_check.csv` | Check of the fast grid evaluation against scikit-learn |

Reproduce with: `python knn_experiment.py` (about 2 minutes on one CPU). The `--quick` flag runs a tiny smoke-test grid and is not used for any reported result.
