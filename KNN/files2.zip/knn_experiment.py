#!/usr/bin/env python3
"""
Step 2 - KNN experiment for VANET Sybil attack detection.

Design
  * Data      : Step-1 artifacts (raw unscaled features, label, predefined `fold`).
  * Duplicates: primary analysis uses the de-duplicated set (drop later copies of
                an identical 60-feature vector; 9,049 -> 8,931 rows).  A baseline
                sensitivity run on all 9,049 rows is also reported.
  * Sentinel  : -20 values are left unchanged.
  * Outer CV  : the 5 predefined folds (each fold is the test set once).
  * Tuning    : nested.  For outer fold k, hyper-parameters are chosen ONLY on the
                other four folds with leave-one-fold-out inner CV (inner pooled
                out-of-fold macro-F1).  The outer test fold is never touched.
  * Leakage   : StandardScaler and any resampler are fitted on the training
                partition only (inside every inner split as well).  Test data are
                never resampled.
  * Positive class for confusion matrices = Attack (1); Genuine (0) = negative.

Usage:  python knn_experiment.py [--quick]
"""
from __future__ import annotations

import argparse
import json
import platform
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import sklearn
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline as ImbPipeline
from imblearn.under_sampling import RandomUnderSampler
from sklearn.metrics import average_precision_score
from sklearn.neighbors import KNeighborsClassifier, NearestNeighbors

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from knn_preprocessing import load_prepared, make_preprocessor  # noqa: E402  (Step 1 code)

SEED = 42
FOLDS = [0, 1, 2, 3, 4]
GRID_K = [1, 3, 5, 7, 9, 11, 15, 21, 31]
GRID_W = ["uniform", "distance"]
GRID_METRIC = ["euclidean", "manhattan", "chebyshev"]
BASELINE = dict(n_neighbors=5, weights="uniform", metric="euclidean")
# name -> (kind, minority/majority ratio after resampling)
STRATEGIES = {
    "none": (None, None),
    "rus_1.0": ("rus", 1.0),
    "rus_0.2": ("rus", 0.2),
    "smote_1.0": ("smote", 1.0),
    "smote_0.2": ("smote", 0.2),
}


def log(msg: str) -> None:
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


# ----------------------------------------------------------------------------
# Metrics
# ----------------------------------------------------------------------------
def _div(a, b):
    return float(a) / float(b) if b else np.nan


def compute_metrics(y, p_attack, pred=None) -> dict:
    """All metrics for one set of predictions.  Attack = positive class.
    Metrics that are mathematically undefined are returned as NaN (never 0)."""
    y = np.asarray(y)
    pred = (np.asarray(p_attack) > 0.5).astype(int) if pred is None else np.asarray(pred)
    tn = int(((y == 0) & (pred == 0)).sum()); fp = int(((y == 0) & (pred == 1)).sum())
    fn = int(((y == 1) & (pred == 0)).sum()); tp = int(((y == 1) & (pred == 1)).sum())
    n_gen, n_att = tn + fp, tp + fn
    m = dict(n=len(y), n_genuine=n_gen, n_attack=n_att, tn=tn, fp=fp, fn=fn, tp=tp)
    m["accuracy"] = _div(tp + tn, len(y))
    # Attack class
    m["precision_attack"] = _div(tp, tp + fp)
    m["recall_attack"] = _div(tp, tp + fn)
    m["f1_attack"] = _div(2 * tp, 2 * tp + fp + fn)
    # Genuine class: undefined when the evaluated set holds no Genuine records
    has_gen = n_gen > 0
    m["precision_genuine"] = _div(tn, tn + fn) if has_gen else np.nan
    m["recall_genuine"] = _div(tn, tn + fp) if has_gen else np.nan
    m["f1_genuine"] = _div(2 * tn, 2 * tn + fn + fp) if has_gen else np.nan
    m["specificity"] = m["recall_genuine"]                       # TN / (TN + FP)
    m["fpr"] = _div(fp, fp + tn) if has_gen else np.nan          # Genuine flagged as Attack
    m["fnr"] = _div(fn, fn + tp)                                 # Attack missed
    m["balanced_accuracy"] = (np.nanmean([m["recall_genuine"], m["recall_attack"]])
                              if has_gen and n_att > 0 else np.nan)
    m["macro_f1"] = (np.nanmean([m["f1_genuine"], m["f1_attack"]]) if has_gen else np.nan)
    both = has_gen and n_att > 0
    m["pr_auc_attack"] = float(average_precision_score(y, p_attack)) if both else np.nan
    m["pr_auc_genuine"] = float(average_precision_score(1 - y, 1 - np.asarray(p_attack))) if both else np.nan
    return m


# ----------------------------------------------------------------------------
# Preprocessing / resampling helpers
# ----------------------------------------------------------------------------
def make_sampler(strategy: str):
    kind, ratio = STRATEGIES[strategy]
    if kind == "rus":
        return RandomUnderSampler(sampling_strategy=ratio, random_state=SEED)
    if kind == "smote":
        return SMOTE(sampling_strategy=ratio, k_neighbors=5, random_state=SEED)
    return None


def build_pipeline(feats, strategy, params) -> ImbPipeline:
    """scaler -> (optional training-only resampler) -> KNN.  Resamplers act only in fit()."""
    steps = [("pre", make_preprocessor(feats))]
    s = make_sampler(strategy)
    if s is not None:
        steps.append(("sampler", s))
    steps.append(("knn", KNeighborsClassifier(algorithm="brute", **params)))
    return ImbPipeline(steps)


def scaled_train_test(Xtr_raw, ytr, Xte_raw, strategy):
    """Fit scaler on training rows only, then resample TRAINING data only."""
    pre = make_preprocessor(list(Xtr_raw.columns))
    Xtr = pre.fit_transform(Xtr_raw).to_numpy(float)
    Xte = pre.transform(Xte_raw).to_numpy(float)
    s = make_sampler(strategy)
    if s is not None:
        Xtr, ytr = s.fit_resample(Xtr, ytr)
        Xtr = np.asarray(Xtr, float)
    return Xtr, np.asarray(ytr), Xte


# ----------------------------------------------------------------------------
# Fast evaluation of the whole (k, weights) grid from one neighbour query
# ----------------------------------------------------------------------------
def neighbour_table(Xtr, ytr, Xte, metric, kmax):
    nn = NearestNeighbors(n_neighbors=kmax, algorithm="brute", metric=metric).fit(Xtr)
    d, idx = nn.kneighbors(Xte)
    return d, ytr[idx]


def vote_p_attack(d, lab, k, weights):
    """P(Attack) exactly as KNeighborsClassifier computes it (incl. zero-distance rule)."""
    d, lab = d[:, :k], lab[:, :k]
    if weights == "uniform":
        return lab.mean(axis=1)
    with np.errstate(divide="ignore"):
        w = 1.0 / d
    zero = (d == 0).any(axis=1)
    w[zero] = (d[zero] == 0).astype(float)
    return (w * lab).sum(axis=1) / w.sum(axis=1)


def inner_cv_grid(Xraw, y, fold, outer_k, strategy, grid_k, grid_w, grid_m):
    """Leave-one-fold-out CV over the 4 folds that remain after removing outer fold `outer_k`."""
    inner_ids = [f for f in FOLDS if f != outer_k]
    store = {}  # (k, w, m) -> (list y, list p)
    for j in inner_ids:
        te = fold == j
        tr = (fold != j) & (fold != outer_k)          # outer test fold excluded
        Xtr, ytr, Xte = scaled_train_test(Xraw.loc[tr], y[tr], Xraw.loc[te], strategy)
        for m in grid_m:
            d, lab = neighbour_table(Xtr, ytr, Xte, m, max(grid_k))
            for k in grid_k:
                for w in grid_w:
                    store.setdefault((k, w, m), ([], []))
                    store[(k, w, m)][0].append(y[te])
                    store[(k, w, m)][1].append(vote_p_attack(d, lab, k, w))
    rows = []
    for (k, w, m), (ys, ps) in store.items():
        mm = compute_metrics(np.concatenate(ys), np.concatenate(ps))
        rows.append(dict(outer_fold=outer_k, strategy=strategy, k=k, weights=w, metric=m,
                         inner_macro_f1=mm["macro_f1"], inner_balanced_accuracy=mm["balanced_accuracy"],
                         inner_f1_genuine=mm["f1_genuine"], inner_recall_genuine=mm["recall_genuine"],
                         inner_f1_attack=mm["f1_attack"], inner_pr_auc_attack=mm["pr_auc_attack"],
                         inner_pr_auc_genuine=mm["pr_auc_genuine"], inner_fpr=mm["fpr"]))
    return pd.DataFrame(rows)


def select_best(df: pd.DataFrame) -> pd.Series:
    """Highest inner macro-F1; ties -> higher balanced accuracy, smaller k, uniform, euclidean first."""
    d = df.copy()
    d["_w"] = d["weights"].map({"uniform": 0, "distance": 1})
    d["_m"] = d["metric"].map({m: i for i, m in enumerate(GRID_METRIC)})
    d = d.sort_values(["inner_macro_f1", "inner_balanced_accuracy", "k", "_w", "_m"],
                      ascending=[False, False, True, True, True])
    return d.iloc[0]


# ----------------------------------------------------------------------------
# Outer evaluation
# ----------------------------------------------------------------------------
def evaluate_outer_fold(Xraw, y, fold, attack_type, row_id, k, strategy, params, exp_name):
    te = fold == k
    tr = ~te
    pipe = build_pipeline(list(Xraw.columns), strategy, params)
    t0 = time.perf_counter(); pipe.fit(Xraw.loc[tr], y[tr]); fit_t = time.perf_counter() - t0
    t0 = time.perf_counter(); proba = pipe.predict_proba(Xraw.loc[te]); pred_t = time.perf_counter() - t0
    p = proba[:, 1]
    pred = pipe.predict(Xraw.loc[te])
    assert np.array_equal(pred, (p > 0.5).astype(int)), "predict / predict_proba inconsistency"
    # leakage guards
    sc = pipe.named_steps["pre"].named_transformers_["num"]
    assert np.allclose(sc.mean_, Xraw.loc[tr].mean().to_numpy()), "scaler not fitted on training rows"
    n_train_after = pipe.named_steps["knn"].n_samples_fit_
    res = compute_metrics(y[te], p, pred)
    res.update(experiment=exp_name, fold=int(k), strategy=strategy, k=params["n_neighbors"],
               weights=params["weights"], metric=params["metric"], n_train_raw=int(tr.sum()),
               n_train_after_resampling=int(n_train_after), n_test=int(te.sum()),
               fit_seconds=fit_t, predict_seconds=pred_t)
    oof = pd.DataFrame(dict(experiment=exp_name, row_id=row_id[te], fold=int(k), y_true=y[te],
                            attack_type=attack_type[te], y_pred=pred, p_attack=p))
    return res, oof


def summarise(exp, fold_df, oof_df):
    """Pooled OOF metrics + mean/std over folds for which each metric is defined."""
    pooled = compute_metrics(oof_df["y_true"].to_numpy(), oof_df["p_attack"].to_numpy(),
                             oof_df["y_pred"].to_numpy())
    out = {"experiment": exp, **{f"pooled_{k}": v for k, v in pooled.items()}}
    for c in ["accuracy", "precision_attack", "recall_attack", "f1_attack", "precision_genuine",
              "recall_genuine", "f1_genuine", "pr_auc_attack", "pr_auc_genuine", "balanced_accuracy",
              "specificity", "fpr", "fnr", "macro_f1"]:
        v = fold_df[c].to_numpy(float)
        out[f"foldmean_{c}"] = float(np.nanmean(v)) if np.isfinite(v).any() else np.nan
        out[f"foldstd_{c}"] = float(np.nanstd(v, ddof=1)) if np.isfinite(v).sum() > 1 else np.nan
        out[f"n_valid_folds_{c}"] = int(np.isfinite(v).sum())
    out["total_fit_seconds"] = float(fold_df["fit_seconds"].sum())
    out["total_predict_seconds"] = float(fold_df["predict_seconds"].sum())
    out["total_tuning_seconds"] = float(fold_df["tuning_seconds"].sum()) if "tuning_seconds" in fold_df else 0.0
    return out


def verify_fast_vote_equivalence(Xraw, y, fold):
    """Confirms the fast grid evaluation reproduces KNeighborsClassifier predictions."""
    k_out = 0
    tr, te = fold != k_out, fold == k_out
    Xtr, ytr, Xte = scaled_train_test(Xraw.loc[tr], y[tr], Xraw.loc[te], "none")
    rec = []
    for m in GRID_METRIC:
        d, lab = neighbour_table(Xtr, ytr, Xte, m, 31)
        for k in (1, 5, 11, 31):
            for w in GRID_W:
                clf = KNeighborsClassifier(n_neighbors=k, weights=w, metric=m, algorithm="brute").fit(Xtr, ytr)
                a = clf.predict(Xte)
                b = (vote_p_attack(d, lab, k, w) > 0.5).astype(int)
                rec.append(dict(k=k, weights=w, metric=m, agreement=float((a == b).mean())))
    r = pd.DataFrame(rec)
    assert r["agreement"].min() >= 0.999, f"fast voting deviates from sklearn:\n{r}"
    return r


# ----------------------------------------------------------------------------
def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--step1-dir", default=str(HERE / "knn_step1_outputs"))
    ap.add_argument("--outdir", default=str(HERE / "knn_step2_outputs"))
    ap.add_argument("--quick", action="store_true", help="tiny grid / two strategies, for smoke-testing only")
    a = ap.parse_args(argv)
    out = Path(a.outdir); out.mkdir(parents=True, exist_ok=True)
    grid_k, grid_w, grid_m = GRID_K, GRID_W, GRID_METRIC
    strategies = list(STRATEGIES)
    if a.quick:
        grid_k, grid_m, strategies = [1, 5, 11], ["euclidean"], ["none", "rus_1.0"]
    t_all = time.perf_counter()

    # ---- 1. load + validate -------------------------------------------------
    X, y, fold, meta = load_prepared(a.step1_dir, "rf_reconstructed")
    X_raw_all, y_raw_all, fold_raw_all, meta_raw_all = load_prepared(a.step1_dir, "raw")
    assert X.shape == (8931, 60) and X_raw_all.shape == (9049, 60)
    assert (y == 1).sum() == 8784 and (y == 0).sum() == 147
    assert sorted(np.unique(fold)) == FOLDS and set(np.unique(y)) == {0, 1}
    assert not X.isna().any().any() and np.isfinite(X.to_numpy(float)).all()
    assert not X.duplicated().any(), "duplicates remain in primary dataset"
    for c in ["label", "attack_type", "reported_id", "fold", "row_id"]:
        assert c not in X.columns
    # folds are group-disjoint by reported_id
    assert (meta.groupby("reported_id")["fold"].nunique() == 1).all()
    row_id, attack_type = meta["row_id"].to_numpy(), meta["attack_type"].to_numpy()
    fold_tbl = pd.crosstab(fold, y)
    log(f"primary data {X.shape}; fold x label:\n{fold_tbl}")
    eq = verify_fast_vote_equivalence(X, y, fold)
    eq.to_csv(out / "fast_vote_equivalence_check.csv", index=False)
    log(f"fast-vote equivalence min agreement = {eq['agreement'].min():.6f}")

    fold_rows, oof_parts, hp_parts, sel_rows = [], [], [], []

    def run_fixed(exp, Xd, yd, fd, rid, atype, strategy, params):
        rows, oofs = [], []
        for k in FOLDS:
            r, o = evaluate_outer_fold(Xd, yd, fd, atype, rid, k, strategy, params, exp)
            rows.append(r); oofs.append(o)
        log(f"{exp}: done")
        return rows, oofs

    # ---- 2. baseline + fixed-k resampling ablation ----------------------------
    log("baseline k=5 / uniform / euclidean / no resampling")
    r, o = run_fixed("baseline_k5", X, y, fold, row_id, attack_type, "none", BASELINE)
    fold_rows += r; oof_parts += o
    log("sensitivity: baseline on all 9,049 rows (duplicates retained)")
    r, o = run_fixed("baseline_k5_with_duplicates", X_raw_all, y_raw_all, fold_raw_all,
                     meta_raw_all["row_id"].to_numpy(), meta_raw_all["attack_type"].to_numpy(), "none", BASELINE)
    fold_rows += r; oof_parts += o
    for s in strategies:
        if s == "none":
            continue
        r, o = run_fixed(f"k5_{s}", X, y, fold, row_id, attack_type, s, BASELINE)
        fold_rows += r; oof_parts += o

    # ---- 3. nested tuning per imbalance strategy ------------------------------
    for s in strategies:
        exp = f"tuned_{s}"
        for k in FOLDS:
            t0 = time.perf_counter()
            hp = inner_cv_grid(X, y, fold, k, s, grid_k, grid_w, grid_m)
            best = select_best(hp)
            tune_t = time.perf_counter() - t0
            hp["selected"] = (hp["k"] == best["k"]) & (hp["weights"] == best["weights"]) & (hp["metric"] == best["metric"])
            hp_parts.append(hp)
            params = dict(n_neighbors=int(best["k"]), weights=best["weights"], metric=best["metric"])
            r, o = evaluate_outer_fold(X, y, fold, attack_type, row_id, k, s, params, exp)
            r["tuning_seconds"] = tune_t; r["inner_macro_f1_selected"] = float(best["inner_macro_f1"])
            fold_rows.append(r); oof_parts.append(o)
            sel_rows.append(dict(experiment=exp, outer_fold=k, **params, inner_macro_f1=float(best["inner_macro_f1"]),
                                 tuning_seconds=tune_t))
            log(f"{exp} fold {k}: selected {params} (inner macro-F1 {best['inner_macro_f1']:.4f}) tune {tune_t:.1f}s")

    # ---- 4. aggregate + save --------------------------------------------------
    fold_df = pd.DataFrame(fold_rows)
    if "tuning_seconds" not in fold_df:
        fold_df["tuning_seconds"] = 0.0
    fold_df["tuning_seconds"] = fold_df["tuning_seconds"].fillna(0.0)
    oof_df = pd.concat(oof_parts, ignore_index=True)
    hp_df = pd.concat(hp_parts, ignore_index=True) if hp_parts else pd.DataFrame()

    # consistency: every row appears exactly once per experiment, folds unchanged
    for exp, g in oof_df.groupby("experiment"):
        assert g["row_id"].is_unique, exp
        assert len(g) == (9049 if exp.endswith("with_duplicates") else 8931), exp
    chk = oof_df[oof_df.experiment == "baseline_k5"].merge(meta[["row_id", "fold", "label"]], on="row_id", suffixes=("", "_m"))
    assert (chk["fold"] == chk["fold_m"]).all() and (chk["y_true"] == chk["label"]).all()

    summary = pd.DataFrame([summarise(e, fold_df[fold_df.experiment == e], oof_df[oof_df.experiment == e])
                            for e in fold_df["experiment"].unique()])
    cm_rows = []
    for e, g in fold_df.groupby("experiment", sort=False):
        for _, r in g.iterrows():
            cm_rows.append(dict(experiment=e, scope=f"fold_{int(r['fold'])}", tn=r.tn, fp=r.fp, fn=r.fn, tp=r.tp))
        cm_rows.append(dict(experiment=e, scope="pooled_oof", tn=g.tn.sum(), fp=g.fp.sum(), fn=g.fn.sum(), tp=g.tp.sum()))
    cm = pd.DataFrame(cm_rows)
    # recall by attack type (pooled OOF)
    at = oof_df[oof_df.y_true == 1].assign(hit=lambda d: (d.y_pred == 1).astype(int)) \
        .groupby(["experiment", "attack_type"]).agg(n=("hit", "size"), detected=("hit", "sum")).reset_index()
    at["recall"] = at["detected"] / at["n"]

    fold_df.to_csv(out / "fold_results.csv", index=False)
    oof_df.to_csv(out / "oof_predictions.csv", index=False)
    summary.to_csv(out / "metrics_summary.csv", index=False)
    cm.to_csv(out / "confusion_matrices.csv", index=False)
    at.to_csv(out / "attack_type_recall.csv", index=False)
    if len(hp_df):
        hp_df.to_csv(out / "hyperparameter_results.csv", index=False)
        pd.DataFrame(sel_rows).to_csv(out / "selected_hyperparameters.csv", index=False)

    config = dict(
        data=dict(primary="de-duplicated (keep first), 8,931 rows, 60 features",
                  sensitivity="all 9,049 rows (baseline only)", folds="predefined `fold` column, 0-4",
                  sentinel_minus20="unchanged", excluded_columns=["label", "attack_type", "reported_id", "fold"]),
        preprocessing=dict(scaler="StandardScaler fitted on training partition only (every outer and inner split)",
                           imputation="none (no missing/non-finite values)", encoding="none (all numeric)"),
        baseline=BASELINE,
        grid=dict(k=grid_k, weights=grid_w, metric=grid_m),
        imbalance_strategies={k: v for k, v in STRATEGIES.items() if k in strategies},
        resampling="training partition only, after scaling; test folds never resampled",
        tuning=dict(scheme="nested: leave-one-fold-out inner CV on the 4 non-test folds",
                    criterion="pooled inner out-of-fold macro-F1 (ties: balanced accuracy, smaller k, uniform, euclidean)"),
        positive_class="Attack (1)", prediction_rule="P(Attack) > 0.5 -> Attack; ties -> Genuine",
        seed=SEED, quick_mode=a.quick,
        environment=dict(python=platform.python_version(), sklearn=sklearn.__version__, pandas=pd.__version__,
                         numpy=np.__version__, cpu_count=1),
        total_runtime_seconds=time.perf_counter() - t_all)
    (out / "knn_step2_preprocessing_config.json").write_text(json.dumps(config, indent=2))
    log(f"finished in {time.perf_counter() - t_all:.1f}s; outputs in {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
