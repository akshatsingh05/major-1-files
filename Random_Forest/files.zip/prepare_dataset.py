"""
Part 1 - Dataset preparation for VANET misbehaviour detection (two_bsm_clean.csv).

Reproducible: run `python prepare_dataset.py [input_csv] [output_dir]`.
No model is trained and no model metric is computed here.

Decisions encoded (evidence is in the written report):
  1. Target            : label (0 = Genuine, 1 = Attack)
  2. Model features    : the 60 bsm1_* / bsm2_* columns, kept raw (no scaling, no outlier
                         removal, no feature dropping, no imputation - none is needed).
  3. Excluded          : attack_type (label proxy), reported_id (source identifier).
  4. Retained for CV   : fold (not a feature; used only to split).
  5. Deduplication     : rows with an identical 60-feature vector + label are collapsed
                         (keep first). This covers the 117 exact full-row duplicates plus
                         1 feature-identical row that sits in a different fold.
"""
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

SRC = Path(sys.argv[1] if len(sys.argv) > 1 else "/mnt/user-data/uploads/two_bsm_clean.csv")
OUT = Path(sys.argv[2] if len(sys.argv) > 2 else "/mnt/user-data/outputs")
OUT.mkdir(parents=True, exist_ok=True)

TARGET, FOLD = "label", "fold"
ANALYSIS_ONLY = ["reported_id", "attack_type"]

raw = pd.read_csv(SRC)                      # original file is never modified
raw["orig_row_idx"] = np.arange(len(raw))   # traceability back to the source CSV

FEATURES = [c for c in raw.columns
            if c not in [TARGET, FOLD, "orig_row_idx", *ANALYSIS_ONLY]]
assert len(FEATURES) == 60 and all(c.startswith(("bsm1_", "bsm2_")) for c in FEATURES)

# ---- sanity checks on the raw data that the decisions rely on -------------------------
assert raw[FEATURES + [TARGET]].notna().all().all(), "unexpected missing values"
assert np.isfinite(raw[FEATURES].to_numpy()).all(), "unexpected inf values"
assert set(raw[TARGET].unique()) == {0, 1}
assert (raw.groupby("attack_type")[TARGET].nunique() == 1).all()          # attack_type determines label
assert (raw.groupby("reported_id")[FOLD].nunique() == 1).all()            # folds are group-disjoint

# ---- deduplication ---------------------------------------------------------------------
n_full_dup = int(raw.drop(columns="orig_row_idx").duplicated().sum())
dup_mask = raw.duplicated(subset=FEATURES + [TARGET], keep="first")
n_removed = int(dup_mask.sum())
clean = raw.loc[~dup_mask].reset_index(drop=True)

# ---- build outputs ---------------------------------------------------------------------
model_ready = clean[FEATURES + [TARGET, FOLD]].copy()
model_ready[TARGET] = model_ready[TARGET].astype("int8")
model_ready[FOLD] = model_ready[FOLD].astype("int8")
metadata = clean[["orig_row_idx", "reported_id", "attack_type", FOLD, TARGET]].copy()  # same row order

model_ready.to_csv(OUT / "two_bsm_model_ready.csv", index=False)
metadata.to_csv(OUT / "two_bsm_analysis_metadata.csv", index=False)
json.dump({
    "target": TARGET,
    "cv_fold_column": FOLD,
    "model_features": FEATURES,
    "excluded_from_model": {
        "attack_type": "perfect proxy for label (Genuine <-> 0); direct leakage",
        "reported_id": "source identifier; encodes Sybil/ID format; 1 label per ID; memorisation risk",
    },
    "analysis_only_file": "two_bsm_analysis_metadata.csv (row-aligned with model-ready file)",
}, open(OUT / "feature_manifest.json", "w"), indent=2)

# ---- validation ------------------------------------------------------------------------
chk = pd.read_csv(OUT / "two_bsm_model_ready.csv")
meta_chk = pd.read_csv(OUT / "two_bsm_analysis_metadata.csv")
assert len(chk) == len(raw) - n_removed == len(meta_chk)
assert chk.shape[1] == 62 and list(chk.columns) == FEATURES + [TARGET, FOLD]
assert "attack_type" not in chk.columns and "reported_id" not in chk.columns
assert chk.isna().sum().sum() == 0 and np.isfinite(chk[FEATURES].to_numpy()).all()
assert set(chk[TARGET].unique()) == {0, 1} and set(chk[FOLD].unique()) == {0, 1, 2, 3, 4}
assert chk.duplicated().sum() == 0
assert (chk[TARGET].to_numpy() == meta_chk[TARGET].to_numpy()).all()
assert (chk[FOLD].to_numpy() == meta_chk[FOLD].to_numpy()).all()
# Fold/ID disjointness must survive dedup
assert (meta_chk.groupby("reported_id")[FOLD].nunique() == 1).all()
assert all(pd.api.types.is_numeric_dtype(t) for t in chk[FEATURES].dtypes)

print("=== PREPARATION SUMMARY ===")
print(f"Original rows            : {len(raw)}")
print(f"Exact full-row duplicates: {n_full_dup}")
print(f"Rows removed (feature+label dup): {n_removed}")
print(f"Final shape              : {chk.shape}")
print(f"Target counts            :\n{chk[TARGET].value_counts().to_string()}")
print(f"Target %                 :\n{(chk[TARGET].value_counts(normalize=True) * 100).round(3).to_string()}")
print("Fold x label:")
print(pd.crosstab(chk[FOLD], chk[TARGET], margins=True).to_string())
print("Removed rows by fold/attack_type:")
print(raw.loc[dup_mask].groupby([FOLD, "attack_type"]).size().to_string())
print(f"Missing: {chk.isna().sum().sum()} | inf: {int(np.isinf(chk[FEATURES].to_numpy()).sum())} | dup: {chk.duplicated().sum()}")
print("ALL VALIDATION ASSERTIONS PASSED")
