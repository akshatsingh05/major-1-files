"""SVM evaluation on two_bsm_clean.csv (target: label; 0 = genuine, 1 = attack)."""
import warnings; warnings.filterwarnings("ignore")
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt, seaborn as sns
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_validate, GridSearchCV, StratifiedGroupKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score, balanced_accuracy_score,
                             confusion_matrix, classification_report, roc_auc_score, roc_curve, ConfusionMatrixDisplay)

PATH = "/mnt/user-data/uploads/two_bsm_clean.csv"
OUT = "/mnt/user-data/outputs/"
RS = 42

# ---------- 1. Inspection ----------
df = pd.read_csv(PATH)
print("Shape:", df.shape)
print("Columns:", list(df.columns))
print("\nDtypes:\n", df.dtypes.value_counts())
print("\nFirst 5 rows:\n", df.head().to_string())
print("\nMissing values total:", int(df.isna().sum().sum()))
print("Duplicate rows:", int(df.duplicated().sum()))
print("\nTarget distribution (label):\n", df["label"].value_counts(), "\n", df["label"].value_counts(normalize=True).round(4))
print("\nattack_type vs label:\n", pd.crosstab(df["attack_type"], df["label"]))

# Class distribution chart
fig, ax = plt.subplots(1, 2, figsize=(13, 5))
vc = df["label"].value_counts().sort_index()
ax[0].bar(["0 (Genuine)", "1 (Attack)"], vc.values, color=["#4C72B0", "#C44E52"])
for i, v in enumerate(vc.values): ax[0].text(i, v, str(v), ha="center", va="bottom")
ax[0].set_title("Target class distribution"); ax[0].set_ylabel("Rows")
at = df["attack_type"].value_counts()
ax[1].barh(at.index[::-1], at.values[::-1], color="#8172B2"); ax[1].set_title("attack_type counts (NOT used as feature)")
plt.tight_layout(); plt.savefig(OUT + "class_distribution.png", dpi=150); plt.close()

# ---------- 2. Preprocessing ----------
n0 = len(df); df = df.drop_duplicates().reset_index(drop=True)   # exact duplicates would straddle train/test
print(f"\nDropped {n0-len(df)} duplicate rows -> {df.shape}")
drop_cols = ["label", "attack_type", "reported_id", "fold"]       # target, leaking label proxy, ID, preset CV fold
X = df.drop(columns=drop_cols); y = df["label"]
print("Numeric features:", X.select_dtypes("number").shape[1], "| Categorical:", X.select_dtypes(exclude="number").shape[1])
assert X.isna().sum().sum() == 0
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, stratify=y, random_state=RS)
print("Train:", X_tr.shape, y_tr.value_counts().to_dict(), "| Test:", X_te.shape, y_te.value_counts().to_dict())

def pipe(**kw): return Pipeline([("scaler", StandardScaler()), ("svc", SVC(random_state=RS, **kw))])
def evaluate(model, name):
    p = model.predict(X_te); s = model.decision_function(X_te)
    r = dict(model=name, accuracy=accuracy_score(y_te, p), balanced_acc=balanced_accuracy_score(y_te, p),
             precision=precision_score(y_te, p), recall=recall_score(y_te, p), f1=f1_score(y_te, p),
             roc_auc=roc_auc_score(y_te, s),
             recall_genuine=recall_score(y_te, p, pos_label=0), f1_macro=f1_score(y_te, p, average="macro"))
    return r, p, s

# ---------- 3/4. Baseline + CV ----------
cv = StratifiedKFold(5, shuffle=True, random_state=RS)
scoring = ["accuracy", "balanced_accuracy", "precision", "recall", "f1", "roc_auc", "f1_macro"]
def cv_report(model, name):
    res = cross_validate(model, X_tr, y_tr, cv=cv, scoring=scoring, return_train_score=True)
    print(f"\n5-fold CV (train only) - {name}")
    for m in scoring: print(f"  {m:18s} {res['test_'+m].mean():.4f} +/- {res['test_'+m].std():.4f}")
    print(f"  train accuracy     {res['train_accuracy'].mean():.4f}")
    return res

models = {
  "RBF (C=1, scale)":                pipe(kernel="rbf", C=1.0, gamma="scale"),
  "RBF balanced":                    pipe(kernel="rbf", C=1.0, gamma="scale", class_weight="balanced"),
  "Linear (C=1)":                    pipe(kernel="linear", C=1.0, max_iter=200000),
  "Linear balanced":                 pipe(kernel="linear", C=1.0, class_weight="balanced", max_iter=200000),
}
rows, preds, scores, cvres = [], {}, {}, {}
for n, m in models.items():
    cvres[n] = cv_report(m, n)
    m.fit(X_tr, y_tr)
    r, p, s = evaluate(m, n); rows.append(r); preds[n] = p; scores[n] = s
    r["train_accuracy"] = accuracy_score(y_tr, m.predict(X_tr))
comp = pd.DataFrame(rows).set_index("model")
print("\nTEST-set comparison:\n", comp.round(4).to_string())

# majority-class baseline for context
print("\nMajority-class baseline accuracy:", round(max(y_te.mean(), 1 - y_te.mean()), 4))

# ---------- 5. Tuning (training data only) ----------
grid = {"svc__C": [1, 10, 100], "svc__gamma": ["scale", 0.001, 0.01],
        "svc__class_weight": [None, "balanced"]}
gs = GridSearchCV(pipe(kernel="rbf"), grid, cv=cv, scoring="balanced_accuracy", n_jobs=-1)
gs.fit(X_tr, y_tr)
print("\nBest params:", gs.best_params_, "| best CV balanced acc:", round(gs.best_score_, 4))
best = gs.best_estimator_
tuned_cv = cv_report(best, "Tuned RBF")
r, p, s = evaluate(best, "Tuned RBF"); r["train_accuracy"] = accuracy_score(y_tr, best.predict(X_tr))
rows.append(r); preds["Tuned RBF"] = p; scores["Tuned RBF"] = s
comp = pd.DataFrame(rows).set_index("model")
print("\nFINAL TEST comparison:\n", comp.round(4).to_string())
comp.round(4).to_csv(OUT + "model_comparison.csv")

# ---------- Final model detail ----------
print("\nTuned model confusion matrix [[TN FP],[FN TP]]:\n", confusion_matrix(y_te, preds["Tuned RBF"]))
print(classification_report(y_te, preds["Tuned RBF"], target_names=["Genuine(0)", "Attack(1)"], digits=4))
print("Baseline RBF classification report:\n", classification_report(y_te, preds["RBF (C=1, scale)"], target_names=["Genuine(0)", "Attack(1)"], digits=4))

# Sensitivity check: group-aware CV (rows with same reported_id are consecutive messages of one vehicle)
g = df.loc[X_tr.index, "reported_id"]
gcv = StratifiedGroupKFold(5, shuffle=True, random_state=RS)
gres = cross_validate(best, X_tr, y_tr, groups=g, cv=gcv, scoring=["accuracy", "balanced_accuracy", "f1_macro"])
print("\nGroup-aware CV (grouped by reported_id), tuned model:",
      {k[5:]: f"{v.mean():.4f}+/-{v.std():.4f}" for k, v in gres.items() if k.startswith("test_")})

# ---------- 6. Plots ----------
fig, ax = plt.subplots(1, 3, figsize=(16, 4.5))
for a, n in zip(ax, ["RBF (C=1, scale)", "RBF balanced", "Tuned RBF"]):
    cm = confusion_matrix(y_te, preds[n])
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", cbar=False, ax=a,
                xticklabels=["Genuine", "Attack"], yticklabels=["Genuine", "Attack"])
    a.set_title(n); a.set_xlabel("Predicted"); a.set_ylabel("Actual")
plt.suptitle("Confusion matrices (test set)"); plt.tight_layout(); plt.savefig(OUT + "confusion_matrices.png", dpi=150); plt.close()

plt.figure(figsize=(6.5, 5.5))
for n in ["RBF (C=1, scale)", "Linear (C=1)", "Tuned RBF"]:
    fpr, tpr, _ = roc_curve(y_te, scores[n]); plt.plot(fpr, tpr, label=f"{n} (AUC={roc_auc_score(y_te, scores[n]):.3f})")
plt.plot([0, 1], [0, 1], "k--", label="Chance"); plt.xlabel("False positive rate"); plt.ylabel("True positive rate")
plt.title("ROC curves (test set)"); plt.legend(loc="lower right"); plt.tight_layout(); plt.savefig(OUT + "roc_curves.png", dpi=150); plt.close()

sub = comp.loc[["Linear (C=1)", "RBF (C=1, scale)", "Linear balanced", "RBF balanced", "Tuned RBF"], ["accuracy", "f1", "f1_macro", "balanced_acc"]]
ax = sub.plot(kind="bar", figsize=(11, 5.5), rot=20, ylim=(0, 1.05)); ax.set_title("Linear vs RBF SVM (test set)")
ax.set_ylabel("Score"); ax.legend(["Accuracy", "F1 (attack)", "F1 (macro)", "Balanced acc."], loc="lower right")
plt.tight_layout(); plt.savefig(OUT + "linear_vs_rbf.png", dpi=150); plt.close()
print("\nSaved plots + model_comparison.csv to", OUT)
