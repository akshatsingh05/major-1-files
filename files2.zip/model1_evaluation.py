"""
Part 2 - Model 1: Random Forest baseline on two_bsm_model_ready.csv
===================================================================
* Predefined 5 folds (fold column values 0..4 are reported as Fold 1..5).
* Positive class = Attack (label 1); negative class = Genuine (label 0).
* Features = the 60 columns listed in feature_manifest.json. `label`, `fold`, `attack_type`
  and `reported_id` are never given to the model.
* Imbalance strategy (from Part 1): class_weight="balanced" computed inside each training fold.
  No resampling. Test folds are never modified.
* No hyper-parameter tuning. Random Forest needs no scaling, so there is no preprocessing step
  (a one-step Pipeline is used so the later models share the same code structure).
* attack_type is used ONLY after prediction, for post-hoc analysis.

Usage: python model1_evaluation.py [model_ready.csv] [analysis_metadata.csv] [feature_manifest.json]
"""
import json
import sys
import warnings
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import sklearn
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, average_precision_score, classification_report,
                             confusion_matrix, f1_score, precision_recall_curve, precision_score,
                             recall_score, roc_auc_score, roc_curve)
from sklearn.pipeline import Pipeline

warnings.filterwarnings("ignore")

# ------------------------------------------------------------------ configuration
HERE = Path(__file__).resolve().parent
OUT = HERE


def find(name, arg_idx):
    if len(sys.argv) > arg_idx:
        return Path(sys.argv[arg_idx])
    for d in [HERE, HERE.parent, Path("/home/claude/part2"), Path.cwd()]:
        if (d / name).exists():
            return d / name
    raise FileNotFoundError(name)


DATA = find("two_bsm_model_ready.csv", 1)
META = find("two_bsm_analysis_metadata.csv", 2)
MANIFEST = find("feature_manifest.json", 3)

SEED = 42
TARGET, FOLD_COL = "label", "fold"
RF_PARAMS = dict(n_estimators=300, criterion="gini", max_depth=None, min_samples_split=2,
                 min_samples_leaf=1, max_features="sqrt", bootstrap=True,
                 class_weight="balanced", random_state=SEED, n_jobs=-1)
THRESHOLD = 0.5  # RandomForestClassifier.predict == argmax of mean class probability (0.5 for binary)


def make_model():
    return Pipeline([("clf", RandomForestClassifier(**RF_PARAMS))])


# ------------------------------------------------------------------ load + verify inputs
df = pd.read_csv(DATA)
meta = pd.read_csv(META)
manifest = json.load(open(MANIFEST))
FEATURES = manifest["model_features"]

assert list(df.columns) == FEATURES + [TARGET, FOLD_COL], "unexpected columns in model-ready file"
assert len(FEATURES) == 60
assert not ({"attack_type", "reported_id"} & set(FEATURES)), "forbidden feature present"
assert df[FEATURES + [TARGET]].notna().all().all() and np.isfinite(df[FEATURES].to_numpy()).all()
assert set(df[TARGET].unique()) == {0, 1} and sorted(df[FOLD_COL].unique()) == [0, 1, 2, 3, 4]
assert len(meta) == len(df) and (meta[TARGET].to_numpy() == df[TARGET].to_numpy()).all() \
    and (meta[FOLD_COL].to_numpy() == df[FOLD_COL].to_numpy()).all(), "metadata not row-aligned"
assert (meta.groupby("reported_id")[FOLD_COL].nunique() == 1).all(), "reported_id spans folds"

X, y, folds = df[FEATURES], df[TARGET].to_numpy(), df[FOLD_COL].to_numpy()
print(f"Data {df.shape}; features={len(FEATURES)}; target counts={dict(pd.Series(y).value_counts())}")


# ------------------------------------------------------------------ metric helpers
def safe_div(a, b):
    return float(a / b) if b > 0 else np.nan


def compute_metrics(y_true, y_pred, y_score):
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    n_neg, n_pos = tn + fp, fn + tp
    m = {"n_test": len(y_true), "n_genuine": int(n_neg), "n_attack": int(n_pos),
         "TN": int(tn), "FP": int(fp), "FN": int(fn), "TP": int(tp)}
    m["Accuracy"] = accuracy_score(y_true, y_pred)
    m["Precision"] = precision_score(y_true, y_pred, pos_label=1, zero_division=np.nan) if (tp + fp) > 0 else np.nan
    m["Recall"] = safe_div(tp, n_pos)
    m["F1"] = f1_score(y_true, y_pred, pos_label=1, zero_division=np.nan) if (tp + fp) > 0 and n_pos > 0 else np.nan
    m["Specificity"] = safe_div(tn, n_neg)
    m["FPR"] = safe_div(fp, n_neg)
    m["FNR"] = safe_div(fn, n_pos)
    m["Balanced Accuracy"] = (m["Recall"] + m["Specificity"]) / 2 if n_neg > 0 and n_pos > 0 else np.nan
    # ROC-AUC needs both classes present in the test fold
    m["ROC-AUC"] = roc_auc_score(y_true, y_score) if n_neg > 0 and n_pos > 0 else np.nan
    m["PR-AUC"] = average_precision_score(y_true, y_score) if n_pos > 0 else np.nan  # Attack = positive
    return m


METRICS = ["Accuracy", "Precision", "Recall", "F1", "Balanced Accuracy", "ROC-AUC", "PR-AUC",
           "Specificity", "FPR", "FNR"]

# ------------------------------------------------------------------ 5-fold CV on predefined folds
oof_score = np.full(len(df), np.nan)
oof_pred = np.full(len(df), -1)
rows, reports, importances, notes = [], [], [], []

for k in range(5):
    test_idx = np.where(folds == k)[0]
    train_idx = np.where(folds != k)[0]
    assert len(np.intersect1d(test_idx, train_idx)) == 0
    # No test-set information is used to fit: model sees only X.iloc[train_idx], y[train_idx];
    # class weights are computed by sklearn from y[train_idx] inside fit().
    model = make_model().fit(X.iloc[train_idx], y[train_idx])
    score = model.predict_proba(X.iloc[test_idx])[:, 1]          # P(Attack)
    pred = model.predict(X.iloc[test_idx])
    oof_score[test_idx], oof_pred[test_idx] = score, pred
    m = compute_metrics(y[test_idx], pred, score)
    m = {"Fold": k + 1, "fold_value": k, "n_train": len(train_idx), **m}
    rows.append(m)
    importances.append(model.named_steps["clf"].feature_importances_)
    reports.append((f"FOLD {k + 1} (fold value {k}) - test n={len(test_idx)}, "
                    f"Genuine={m['n_genuine']}, Attack={m['n_attack']}",
                    classification_report(y[test_idx], pred, labels=[0, 1],
                                          target_names=["Genuine (0)", "Attack (1) [POSITIVE]"],
                                          zero_division=0, digits=4)))
    if m["n_genuine"] == 0:
        notes.append(f"Fold {k + 1}: no Genuine samples in test fold -> ROC-AUC, Specificity, FPR, "
                     f"Balanced Accuracy undefined (NaN). Genuine row in classification report has support 0.")
    print(f"Fold {k + 1}: acc={m['Accuracy']:.4f} rec={m['Recall']:.4f} TN={m['TN']} FP={m['FP']} "
          f"FN={m['FN']} TP={m['TP']}")

assert (oof_pred >= 0).all() and not np.isnan(oof_score).any()   # every row tested exactly once

fold_df = pd.DataFrame(rows)
fold_df.to_csv(OUT / "model1_fold_results.csv", index=False)

# ------------------------------------------------------------------ mean +/- SD (sample SD, ddof=1)
summ = []
for name in METRICS:
    v = fold_df[name].astype(float)
    valid = v.dropna()
    summ.append({"Metric": name, "Mean": valid.mean(),
                 "Std (ddof=1)": valid.std(ddof=1) if len(valid) > 1 else np.nan,
                 "N folds with defined value": len(valid),
                 "Mean ± SD": f"{valid.mean():.4f} ± {valid.std(ddof=1):.4f}" if len(valid) > 1 else f"{valid.mean():.4f}"})
summary_df = pd.DataFrame(summ)

# pooled (out-of-fold) metrics: every observation tested once
pooled = compute_metrics(y, oof_pred, oof_score)
summary_df = pd.concat([summary_df, pd.DataFrame([
    {"Metric": f"[Pooled OOF] {n}", "Mean": pooled[n], "Std (ddof=1)": np.nan,
     "N folds with defined value": 5, "Mean ± SD": f"{pooled[n]:.4f} (pooled)"} for n in METRICS])],
    ignore_index=True)
summary_df.to_csv(OUT / "model1_summary.csv", index=False)

# ------------------------------------------------------------------ confusion matrices
cm_rows = [{"Fold": r["Fold"], "TN": r["TN"], "FP": r["FP"], "FN": r["FN"], "TP": r["TP"]} for r in rows]
agg = {"Fold": "Aggregated (all 5)", "TN": pooled["TN"], "FP": pooled["FP"], "FN": pooled["FN"], "TP": pooled["TP"]}
assert agg["TN"] == sum(r["TN"] for r in rows) and agg["TP"] == sum(r["TP"] for r in rows)
pd.DataFrame(cm_rows + [agg]).to_csv(OUT / "model1_confusion_matrices.csv", index=False)

# ------------------------------------------------------------------ classification reports
with open(OUT / "model1_classification_reports.txt", "w") as f:
    f.write("MODEL 1 - RANDOM FOREST - CLASSIFICATION REPORTS\n"
            "Positive class = Attack (1). Negative class = Genuine (0). Threshold = 0.5.\n"
            "Note: where a test fold has zero Genuine samples, Genuine metrics are 0/undefined by construction.\n\n")
    for title, rep in reports:
        f.write("=" * 78 + "\n" + title + "\n" + "=" * 78 + "\n" + rep + "\n")
    f.write("=" * 78 + "\nPOOLED OUT-OF-FOLD (all 5 test folds combined)\n" + "=" * 78 + "\n")
    f.write(classification_report(y, oof_pred, labels=[0, 1],
                                  target_names=["Genuine (0)", "Attack (1) [POSITIVE]"], digits=4))
    f.write("\nNOTES\n" + "\n".join(notes) + "\n")

# ------------------------------------------------------------------ attack-type analysis (post-hoc only)
an = meta[["orig_row_idx", "reported_id", "attack_type", FOLD_COL, TARGET]].copy()
an["pred"], an["p_attack"] = oof_pred, oof_score
at_rows = []
for t, g in an.groupby("attack_type"):
    if t == "Genuine":
        continue
    det = int((g.pred == 1).sum())
    at_rows.append({"Attack Type": t, "Total Samples": len(g), "Detected as Attack": det,
                    "Missed (predicted Genuine)": len(g) - det, "Detection Rate": det / len(g),
                    "Distinct reported_id": g.reported_id.nunique(),
                    "Mean P(Attack)": g.p_attack.mean()})
at_df = pd.DataFrame(at_rows).sort_values("Detection Rate", ascending=False).reset_index(drop=True)
gen = an[an.attack_type == "Genuine"]
gen_row = {"Attack Type": "Genuine (reference: correct = predicted Genuine)", "Total Samples": len(gen),
           "Detected as Attack": int((gen.pred == 1).sum()),
           "Missed (predicted Genuine)": int((gen.pred == 0).sum()),
           "Detection Rate": float((gen.pred == 0).mean()), "Distinct reported_id": gen.reported_id.nunique(),
           "Mean P(Attack)": gen.p_attack.mean()}
pd.concat([at_df, pd.DataFrame([gen_row])], ignore_index=True).to_csv(OUT / "model1_attack_type_results.csv", index=False)
# per-fold breakdown (extra)
pf = an[an.attack_type != "Genuine"].assign(det=lambda d: (d.pred == 1).astype(int)) \
    .pivot_table(index="attack_type", columns=FOLD_COL, values="det", aggfunc=["sum", "count"], fill_value=0)
pf.columns = [f"{a}_fold{b + 1}" for a, b in pf.columns]
pf.to_csv(OUT / "model1_attack_type_by_fold.csv")

# per-reported_id view of the Genuine class (explains genuine-class errors)
gen_ids = gen.groupby(["reported_id", FOLD_COL]).agg(n=("pred", "size"), predicted_attack=("pred", "sum")).reset_index()
gen_ids.to_csv(OUT / "model1_genuine_by_vehicle.csv", index=False)

# out-of-fold predictions + feature importance (for later cross-model comparison)
an.rename(columns={"pred": "model1_pred", "p_attack": "model1_p_attack"}).to_csv(OUT / "model1_oof_predictions.csv", index=False)
imp = pd.DataFrame({"feature": FEATURES, "mean_importance": np.mean(importances, axis=0),
                    "std_importance": np.std(importances, axis=0, ddof=1)}) \
    .sort_values("mean_importance", ascending=False)
imp.to_csv(OUT / "model1_feature_importance.csv", index=False)

# ------------------------------------------------------------------ plots
colors = plt.cm.tab10(np.arange(5))

# confusion matrices (counts, with row-normalised % as second line)
fig, axes = plt.subplots(2, 3, figsize=(16, 10))
panels = [(f"Fold {r['Fold']}", np.array([[r["TN"], r["FP"]], [r["FN"], r["TP"]]])) for r in rows]
panels.append(("Aggregated (all 5 folds)", np.array([[agg["TN"], agg["FP"]], [agg["FN"], agg["TP"]]])))
for ax, (title, cm) in zip(axes.ravel(), panels):
    rn = cm.sum(axis=1, keepdims=True)
    pct = np.divide(cm, rn, out=np.zeros(cm.shape), where=rn > 0)
    ax.imshow(pct, cmap="Blues", vmin=0, vmax=1)
    for i in range(2):
        for j in range(2):
            ax.text(j, i, f"{cm[i, j]}\n({pct[i, j] * 100:.1f}% of row)", ha="center", va="center",
                    fontsize=11, color="white" if pct[i, j] > 0.5 else "black")
    ax.set_xticks([0, 1]); ax.set_xticklabels(["Genuine (0)", "Attack (1)"])
    ax.set_yticks([0, 1]); ax.set_yticklabels(["Genuine (0)", "Attack (1)"])
    ax.set_xlabel("Predicted"); ax.set_ylabel("Actual"); ax.set_title(title)
    if cm[0].sum() == 0:
        ax.text(0.5, -0.28, "no Genuine samples in this fold", transform=ax.transAxes, ha="center", fontsize=9, color="red")
fig.suptitle("Model 1 (Random Forest) - Confusion matrices (negative=Genuine, positive=Attack)", fontsize=14)
fig.tight_layout(); fig.savefig(OUT / "model1_confusion_matrix.png", dpi=150); plt.close(fig)

# ROC
fig, ax = plt.subplots(figsize=(8, 7))
for k in range(5):
    idx = folds == k
    if (y[idx] == 0).sum() == 0 or (y[idx] == 1).sum() == 0:
        continue
    fpr, tpr, _ = roc_curve(y[idx], oof_score[idx])
    ax.plot(fpr, tpr, color=colors[k], alpha=0.6, lw=1.3,
            label=f"Fold {k + 1} (AUC={rows[k]['ROC-AUC']:.3f}, n_genuine={rows[k]['n_genuine']})")
fpr, tpr, _ = roc_curve(y, oof_score)
ax.plot(fpr, tpr, color="black", lw=2.5, label=f"Pooled out-of-fold (AUC={pooled['ROC-AUC']:.3f})")
ax.plot([0, 1], [0, 1], "r--", label="Random classifier (AUC=0.5)")
ax.set_xlabel("False Positive Rate"); ax.set_ylabel("True Positive Rate (Recall, Attack)")
ax.set_title("Model 1 (Random Forest) - ROC curve\nFold 3 omitted: no Genuine samples (ROC undefined)")
ax.legend(loc="lower right", fontsize=8); ax.grid(alpha=0.3)
fig.tight_layout(); fig.savefig(OUT / "model1_roc_curve.png", dpi=150); plt.close(fig)

# Precision-Recall (Attack positive)
fig, ax = plt.subplots(figsize=(8, 7))
for k in range(5):
    idx = folds == k
    p, r, _ = precision_recall_curve(y[idx], oof_score[idx])
    ax.plot(r, p, color=colors[k], alpha=0.6, lw=1.3, label=f"Fold {k + 1} (AP={rows[k]['PR-AUC']:.4f})")
p, r, _ = precision_recall_curve(y, oof_score)
ax.plot(r, p, color="black", lw=2.5, label=f"Pooled out-of-fold (AP={pooled['PR-AUC']:.4f})")
ax.axhline(y.mean(), color="r", ls="--", label=f"No-skill baseline (Attack prevalence={y.mean():.4f})")
ax.set_xlabel("Recall (Attack)"); ax.set_ylabel("Precision (Attack)"); ax.set_ylim(0.9, 1.003)
ax.set_title("Model 1 (Random Forest) - Precision-Recall curve (positive = Attack)\n"
             "y-axis zoomed to [0.9, 1] because Attack prevalence is ~98%")
ax.legend(loc="lower left", fontsize=8); ax.grid(alpha=0.3)
fig.tight_layout(); fig.savefig(OUT / "model1_precision_recall_curve.png", dpi=150); plt.close(fig)

# ------------------------------------------------------------------ config
json.dump({
    "model_name": "Random Forest (Model 1)",
    "library": f"scikit-learn {sklearn.__version__} - sklearn.ensemble.RandomForestClassifier",
    "numpy": np.__version__, "pandas": pd.__version__,
    "pipeline": "Pipeline([('clf', RandomForestClassifier)]) - no preprocessing steps (tree model: scaling unnecessary)",
    "model_parameters": RF_PARAMS,
    "hyperparameter_tuning": "none (baseline)",
    "decision_threshold": THRESHOLD,
    "n_features": len(FEATURES), "feature_names": FEATURES,
    "target_column": TARGET, "positive_class": "1 (Attack)", "negative_class": "0 (Genuine)",
    "n_samples": int(len(df)), "n_folds": 5,
    "fold_strategy": "predefined 'fold' column; for each k: train on folds != k, test on fold k; no reshuffling. "
                     "fold values 0..4 are reported as Fold 1..5",
    "class_imbalance_strategy": "class_weight='balanced' (weights computed from each training fold only); "
                                "no resampling; test folds untouched and keep original distribution",
    "random_seed": SEED,
    "preprocessing_performed": "none inside the model (Random Forest is scale-invariant); dataset-level preprocessing from Part 1 only",
    "excluded_columns": ["label (target)", "fold (CV only)", "attack_type (post-hoc analysis only)", "reported_id (analysis only)"],
    "metric_conventions": "Attack=positive; undefined metrics reported as NaN; mean/SD over folds where defined, SD with ddof=1; "
                          "pooled out-of-fold metrics also reported",
    "input_files": {"data": str(DATA), "metadata": str(META), "manifest": str(MANIFEST)},
}, open(OUT / "model1_config.json", "w"), indent=2)

# ------------------------------------------------------------------ console report
pd.set_option("display.width", 250, "display.max_columns", 50)
print("\nFOLD RESULTS\n", fold_df[["Fold"] + METRICS + ["TN", "FP", "FN", "TP"]].round(4).to_string(index=False))
print("\nSUMMARY\n", summary_df[["Metric", "Mean ± SD", "N folds with defined value"]].to_string(index=False))
print("\nAGGREGATED CM:", {k: agg[k] for k in ["TN", "FP", "FN", "TP"]})
print("\nATTACK TYPE\n", pd.concat([at_df, pd.DataFrame([gen_row])]).round(4).to_string(index=False))
print("\nGENUINE BY VEHICLE\n", gen_ids.to_string(index=False))
print("\nTOP FEATURES\n", imp.head(12).round(4).to_string(index=False))
print("\nNOTES:", *notes, sep="\n- ")
