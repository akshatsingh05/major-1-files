# Auto-generated results summary

XGBoost installed in this run: **False**  |  SHAP installed: **False**

## Binary detection - primary (pooled over 5 held-out folds, positive = attack)

| model | accuracy | balanced_accuracy | macro_f1 | recall_attack | recall_genuine | fpr | fnr | roc_auc | pr_auc_genuine |
|---|---|---|---|---|---|---|---|---|---|
| RandomForest | 0.8427 | 0.7662 | 0.5190 | 0.8453 | 0.6871 | 0.3129 | 0.1547 | 0.8602 | 0.2305 |
| DecisionTree | 0.9785 | 0.6044 | 0.6181 | 0.9910 | 0.2177 | 0.7823 | 0.0090 | 0.6044 | 0.0749 |
| SVM_RBF | 0.8540 | 0.7820 | 0.5282 | 0.8564 | 0.7075 | 0.2925 | 0.1436 | 0.9249 | 0.1394 |

## Binary detection - no_abs_time (pooled over 5 held-out folds, positive = attack)

| model | accuracy | balanced_accuracy | macro_f1 | recall_attack | recall_genuine | fpr | fnr | roc_auc | pr_auc_genuine |
|---|---|---|---|---|---|---|---|---|---|
| RandomForest | 0.8765 | 0.8703 | 0.5591 | 0.8767 | 0.8639 | 0.1361 | 0.1233 | 0.9450 | 0.3117 |
| DecisionTree | 0.9782 | 0.6109 | 0.6228 | 0.9906 | 0.2313 | 0.7687 | 0.0094 | 0.6109 | 0.0791 |
| SVM_RBF | 0.8899 | 0.9173 | 0.5795 | 0.8890 | 0.9456 | 0.0544 | 0.1110 | 0.9694 | 0.3349 |

## Binary detection - no_abs_time_pos (pooled over 5 held-out folds, positive = attack)

| model | accuracy | balanced_accuracy | macro_f1 | recall_attack | recall_genuine | fpr | fnr | roc_auc | pr_auc_genuine |
|---|---|---|---|---|---|---|---|---|---|
| RandomForest | 0.9228 | 0.8805 | 0.6098 | 0.9242 | 0.8367 | 0.1633 | 0.0758 | 0.9460 | 0.4035 |
| DecisionTree | 0.9796 | 0.5982 | 0.6173 | 0.9924 | 0.2041 | 0.7959 | 0.0076 | 0.5982 | 0.0754 |
| SVM_RBF | 0.9457 | 0.9490 | 0.6674 | 0.9456 | 0.9524 | 0.0476 | 0.0544 | 0.9688 | 0.3428 |

## Binary detection - dedup_rows (pooled over 5 held-out folds, positive = attack)

| model | accuracy | balanced_accuracy | macro_f1 | recall_attack | recall_genuine | fpr | fnr | roc_auc | pr_auc_genuine |
|---|---|---|---|---|---|---|---|---|---|
| RandomForest | 0.8144 | 0.7652 | 0.5044 | 0.8161 | 0.7143 | 0.2857 | 0.1839 | 0.8586 | 0.2188 |
| DecisionTree | 0.9739 | 0.5954 | 0.5958 | 0.9868 | 0.2041 | 0.7959 | 0.0132 | 0.5954 | 0.0550 |
| SVM_RBF | 0.7856 | 0.7405 | 0.4873 | 0.7871 | 0.6939 | 0.3061 | 0.2129 | 0.9253 | 0.1407 |

## Multiclass (attack_type)

| model | accuracy | macro_f1_all_classes | macro_f1_classes_support_ge_30 | weighted_f1 | n_classes | n_classes_low_support |
|---|---|---|---|---|---|---|
| RandomForest | 0.9130 | 0.8253 | 0.8512 | 0.9115 | 20 | 1 |
