#!/usr/bin/env python3
"""
Build the one-page Word report for a model (default: XGBoost) in the same
layout as report_random_forest.docx.

Every number is read from the CSV/JSON files written by test_xgboost_vanet.py.
Nothing is typed in by hand, so the report can only contain results that were
actually produced. If the model has no row in the results (e.g. XGBoost was not
installed during the run) the script stops with an error instead of writing a
report.

Usage:
  python make_report_xgboost.py --out outputs --template report_random_forest.docx
Options:
  --setting dedup_rows|primary     data setting (default dedup_rows, which
                                   matches the Random Forest report's size)
  --threshold default|tuned        0.5 cut-off (default) or the cut-off chosen
                                   on training folds only
"""
import argparse
import copy
import json
import sys
from pathlib import Path

import pandas as pd
from docx import Document

DESCRIPTIONS = {
    "XGBoost": dict(
        title="XGBoost Model",
        short="XGBoost",
        full="XGBoost (Extreme Gradient Boosting)",
        intro=(" is an ensemble machine-learning classification algorithm that builds "
               "decision trees one after another, each correcting the errors of the "
               "previous trees. It is well suited for structured numerical data such as "
               "VANET Basic Safety Message (BSM) data because it can learn complex, "
               "non-linear relationships between vehicle and communication features "
               "without extensive feature transformation."),
        principle=(" XGBoost applies gradient boosting: each new decision tree is fitted to the "
                   "errors (gradient of the logistic loss) of the current ensemble and added "
                   "with a small learning rate, while subsampling and built-in regularization "
                   "reduce overfitting. The summed tree outputs are converted by the logistic "
                   "function into the probability that a BSM record is an attack, which decides "
                   "whether it represents "),
        config=("Configuration: 300 trees, maximum depth 5, learning rate 0.05, "
                "subsample and column-sample ratios 0.8."),
    ),
    "RandomForest": dict(
        title="Random Forest Model", short="Random Forest", full="Random Forest (RF)",
        intro=" is an ensemble machine-learning classification algorithm.",
        principle=" Each tree votes; the share of trees voting for an attack decides whether the record represents ",
        config="The baseline configuration used 300 trees with balanced class weights."),
}


def pct(x, nd=2):
    return f"{100 * x:.{nd}f}%"


def load(out, model, setting, threshold):
    out = Path(out)
    name = ("pooled_metrics_default_threshold_%s.csv" if threshold == "default"
            else "pooled_metrics_full_%s.csv") % setting
    f = out / name
    if not f.exists():
        sys.exit(f"ERROR: {f} not found. Run test_xgboost_vanet.py first "
                 f"(without --skip-ablations if you want the dedup_rows setting).")
    df = pd.read_csv(f)
    row = df[df["model"] == model]
    if row.empty:
        sys.exit(f"ERROR: no results for model '{model}' in {f.name} "
                 f"(models present: {list(df['model'])}). "
                 f"For XGBoost, install it (pip install xgboost) and re-run the experiment.")
    rep = json.loads((out / "dataset_report.json").read_text())
    return row.iloc[0], rep


def interpretation(m, rep, d, setting, threshold):
    n_gen, n_att, n = int(m.n_genuine), int(m.n_attack), int(m.n)
    base = n_att / n
    spec, rec, bal = m.recall_genuine, m.recall_attack, m.balanced_accuracy
    s = []
    s.append(f" {d['short']} achieved a recall of {pct(rec)}, precision of "
             f"{pct(m.precision_attack)}, F1-score of {pct(m.f1_attack)} and PR-AUC of "
             f"{pct(m.pr_auc_attack)} for the attack class. However, the dataset is highly "
             f"imbalanced: labelling every record as an attack would already give "
             f"{pct(base)} accuracy, so accuracy alone is not sufficient to assess the model.")
    if m.accuracy < base:
        s.append(" The observed accuracy is below this baseline.")
    if spec < 0.5:
        s.append(f" The low specificity ({pct(spec)}) and high false-positive rate "
                 f"({pct(m.fpr)}) indicate that the model frequently identifies genuine "
                 f"records as attacks; only {int(m.TN)} of {n_gen} genuine records were "
                 f"recognised, and the balanced accuracy of {pct(bal)} reflects this.")
    elif spec < 0.9:
        s.append(f" Genuine records were recognised with a specificity of {pct(spec)} "
                 f"(false-positive rate {pct(m.fpr)}), which leaves a substantial share of "
                 f"genuine traffic flagged as attacks; the balanced accuracy is {pct(bal)}.")
    else:
        s.append(f" Genuine records were recognised with a specificity of {pct(spec)} "
                 f"(false-positive rate {pct(m.fpr)}) and a balanced accuracy of {pct(bal)}.")
    fb = rep.get("fold_by_label", {})
    zero = [k for k, v in fb.items() if int(v.get("0", 0)) == 0]
    n_genuine_ids = rep.get("genuine_unique_reported_ids")
    extra = (f" The genuine samples come from only {n_genuine_ids} vehicles, so genuine-class "
             f"estimates are uncertain." if n_genuine_ids else "")
    if zero:
        s.append(f" Furthermore, the predefined folds contain an uneven distribution of "
                 f"genuine samples, including {len(zero)} fold with none, making some "
                 f"fold-level metrics unstable." + extra)
    else:
        s.append(" Furthermore, the predefined folds contain an uneven distribution of "
                 "genuine samples, making some fold-level metrics unstable." + extra)
    if spec < 0.5:
        s.append(f" Overall, {d['short']} is effective at detecting attacks, but further "
                 f"investigation is required to improve its ability to distinguish genuine "
                 f"traffic from attacks.")
    else:
        s.append(f" Overall, {d['short']} is effective at detecting attacks, and its handling "
                 f"of genuine traffic should be confirmed on additional genuine vehicles.")
    return "".join(s)


def build_report(out_dir, template=None, model="XGBoost", setting="dedup_rows",
                 threshold="default", docx_out=None):
    d = DESCRIPTIONS[model]
    m, rep = load(out_dir, model, setting, threshold)
    n_feat = int(rep["n_input_features"])
    orig_rows = int(rep["shape"][0])
    n, n_gen, n_att = int(m.n), int(m.n_genuine), int(m.n_attack)
    removed = orig_rows - n

    segs_setup = [
        ("Dataset and Experimental Setup:", True),
        (" The prepared dataset contained ", False),
        (f"{n:,} records with {n_feat} input features", True),
        (", including ", False),
        (f"{n_att:,} attack samples and {n_gen} genuine samples", True),
        (". The label column was used as the binary target, while attack_type, reported_id "
         "and the fold index were excluded to prevent information leakage. ", False),
    ]
    if removed > 0:
        segs_setup.append((f"{removed} exact duplicates were removed. ", False))
    thr_txt = ("The decision threshold was 0.5. " if threshold == "default" else
               "The threshold was chosen on training folds only. ")
    segs_setup.append((
        "The predefined five-fold structure was used for evaluation, with each fold serving "
        "as the test set once and no vehicle shared between training and test data. Class "
        "imbalance was handled during training (scale_pos_weight), not in the test data. " + thr_txt + d["config"] + " Metrics are pooled over the five test folds.", False))
    segs_setup.append(("\n", False))

    results = [
        ("Accuracy:", pct(m.accuracy)),
        ("Precision:", pct(m.precision_attack)),
        ("Recall:", pct(m.recall_attack)),
        ("F1-score:", pct(m.f1_attack)),
        ("PR-AUC (Average Precision):", pct(m.pr_auc_attack)),
        ("Balanced Accuracy:", pct(m.balanced_accuracy)),
        ("Specificity:", pct(m.recall_genuine)),
        ("False Positive Rate (FPR):", pct(m.fpr)),
        ("False Negative Rate (FNR):", pct(m.fnr)),
        ("Correctly detected attacks:", f"{pct(m.recall_attack)} of actual attacks "
                                        f"({int(m.TP):,} out of {n_att:,})"),
        ("Genuine samples correctly classified:", f"{int(m.TN)} out of {n_gen}"),
        ("Genuine samples incorrectly classified as attacks:", f"{int(m.FP)} out of {n_gen}"),
    ]

    # ---- build the document from the user's template (keeps fonts/bullets) ----
    tpl = Path(template) if template else None
    use_tpl = tpl is not None and tpl.exists()
    doc = Document(str(tpl)) if use_tpl else Document()
    bullet_ppr = None
    if use_tpl:
        for p in doc.paragraphs:
            if p.style.name == "List Paragraph" and p._p.pPr is not None:
                bullet_ppr = copy.deepcopy(p._p.pPr)
                break
        for p in list(doc.paragraphs):
            p._p.getparent().remove(p._p)
    else:
        print("NOTE: template not found; using a plain Word layout.")

    def add(segments, bullet=False):
        p = doc.add_paragraph()
        if bullet:
            if bullet_ppr is not None:
                old = p._p.pPr
                if old is not None:
                    p._p.remove(old)
                p._p.insert(0, copy.deepcopy(bullet_ppr))
            else:
                p.style = doc.styles["List Bullet"]
        for text, bold in segments:
            if text == "\n":
                p.add_run().add_break()
                continue
            r = p.add_run(text)
            if bold:
                r.bold = True
        return p

    add([(d["title"], True)])
    add([(d["full"], True), (d["intro"], False), ("\n", False),
         ("Working Principle:", True),
         (d["principle"], False), ("Genuine (0)", True), (" or ", False),
         ("Attack (1)", True),
         (" behavior. A record is classified as an attack when this probability reaches the "
          "decision threshold.", False),
         ("\n", False)] + segs_setup + [(f"{d['short']} Evaluation Results:", True)])
    for label, val in results:
        add([(label, True), (" " + val, False)], bullet=True)
    add([("Result Interpretation:", True),
         (interpretation(m, rep, d, setting, threshold), False)])

    out_path = Path(docx_out) if docx_out else Path(out_dir) / f"report_{model.lower()}.docx"
    doc.save(str(out_path))
    print(f"Report written: {out_path}")
    return out_path


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="outputs")
    ap.add_argument("--template", default="report_random_forest.docx")
    ap.add_argument("--model", default="XGBoost", choices=list(DESCRIPTIONS))
    ap.add_argument("--setting", default="dedup_rows", choices=["dedup_rows", "primary"])
    ap.add_argument("--threshold", default="default", choices=["default", "tuned"])
    ap.add_argument("--docx-out", default=None)
    a = ap.parse_args()
    build_report(a.out, a.template, a.model, a.setting, a.threshold, a.docx_out)
