# VANET attack detection on `two_bsm_clean.csv` — experiment report

## 0. Status (read this first)

| Item | Status |
|---|---|
| Dataset inspection | Done on the real file |
| Random Forest, Decision Tree, SVM (binary + RF multiclass) | **Run; all numbers below are real outputs** |
| **XGBoost (binary, multiclass, feature importance, SHAP)** | **NOT RUN.** `pip` could not reach PyPI from the analysis sandbox (egress policy returned 403), so `xgboost` and `shap` could not be installed. The XGBoost code path is written but **has never been executed**; it may contain bugs. No XGBoost metric is reported or implied anywhere in this document. |

To produce the XGBoost results, run the script on your machine (Section 6). It will fill in XGBoost rows automatically.

## 1. Dataset (verified on the file)

* 9,049 rows × 64 columns: 56 float, 7 int, 1 string (`attack_type`). No missing values, no infinities.
* `label`: 1 = attack (8,902 rows, 98.4 %), 0 = genuine (147 rows, 1.6 %). Label convention confirmed: `attack_type == "Genuine"` ⇔ `label == 0`, with no exceptions. **Attack is the majority class; genuine is the minority.** Majority-class accuracy is therefore 98.4 %, so accuracy alone is meaningless here.
* `attack_type`: 20 values (19 attacks + Genuine); sizes from 27 (DataReplaySybil) to 1,550 (DoSDisruptive).
* `reported_id`: 1,007 distinct values (1–303 rows each). No id has mixed labels and **no id appears in more than one `fold`**, so `fold` is a group-disjoint partition.
* **Only 8 distinct `reported_id`s are genuine** (2/3/0/2/1 per fold 0–4; fold 2 has no genuine rows). Everything about genuine-class performance rests on 8 vehicles.
* 117 exact duplicate rows, all inside the same `reported_id` (mostly DoS), none with conflicting labels → consistent with repeated messages, not accidental duplication. They are **kept** in the primary run; a de-duplicated run is reported as a sensitivity check.
* Univariate screen: no single feature separates the classes (best single-feature AUC 0.79, `bsm1_psmC`), so there is no trivial leaking column among the inputs.

**Inputs:** the 60 `bsm*` columns. **Excluded:** `attack_type` (reveals the target), `label`, `reported_id` (identifier), `fold` (partition index). Median imputation (no-op here) and, for the SVM only, standardisation are fit inside the training folds.

## 2. Protocol

* Outer evaluation: **leave-one-fold-out over the 5 predefined, group-disjoint folds**; predictions from the 5 held-out folds are pooled. A single holdout would be too noisy with 8 genuine ids.
* Positive class = **attack (1)**. FPR = genuine flagged as attack; FNR = attacks missed.
* Imbalance: XGBoost `scale_pos_weight = n_genuine/n_attack` (planned); RF `balanced_subsample`; DT/SVM `balanced`.
* Decision threshold chosen **only on training folds** (Youden-J on out-of-fold scores from a grouped, stratified inner 4-fold CV). The held-out fold is never used for fitting, tuning or thresholding. Hyperparameters are the fixed baseline from the task; **no tuning was done.**
* 95 % CIs: cluster bootstrap over `reported_id` (1,000 resamples).

## 3. Binary results — primary setting (all 60 features), pooled held-out folds

Test support: 147 genuine, 8,902 attack. **XGBoost: not run.**

| Model | Accuracy | Balanced acc. | Macro F1 | Attack recall | Genuine recall | FPR | FNR | ROC-AUC |
|---|---|---|---|---|---|---|---|---|
| Random Forest | 0.8427 | 0.7662 | 0.5190 | 0.8453 | 0.6871 | 0.3129 | 0.1547 | 0.8602 |
| Decision Tree | 0.9785 | 0.6044 | 0.6181 | 0.9910 | 0.2177 | 0.7823 | 0.0090 | 0.6044 |
| SVM (RBF) | 0.8540 | 0.7820 | 0.5282 | 0.8564 | 0.7075 | 0.2925 | 0.1436 | 0.9249 |

Bootstrap 95 % CIs (primary): genuine recall RF [0.27, 1.00], DT [0.00, 0.50], SVM [0.29, 0.97]; balanced accuracy RF [0.55, 0.93], SVM [0.57, 0.92]. **The intervals are very wide, so differences between RF and SVM are not statistically meaningful.**

Per-fold genuine recall is highly unstable (RF: 0.39 / 0.81 / n.a. / 0.96 / 1.00; SVM: 0.39 / 0.87 / n.a. / 0.98 / 1.00; fold 0 has 61 genuine rows from 2 vehicles and is the hard case; fold 2 has no genuine rows).

The Decision Tree's 97.9 % accuracy is the clearest illustration of why accuracy misleads: it detects only ~22 % of genuine messages.

## 4. Exploratory sensitivity analyses (balanced accuracy / genuine recall / FPR)

| Setting | RF | DT | SVM |
|---|---|---|---|
| Primary (60 features) | 0.766 / 0.687 / 0.313 | 0.604 / 0.218 / 0.782 | 0.782 / 0.708 / 0.292 |
| Without absolute timestamps (4 cols) | 0.870 / 0.864 / 0.136 | 0.611 / 0.231 / 0.769 | 0.917 / 0.946 / 0.054 |
| Without timestamps and raw `pos_x/pos_y` | 0.881 / 0.837 / 0.163 | 0.598 / 0.204 / 0.796 | 0.949 / 0.952 / 0.048 |
| Primary, duplicates removed | 0.765 / 0.714 / 0.286 | 0.595 / 0.204 / 0.796 | 0.741 / 0.694 / 0.306 |

**Caveat:** these were examined after seeing held-out-fold results, so they are exploratory and **not an unbiased estimate**; picking the best of them would be tuning on the test folds. A plausible (untested) explanation for the improvement is that absolute simulation time and raw coordinates are scenario-specific and let models memorise vehicles rather than behaviour, which hurts generalisation to unseen vehicles. If you adopt a reduced feature set, justify it on domain grounds and confirm on independent data.

## 5. Multiclass (`attack_type`, Random Forest only — XGBoost not run)

Pooled held-out folds, 20 classes: accuracy 0.913, macro-F1 0.825 (0.851 over classes with ≥30 test samples), weighted F1 0.912. Strong: DoS, DoSRandom, DoSDisruptive, DoSRandomSybil, ConstPos, ConstSpeed, RandomPos, RandomSpeed (F1 ≥ 0.97). Weak: **Genuine (F1 0.36)**, Disruptive (0.43), DataReplay (0.57), GridSybil (0.77), DataReplaySybil (0.33, only 27 samples → unreliable). Per-class tables and confusion matrix are in `multiclass_*` files.

## 6. Interpretation of feature importance (RF only; XGBoost/SHAP not run)

Top Random Forest impurity importances (mean over 5 fold models): `bsm1_psmC`, `bsm2_psmC`, `bsm1_kPSCP`, `bsm1_kPSCSP`, `bsm1_pP`. The file does not document what these abbreviations mean, so I do not interpret them individually. They are predictive associations learned from 8 genuine vehicles, not causal evidence, and impurity importance is biased toward high-cardinality features.

## 7. Run in VS Code on Windows

1. Install Python 3.10+ from python.org (tick "Add python.exe to PATH"). Install the VS Code *Python* extension.
2. Put `test_xgboost_vanet.py`, `requirements.txt` and `two_bsm_clean.csv` in one folder; open it via *File → Open Folder*.
3. Terminal → New Terminal (PowerShell), then:
   ```
   python -m venv .venv
   .venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   python test_xgboost_vanet.py --data two_bsm_clean.csv --out outputs
   ```
   If activation is blocked: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`.
4. Runtime is about 4–6 minutes with XGBoost on a laptop (use `--skip-ablations` for ~1–2 min, `--skip-svm` to drop the SVM).
5. Outputs appear in `outputs\`: `model_comparison_*.csv`, `pooled_metrics_full_*.csv`, `per_fold_metrics_*`, `classification_report_*`, `feature_importance_*.csv/png`, `shap_*` (if installed), `multiclass_*`, `xgboost_model.json`, `*.joblib` models, `results_summary.md`, `run_log.txt`.

If XGBoost misbehaves, please send me `outputs\run_log.txt`; errors are logged with tracebacks rather than skipped silently.

## 8. Draft results paragraph (XGBoost to be added after you run it)

> We evaluated tree-based and kernel classifiers for binary detection of malicious BSM pairs on 9,049 messages (8,902 attack, 147 genuine; the genuine messages originate from only 8 reporting vehicles). Models were assessed with leave-one-fold-out validation over five predefined, vehicle-disjoint folds, with decision thresholds selected exclusively on training folds. Overall accuracy is dominated by the 98.4 % attack majority and is therefore uninformative; a decision tree reached 97.9 % accuracy while recognising only 21.8 % of genuine messages. Random Forest and an RBF-SVM achieved balanced accuracies of 0.766 and 0.782 (genuine recall 0.687 and 0.708; attack recall 0.845 and 0.856), with bootstrap confidence intervals over vehicles spanning roughly 0.55–0.93, so no model ranking is statistically supported. [XGBoost results: not yet obtained.] Conclusions about genuine-message detection are limited by the small number of genuine vehicles.

## 9. Word report for XGBoost (same layout as report_random_forest.docx)

`python test_xgboost_vanet.py ...` now also writes `outputs\report_xgboost.docx` automatically once XGBoost has run
(keep `report_random_forest.docx` in the same folder; it is used as the layout template). To rebuild it on its own:

    python make_report_xgboost.py --out outputs --template report_random_forest.docx

All numbers are read from the result CSVs; the script refuses to create the report if XGBoost has no results.
Defaults (de-duplicated data, 0.5 threshold) match how the Random Forest report appears to have been produced;
use `--threshold tuned` or `--setting primary` for the other variants.
