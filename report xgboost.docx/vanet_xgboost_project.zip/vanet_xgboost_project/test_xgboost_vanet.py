#!/usr/bin/env python3
"""
Leakage-safe evaluation of XGBoost (plus RF / DT / SVM) for VANET attack
detection on two_bsm_clean.csv.

Design (see dataset_report.json for the evidence behind each choice):
  * Target: label (0 = genuine, 1 = attack; verified in the file).
    POSITIVE CLASS = attack (1). Genuine is the minority class (~1.6 %).
  * Excluded from inputs: label, attack_type (target leakage), reported_id
    (identifier), fold (partition index). Inputs = the 60 `bsm*` columns.
  * `fold` is group-disjoint with respect to `reported_id`, so it is used
    as the OUTER evaluation partition (leave-one-fold-out, 5 rounds). The
    test fold is never used for fitting, tuning, or threshold selection.
  * Threshold selection and imbalance handling happen on the TRAINING folds
    only, using StratifiedGroupKFold (grouped by reported_id) out-of-fold
    scores.
  * Hyper-parameters are the fixed baseline from the task statement; no
    tuning is performed, so there is nothing to leak into the test folds.
  * Duplicates are kept in the primary run (they are repeated messages inside
    one reported_id, never across ids); a de-duplicated sensitivity run is
    reported as well.

Usage:  python test_xgboost_vanet.py --data two_bsm_clean.csv --out outputs
"""
import argparse
import json
import logging
import sys
import time
import traceback
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import joblib
from sklearn.base import clone
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.metrics import (accuracy_score, average_precision_score,
                             classification_report, confusion_matrix,
                             f1_score, precision_score, roc_auc_score,
                             roc_curve)
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.utils.class_weight import compute_sample_weight

warnings.filterwarnings("ignore")

try:
    from xgboost import XGBClassifier
    import xgboost
    HAS_XGB, XGB_ERR = True, ""
except Exception as exc:  # pragma: no cover
    HAS_XGB, XGB_ERR = False, repr(exc)

try:
    import shap
    HAS_SHAP, SHAP_ERR = True, ""
except Exception as exc:  # pragma: no cover
    HAS_SHAP, SHAP_ERR = False, repr(exc)

SEED = 42
TARGET, ATTACK_COL = "label", "attack_type"
ID_COLS = ["reported_id", "fold"]
LOG = logging.getLogger("vanet")


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def md_table(df, nd=4):
    """Tiny markdown-table writer (avoids the optional `tabulate` package)."""
    d = df.copy()
    cols = list(d.columns)
    lines = ["| " + " | ".join(map(str, cols)) + " |",
             "|" + "|".join(["---"] * len(cols)) + "|"]
    for _, r in d.iterrows():
        cells = []
        for v in r.values:
            if isinstance(v, (float, np.floating)):
                cells.append("nan" if np.isnan(v) else f"{v:.{nd}f}")
            else:
                cells.append(str(v))
        lines.append("| " + " | ".join(cells) + " |")
    return "\n".join(lines)


def stage(name):
    """Decorator: run a stage, log errors with traceback, never hide them."""
    def deco(fn):
        def wrapper(*a, **k):
            LOG.info("=== %s ===", name)
            t0 = time.time()
            try:
                out = fn(*a, **k)
                LOG.info("%s finished in %.1fs", name, time.time() - t0)
                return out
            except Exception:
                LOG.error("STAGE FAILED: %s\n%s", name, traceback.format_exc())
                return None
        return wrapper
    return deco


# --------------------------------------------------------------------------
# 1. dataset analysis
# --------------------------------------------------------------------------
def analyse_dataset(df, feats, out):
    rep = {}
    rep["shape"] = list(df.shape)
    rep["dtypes"] = {c: str(t) for c, t in df.dtypes.items()}
    num = df.select_dtypes(include=[np.number])
    rep["categorical_columns"] = [c for c in df.columns if c not in num.columns]
    rep["n_numeric_columns"] = int(num.shape[1])
    rep["missing_total"] = int(df.isna().sum().sum())
    rep["inf_total"] = int(np.isinf(num).sum().sum())
    rep["duplicate_rows"] = int(df.duplicated().sum())
    rep["label_counts"] = {int(k): int(v) for k, v in df[TARGET].value_counts().items()}
    rep["attack_type_counts"] = {k: int(v) for k, v in df[ATTACK_COL].value_counts().items()}
    ct = pd.crosstab(df[ATTACK_COL], df[TARGET])
    rep["label_attack_consistent"] = bool(
        (ct.loc["Genuine", 0] == (df[TARGET] == 0).sum()) and ct.drop("Genuine")[0].sum() == 0
        and ct.loc["Genuine", 1] == 0)
    rep["fold_by_label"] = {int(k): {int(a): int(b) for a, b in v.items()}
                            for k, v in pd.crosstab(df["fold"], df[TARGET]).iterrows()}
    g = df.groupby("reported_id")
    rep["reported_id_unique"] = int(df.reported_id.nunique())
    rep["rows_per_reported_id"] = {k: float(v) for k, v in
                                   g.size().describe().items()}
    rep["reported_ids_with_mixed_labels"] = int((g[TARGET].nunique() > 1).sum())
    rep["reported_ids_spanning_folds"] = int((g["fold"].nunique() > 1).sum())
    rep["genuine_unique_reported_ids"] = int(df.loc[df[TARGET] == 0, "reported_id"].nunique())
    rep["genuine_ids_per_fold"] = {int(k): int(v) for k, v in
                                   df[df[TARGET] == 0].groupby("fold").reported_id.nunique().items()}
    # duplicates
    dup_all = df[df.duplicated(keep=False)]
    rep["duplicate_rows_by_attack_type"] = {k: int(v) for k, v in
                                            dup_all[ATTACK_COL].value_counts().items()}
    rep["duplicates_within_same_reported_id"] = int(df.duplicated(["reported_id"] + feats).sum())
    rep["duplicate_feature_rows_with_conflicting_label"] = int(
        (df.groupby(feats)[TARGET].nunique() > 1).sum())
    # univariate leakage screen
    uni = {}
    y = df[TARGET].values
    for c in feats:
        v = df[c].replace([np.inf, -np.inf], np.nan).fillna(df[c].median())
        if v.nunique() > 1:
            a = roc_auc_score(y, v)
            uni[c] = float(max(a, 1 - a))
    uni = dict(sorted(uni.items(), key=lambda kv: -kv[1]))
    rep["univariate_auc_top10"] = dict(list(uni.items())[:10])
    rep["constant_features"] = [c for c in feats if df[c].nunique() <= 1]
    zero_len = {int(k): float(v) for k, v in
                (df.groupby(TARGET)["bsm1_length"].apply(lambda s: (s == 0).mean())).items()}
    rep["frac_bsm1_length_zero_by_label"] = zero_len
    rep["majority_class_baseline_accuracy"] = float(max(y.mean(), 1 - y.mean()))
    rep["suitability"] = {
        "binary": "yes (but only 147 genuine rows from "
                  f"{rep['genuine_unique_reported_ids']} reported_ids)",
        "multiclass": "yes for 19 attack types + Genuine; several classes are "
                      "small (see multiclass report)"}
    rep["excluded_from_inputs"] = {
        ATTACK_COL: "directly reveals the target",
        TARGET: "target",
        "reported_id": "identifier / grouping key",
        "fold": "partition index, not a message property"}
    rep["n_input_features"] = len(feats)
    (out / "dataset_report.json").write_text(json.dumps(rep, indent=2))
    for k in ["shape", "missing_total", "inf_total", "duplicate_rows", "label_counts",
              "reported_id_unique", "reported_ids_with_mixed_labels",
              "reported_ids_spanning_folds", "genuine_unique_reported_ids",
              "genuine_ids_per_fold", "fold_by_label", "univariate_auc_top10"]:
        LOG.info("%s: %s", k, rep[k])
    return rep


# --------------------------------------------------------------------------
# 2. metrics
# --------------------------------------------------------------------------
def compute_metrics(y, pred, score=None):
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    sd = lambda a, b: a / b if b > 0 else np.nan
    rec_att, rec_gen = sd(tp, tp + fn), sd(tn, tn + fp)
    m = dict(n=len(y), n_genuine=int((y == 0).sum()), n_attack=int((y == 1).sum()),
             TN=int(tn), FP=int(fp), FN=int(fn), TP=int(tp),
             accuracy=accuracy_score(y, pred),
             balanced_accuracy=float(np.nanmean([rec_att, rec_gen])),
             precision_attack=precision_score(y, pred, pos_label=1, zero_division=0),
             recall_attack=rec_att, recall_genuine=rec_gen,
             f1_attack=f1_score(y, pred, pos_label=1, zero_division=0),
             f1_genuine=f1_score(y, pred, pos_label=0, zero_division=0),
             macro_f1=f1_score(y, pred, average="macro", labels=[0, 1], zero_division=0),
             weighted_f1=f1_score(y, pred, average="weighted", labels=[0, 1], zero_division=0),
             fpr=sd(fp, fp + tn), fnr=sd(fn, fn + tp),
             roc_auc=np.nan, pr_auc_attack=np.nan, pr_auc_genuine=np.nan)
    if score is not None and len(np.unique(y)) == 2:
        m["roc_auc"] = roc_auc_score(y, score)
        m["pr_auc_attack"] = average_precision_score(y, score)
        m["pr_auc_genuine"] = average_precision_score(1 - y, -score)
    return m


def pick_threshold(y, s):
    """Youden J (= max balanced accuracy) on training-only OOF scores."""
    if len(np.unique(y)) < 2:
        return None
    fpr, tpr, thr = roc_curve(y, s, drop_intermediate=False)
    j = tpr - fpr
    j[~np.isfinite(thr)] = -1
    return float(thr[int(np.argmax(j))])


def group_bootstrap(y, pred, groups, n_boot=1000, seed=SEED):
    """Cluster bootstrap over reported_id -> 95 % CI for key metrics."""
    rng = np.random.default_rng(seed)
    ug, inv = np.unique(groups, return_inverse=True)
    G = len(ug)
    cnt = np.zeros((G, 4))
    for i, (t, p) in enumerate(zip(y, pred)):
        cnt[inv[i], {(0, 0): 0, (0, 1): 1, (1, 0): 2, (1, 1): 3}[(int(t), int(p))]] += 1
    res = {"balanced_accuracy": [], "recall_genuine": [], "recall_attack": [], "fpr": []}
    for _ in range(n_boot):
        c = cnt[rng.integers(0, G, G)].sum(0)
        tn, fp, fn, tp = c
        if tn + fp == 0 or tp + fn == 0:
            continue
        rg, ra = tn / (tn + fp), tp / (tp + fn)
        res["recall_genuine"].append(rg)
        res["recall_attack"].append(ra)
        res["balanced_accuracy"].append((rg + ra) / 2)
        res["fpr"].append(1 - rg)
    return {k: (float(np.percentile(v, 2.5)), float(np.percentile(v, 97.5)))
            for k, v in res.items() if v}


# --------------------------------------------------------------------------
# 3. models
# --------------------------------------------------------------------------
def make_models(ytr):
    n_pos, n_neg = int((ytr == 1).sum()), int((ytr == 0).sum())
    imp = lambda: ("imp", SimpleImputer(strategy="median"))
    models = {}
    if HAS_XGB:
        models["XGBoost"] = Pipeline([imp(), ("clf", XGBClassifier(
            n_estimators=300, max_depth=5, learning_rate=0.05, subsample=0.8,
            colsample_bytree=0.8, objective="binary:logistic", eval_metric="logloss",
            random_state=SEED, scale_pos_weight=n_neg / max(n_pos, 1),
            tree_method="hist", n_jobs=-1))])
    models["RandomForest"] = Pipeline([imp(), ("clf", RandomForestClassifier(
        n_estimators=300, class_weight="balanced_subsample", n_jobs=-1,
        random_state=SEED))])
    models["DecisionTree"] = Pipeline([imp(), ("clf", DecisionTreeClassifier(
        class_weight="balanced", random_state=SEED))])
    models["SVM_RBF"] = Pipeline([imp(), ("sc", StandardScaler()), ("clf", SVC(
        kernel="rbf", C=1.0, gamma="scale", class_weight="balanced"))])
    return models


def get_score(model, X):
    if hasattr(model, "predict_proba"):
        return model.predict_proba(X)[:, 1]
    return model.decision_function(X)


def default_threshold(name):
    return 0.0 if name == "SVM_RBF" else 0.5


# --------------------------------------------------------------------------
# 4. binary experiment (leave-one-fold-out, thresholds from training data)
# --------------------------------------------------------------------------
def run_binary(df, feats, tag, extras=False, skip_svm=False):
    Xv = df[feats].replace([np.inf, -np.inf], np.nan).values.astype(float)
    y = df[TARGET].values.astype(int)
    g = df["reported_id"].values
    folds = df["fold"].values
    store = {}
    imp_store, shap_vals, shap_X = {}, [], []
    thr_store = {}
    rng = np.random.default_rng(SEED)

    for k in sorted(np.unique(folds)):
        te, tr = folds == k, folds != k
        Xtr, ytr, gtr, Xte, yte = Xv[tr], y[tr], g[tr], Xv[te], y[te]
        inner = StratifiedGroupKFold(n_splits=4, shuffle=True, random_state=SEED)
        inner_splits = list(inner.split(Xtr, ytr, gtr))
        for name, proto in make_models(ytr).items():
            if skip_svm and name == "SVM_RBF":
                continue
            t0 = time.time()
            oof = np.full(len(ytr), np.nan)
            for a, b in inner_splits:
                if len(np.unique(ytr[a])) < 2:
                    continue
                m = clone(proto).fit(Xtr[a], ytr[a])
                oof[b] = get_score(m, Xtr[b])
            ok = ~np.isnan(oof)
            thr = pick_threshold(ytr[ok], oof[ok])
            if thr is None:
                thr = default_threshold(name)
            model = clone(proto).fit(Xtr, ytr)
            sc = get_score(model, Xte)
            s = store.setdefault(name, dict(y=[], g=[], fold=[], score=[], pred_t=[], pred_d=[]))
            s["y"].append(yte); s["g"].append(g[te]); s["fold"].append(np.full(te.sum(), k))
            s["score"].append(sc)
            s["pred_t"].append((sc >= thr).astype(int))
            s["pred_d"].append((sc >= default_threshold(name)).astype(int))
            thr_store.setdefault(name, {})[int(k)] = thr
            clf = model.named_steps["clf"]
            if extras and hasattr(clf, "feature_importances_"):
                imp_store.setdefault(name, []).append(clf.feature_importances_)
            if extras and name == "XGBoost" and HAS_SHAP:
                try:
                    idx = rng.choice(len(Xte), size=min(500, len(Xte)), replace=False)
                    Xs = model.named_steps["imp"].transform(Xte[idx])
                    sv = shap.TreeExplainer(clf).shap_values(Xs)
                    shap_vals.append(np.asarray(sv)); shap_X.append(Xs)
                except Exception:
                    LOG.error("SHAP failed in fold %s:\n%s", k, traceback.format_exc())
            LOG.info("[%s] fold %s %-12s thr=%.4g (%.1fs)", tag, k, name, thr, time.time() - t0)

    res = {}
    for name, s in store.items():
        c = {k: np.concatenate(v) for k, v in s.items()}
        pooled_t = compute_metrics(c["y"], c["pred_t"], c["score"])
        pooled_d = compute_metrics(c["y"], c["pred_d"], c["score"])
        per_fold = []
        for k in sorted(np.unique(c["fold"])):
            mk = c["fold"] == k
            row = compute_metrics(c["y"][mk], c["pred_t"][mk], c["score"][mk])
            row.update(fold=int(k), threshold=thr_store[name][int(k)])
            per_fold.append(row)
        pf = pd.DataFrame(per_fold)
        pooled_t["roc_auc_mean_per_fold"] = float(pf["roc_auc"].mean())
        res[name] = dict(c=c, pooled_tuned=pooled_t, pooled_default=pooled_d,
                         per_fold=pf, thresholds=thr_store[name],
                         ci=group_bootstrap(c["y"], c["pred_t"], c["g"]))
    return res, imp_store, shap_vals, shap_X


def summarise_binary(res, tag, out):
    rows, rows_d = [], []
    for name, r in res.items():
        for lst, key in ((rows, "pooled_tuned"), (rows_d, "pooled_default")):
            d = dict(model=name, **r[key])
            lst.append(d)
        r["per_fold"].to_csv(out / f"per_fold_metrics_{name}_{tag}.csv", index=False)
    full = pd.DataFrame(rows)
    full.to_csv(out / f"pooled_metrics_full_{tag}.csv", index=False)
    pd.DataFrame(rows_d).to_csv(out / f"pooled_metrics_default_threshold_{tag}.csv", index=False)
    cols = ["model", "accuracy", "balanced_accuracy", "macro_f1", "recall_attack",
            "recall_genuine", "fpr", "fnr", "roc_auc", "pr_auc_genuine"]
    comp = full[cols]
    comp.to_csv(out / f"model_comparison_{tag}.csv", index=False)
    for name, r in res.items():
        y, p = r["c"]["y"], r["c"]["pred_t"]
        txt = classification_report(y, p, labels=[0, 1], target_names=["Genuine(0)", "Attack(1)"],
                                    digits=4, zero_division=0)
        cm = confusion_matrix(y, p, labels=[0, 1])
        (out / f"classification_report_{name}_{tag}.txt").write_text(
            f"Pooled leave-one-fold-out test predictions, tag={tag}, model={name}\n"
            f"Positive class = Attack(1). Threshold chosen on training folds only.\n\n"
            f"{txt}\nConfusion matrix (rows=true, cols=pred; order Genuine, Attack):\n{cm}\n")
    return comp, full


def plot_confusion(res, tag, out):
    names = list(res)
    fig, axes = plt.subplots(1, len(names), figsize=(3.6 * len(names), 3.4))
    axes = np.atleast_1d(axes)
    for ax, n in zip(axes, names):
        cm = confusion_matrix(res[n]["c"]["y"], res[n]["c"]["pred_t"], labels=[0, 1])
        ax.imshow(cm, cmap="Blues")
        for i in range(2):
            for j in range(2):
                ax.text(j, i, f"{cm[i, j]}", ha="center", va="center",
                        color="white" if cm[i, j] > cm.max() / 2 else "black")
        ax.set_xticks([0, 1], ["Genuine", "Attack"]); ax.set_yticks([0, 1], ["Genuine", "Attack"])
        ax.set_xlabel("Predicted"); ax.set_ylabel("True"); ax.set_title(n, fontsize=10)
    fig.tight_layout(); fig.savefig(out / f"confusion_matrices_{tag}.png", dpi=150); plt.close(fig)


def save_importance(imp_store, feats, out):
    for name, arrs in imp_store.items():
        a = np.vstack(arrs)
        t = pd.DataFrame({"feature": feats, "importance_mean": a.mean(0),
                          "importance_std_across_folds": a.std(0)}
                         ).sort_values("importance_mean", ascending=False)
        t.insert(0, "rank", range(1, len(t) + 1))
        kind = "gain" if name == "XGBoost" else "impurity (MDI)"
        t["importance_type"] = kind
        t.to_csv(out / f"feature_importance_{name}.csv", index=False)
        top = t.head(20)[::-1]
        fig, ax = plt.subplots(figsize=(7, 6))
        ax.barh(top["feature"], top["importance_mean"], xerr=top["importance_std_across_folds"])
        ax.set_xlabel(f"Mean {kind} importance (± SD over 5 outer-fold models)")
        ax.set_title(f"{name}: top-20 features")
        fig.tight_layout(); fig.savefig(out / f"feature_importance_{name}.png", dpi=150); plt.close(fig)


def save_shap(shap_vals, shap_X, feats, out):
    if not shap_vals:
        return
    sv, X = np.vstack(shap_vals), np.vstack(shap_X)
    t = pd.DataFrame({"feature": feats, "mean_abs_shap": np.abs(sv).mean(0)}
                     ).sort_values("mean_abs_shap", ascending=False)
    t.insert(0, "rank", range(1, len(t) + 1))
    t.to_csv(out / "shap_importance_XGBoost.csv", index=False)
    plt.figure()
    shap.summary_plot(sv, X, feature_names=feats, show=False, max_display=20)
    plt.tight_layout(); plt.savefig(out / "shap_summary_XGBoost.png", dpi=150); plt.close()


def fit_and_save_final(df, feats, res, out):
    Xv = df[feats].replace([np.inf, -np.inf], np.nan).values.astype(float)
    y = df[TARGET].values.astype(int)
    for name, model in make_models(y).items():
        model.fit(Xv, y)
        thr = float(np.median(list(res[name]["thresholds"].values()))) if name in res \
            else default_threshold(name)
        joblib.dump({"model": model, "features": feats, "threshold": thr,
                     "positive_class": "attack (label=1)"}, out / f"model_{name}.joblib")
        if name == "XGBoost":
            model.named_steps["clf"].save_model(str(out / "xgboost_model.json"))
        LOG.info("saved %s (threshold %.4g)", name, thr)


# --------------------------------------------------------------------------
# 5. multiclass experiment
# --------------------------------------------------------------------------
def run_multiclass(df, feats, out, min_support=30):
    Xv = df[feats].replace([np.inf, -np.inf], np.nan).values.astype(float)
    ys = df[ATTACK_COL].values
    folds = df["fold"].values
    classes = sorted(np.unique(ys))
    protos = {}
    imp = lambda: ("imp", SimpleImputer(strategy="median"))
    if HAS_XGB:
        protos["XGBoost"] = Pipeline([imp(), ("clf", XGBClassifier(
            n_estimators=300, max_depth=5, learning_rate=0.05, subsample=0.8,
            colsample_bytree=0.8, objective="multi:softprob", eval_metric="mlogloss",
            random_state=SEED, tree_method="hist", n_jobs=-1))])
    protos["RandomForest"] = Pipeline([imp(), ("clf", RandomForestClassifier(
        n_estimators=300, class_weight="balanced_subsample", n_jobs=-1, random_state=SEED))])
    summary = []
    for name, proto in protos.items():
        pred = np.empty(len(ys), dtype=object)
        for k in sorted(np.unique(folds)):
            te, tr = folds == k, folds != k
            le = LabelEncoder().fit(ys[tr])           # classes absent from training -> never predicted
            m = clone(proto)
            if name == "XGBoost":
                sw = compute_sample_weight("balanced", ys[tr])
                m.fit(Xv[tr], le.transform(ys[tr]), clf__sample_weight=sw)
            else:
                m.fit(Xv[tr], le.transform(ys[tr]))
            pred[te] = le.inverse_transform(m.predict(Xv[te]).astype(int))
            LOG.info("[multiclass] %s fold %s done", name, k)
        rep = classification_report(ys, pred, labels=classes, output_dict=True, zero_division=0)
        t = pd.DataFrame({c: rep[c] for c in classes}).T[["precision", "recall", "f1-score", "support"]]
        t["support"] = t["support"].astype(int)
        t["adequate_support(>=%d)" % min_support] = t["support"] >= min_support
        t.to_csv(out / f"multiclass_per_class_{name}.csv")
        cm = confusion_matrix(ys, pred, labels=classes)
        pd.DataFrame(cm, index=classes, columns=classes).to_csv(out / f"multiclass_confusion_{name}.csv")
        fig, ax = plt.subplots(figsize=(10, 9))
        cmn = cm / np.maximum(cm.sum(1, keepdims=True), 1)
        ax.imshow(cmn, cmap="Blues", vmin=0, vmax=1)
        ax.set_xticks(range(len(classes)), classes, rotation=90, fontsize=7)
        ax.set_yticks(range(len(classes)), classes, fontsize=7)
        ax.set_xlabel("Predicted"); ax.set_ylabel("True")
        ax.set_title(f"{name}: row-normalised multiclass confusion (pooled held-out folds)")
        fig.tight_layout(); fig.savefig(out / f"multiclass_confusion_{name}.png", dpi=150); plt.close(fig)
        ok = t["support"] >= min_support
        summary.append(dict(
            model=name, accuracy=float(np.mean(ys == pred)),
            macro_f1_all_classes=float(t["f1-score"].mean()),
            macro_f1_classes_support_ge_30=float(t.loc[ok, "f1-score"].mean()),
            weighted_f1=float(rep["weighted avg"]["f1-score"]),
            n_classes=len(classes), n_classes_low_support=int((~ok).sum())))
    s = pd.DataFrame(summary)
    s.to_csv(out / "multiclass_summary.csv", index=False)
    return s


# --------------------------------------------------------------------------
# main
# --------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="two_bsm_clean.csv")
    ap.add_argument("--out", default="outputs")
    ap.add_argument("--skip-svm", action="store_true")
    ap.add_argument("--skip-ablations", action="store_true")
    ap.add_argument("--template", default="report_random_forest.docx",
                    help="Word report to use as the layout template for the XGBoost report")
    args = ap.parse_args()
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s",
                        handlers=[logging.StreamHandler(sys.stdout),
                                  logging.FileHandler(out / "run_log.txt", mode="w", encoding="utf-8")])
    LOG.info("xgboost available: %s %s", HAS_XGB, XGB_ERR if not HAS_XGB else xgboost.__version__)
    LOG.info("shap available: %s %s", HAS_SHAP, SHAP_ERR)
    if not HAS_XGB:
        LOG.warning("XGBoost is NOT installed: no XGBoost results will be produced. "
                    "Run `pip install -r requirements.txt` and re-run.")
    try:
        df = pd.read_csv(args.data)
    except Exception:
        LOG.error("Cannot read %s\n%s", args.data, traceback.format_exc()); sys.exit(1)
    missing = {TARGET, ATTACK_COL, "reported_id", "fold"} - set(df.columns)
    if missing:
        LOG.error("Missing expected columns: %s", missing); sys.exit(1)
    feats = [c for c in df.columns if c.startswith("bsm")]
    assert not set(feats) & {TARGET, ATTACK_COL, "reported_id", "fold"}
    non_num = [c for c in feats if not pd.api.types.is_numeric_dtype(df[c])]
    if non_num:
        LOG.error("Non-numeric input features: %s", non_num); sys.exit(1)

    stage("1. dataset analysis")(analyse_dataset)(df, feats, out)

    time_cols = [c for c in feats if c.endswith(("creation_time", "arrival_time"))]
    pos_cols = [c for c in feats if c.endswith(("pos_x", "pos_y"))]
    settings = {"primary": (df, feats)}
    if not args.skip_ablations:
        f2 = [c for c in feats if c not in time_cols]
        f3 = [c for c in f2 if c not in pos_cols]
        settings["no_abs_time"] = (df, f2)
        settings["no_abs_time_pos"] = (df, f3)
        settings["dedup_rows"] = (df.drop_duplicates().reset_index(drop=True), feats)

    all_comp = {}
    primary_res = None
    for tag, (d, f) in settings.items():
        r = stage(f"2. binary leave-one-fold-out [{tag}]")(run_binary)(
            d, f, tag, extras=(tag == "primary"), skip_svm=args.skip_svm)
        if r is None:
            continue
        res, imp_store, shap_vals, shap_X = r
        comp, full = summarise_binary(res, tag, out)
        all_comp[tag] = comp.assign(setting=tag)
        LOG.info("\n%s", md_table(comp))
        if tag == "primary":
            primary_res = res
            plot_confusion(res, tag, out)
            stage("feature importance")(save_importance)(imp_store, f, out)
            stage("SHAP")(save_shap)(shap_vals, shap_X, f, out)
            ci_rows = [dict(model=n, **{f"{k}_95CI": f"[{v[0]:.4f}, {v[1]:.4f}]"
                                         for k, v in rr["ci"].items()}) for n, rr in res.items()]
            pd.DataFrame(ci_rows).to_csv(out / "group_bootstrap_CI_primary.csv", index=False)
            stage("save final models")(fit_and_save_final)(d, f, res, out)
    if all_comp:
        pd.concat(all_comp.values()).to_csv(out / "all_settings_comparison.csv", index=False)

    mc = stage("3. multiclass attack_type")(run_multiclass)(df, feats, out)

    # ---- auto-generated results summary (numbers copied from the CSVs) ----
    lines = ["# Auto-generated results summary", "",
             f"XGBoost installed in this run: **{HAS_XGB}**  |  SHAP installed: **{HAS_SHAP}**", ""]
    for tag, comp in all_comp.items():
        lines += [f"## Binary detection - {tag} (pooled over 5 held-out folds, positive = attack)", "",
                  md_table(comp.drop(columns="setting")), ""]
    if mc is not None:
        lines += ["## Multiclass (attack_type)", "", md_table(mc), ""]
    (out / "results_summary.md").write_text("\n".join(lines), encoding="utf-8")
    if HAS_XGB:
        try:
            from make_report_xgboost import build_report
            setting = "primary" if args.skip_ablations else "dedup_rows"
            build_report(out, args.template, "XGBoost", setting, "default",
                         out / "report_xgboost.docx")
        except SystemExit as e:
            LOG.error("Word report not created: %s", e)
        except Exception:
            LOG.error("Word report failed:\n%s", traceback.format_exc())
    LOG.info("Done. Outputs in %s", out.resolve())


if __name__ == "__main__":
    main()
