VANET SYBIL ATTACK DETECTION - PART 2: DECISION TREE MODEL IMPLEMENTATION
=========================================================================
Task: binary classification, 0 = Genuine, 1 = Sybil (positive class = Sybil), using scikit-learn's
DecisionTreeClassifier on the verified Part 1 preprocessing outputs. Part 1 files are used unchanged and the
Part 1 train/test split is never replaced. No Random Forest / KNN code, models or results are used.

QUICK START (from this folder)
  pip install -r requirements.txt
  python decision_tree_implementation.py
Runtime is about 15 seconds. On the first run the bundled archive Decision_Tree_Sybil_Preprocessing.zip is
extracted next to the script (folder Decision_Tree_Sybil_Preprocessing/); the original zip is never modified.
Optional arguments:
  --data-dir DIR       folder containing X_train.csv, X_test.csv, y_train.csv, y_test.csv, *_metadata.csv, ...
  --output-dir DIR     where to write results (default: this folder)
  --seed 42            random seed (default 42)
  --cv-folds 5         grouped CV folds for tuning (needs >= that many genuine senders in the training data)
  --n-configs 60       sampled hyperparameter configurations (the two reference configs are always added)
  --tree-plot-depth 3  levels drawn in decision_tree_visualization.png
Exit code 0 means all validation checks passed (they are listed in execution_log.txt).
Re-running overwrites all outputs; results are deterministic for the same package versions.

WHAT THE SCRIPT DOES
  1. Inspects the Part 1 data (shapes, feature order, binary target, no sender in both splits, no leakage columns,
     missing indicators, processed-CSV consistency) and stops without changing anything if a check fails.
  2. Trains a baseline tree (class_weight=None) and a class-weighted tree (class_weight='balanced'), seed 42.
  3. Tunes with grouped, class-stratified CV on the TRAINING data only (groups = reported_id; one genuine sender
     per validation fold; selection metric = pooled out-of-fold macro-F1), refits the winner on the full training
     set and evaluates it once on the test set.
  4. Missing-indicator ablation: all 56 features vs 54 features without bsm1_delay_was_missing and
     bsm2_delay_was_missing, plus diagnostics (indicator usage, neutralised-column control, seed sensitivity).
  5. Writes metrics, plots, feature importances, a report and a validation log.
The test set is used only to evaluate models whose configuration was fixed beforehand.

FILES
  Code / setup:  decision_tree_implementation.py, requirements.txt, README.txt
  Input archive: Decision_Tree_Sybil_Preprocessing.zip (original Part 1 package, unmodified)
  Models:        decision_tree_baseline.joblib, decision_tree_balanced.joblib, decision_tree_best.joblib
                 (scikit-learn objects fitted on pandas DataFrames: feature_names_in_ holds the 56 feature names in the
                 order of feature_columns.json; call predict on X[feature_columns])
  Metrics:       baseline_metrics.json, balanced_metrics.json, best_model_metrics.json, classification_report.txt,
                 model_comparison.csv, hyperparameter_tuning_results.csv (CV results, training data only),
                 missing_indicator_ablation.csv, ablation_seed_sensitivity.csv, feature_importance.csv,
                 selected_tree_rules.txt
  Extra:         test_predictions.csv (per-row test predictions and Sybil probabilities; row_id/reported_id/attack_type
                 are metadata for tracing, not model inputs), error_analysis_by_attack_type.csv,
                 error_analysis_genuine_senders.csv (descriptive only)
  Plots:         confusion_matrix.png (selected model), decision_tree_visualization.png (TRUNCATED to the top levels - the
                 title says so), feature_importance.png, roc_curve.png, precision_recall_curve.png,
                 plots/confusion_matrix_{baseline,balanced,best}.png, plots/missing_indicator_ablation.png
  Documentation: implementation_report.txt, execution_log.txt, model_configuration.json

IMPORTANT CAVEATS (details in implementation_report.txt)
  - Only 8 genuine senders exist (5 in train, 3 in test, 28 genuine test rows): genuine-class metrics are unstable and
    the test result is likely optimistic compared with the grouped CV on the training data.
  - Results do not establish performance on other VANET environments, simulators or real deployments.
  - Tree feature importance is not causal evidence; correlated features share importance.
