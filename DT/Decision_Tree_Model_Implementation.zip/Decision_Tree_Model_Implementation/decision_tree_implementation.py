#!/usr/bin/env python3
"""
Part 2 - Decision Tree classifier for VANET Sybil attack detection (Genuine vs Sybil).

Uses the verified Part 1 preprocessing outputs (Decision_Tree_Sybil_Preprocessing) as the source of truth.
No new train/test split is made, nothing is re-preprocessed, and the test set is never used to fit,
tune or select anything. The test set is only used for the final evaluation of the already-chosen models.

Run (from this folder):
    pip install -r requirements.txt
    python decision_tree_implementation.py
Optional:
    --data-dir DIR     folder with X_train.csv ... (default: ./Decision_Tree_Sybil_Preprocessing, extracted from the
                       bundled ZIP automatically if the folder does not exist)
    --output-dir DIR   where results are written (default: the folder of this script)
    --seed 42          random seed
    --cv-folds 5       number of grouped CV folds for tuning
    --n-configs 60     number of sampled hyperparameter configurations (+ the 2 reference configurations)
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import logging
import platform
import random
import sys
import time
import zipfile
from pathlib import Path

import joblib
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import sklearn
from sklearn.metrics import (accuracy_score, auc, average_precision_score, balanced_accuracy_score,
                             classification_report, confusion_matrix, f1_score, matthews_corrcoef,
                             precision_recall_curve, precision_recall_fscore_support, roc_auc_score, roc_curve)
from sklearn.tree import DecisionTreeClassifier, export_text, plot_tree

CLASS_NAMES = {0: "Genuine", 1: "Sybil"}
LABELS = [0, 1]
MISSING_INDICATORS = ["bsm1_delay_was_missing", "bsm2_delay_was_missing"]
REQUIRED_INPUTS = ["class_distribution.csv", "X_train.csv", "X_test.csv", "y_train.csv", "y_test.csv", "train_metadata.csv",
                   "test_metadata.csv", "feature_columns.json", "target_mapping.json",
                   "preprocessing_config.json", "preprocessing_report.txt", "README.txt"]
OPTIONAL_INPUTS = ["preprocessor.joblib", "train_processed.csv", "test_processed.csv"]
# Columns that must never be model inputs (target / identifiers / attack labels / absolute clocks).
FORBIDDEN_EXACT = {"label", "attack_type", "source_label", "row_id", "reported_id", "fold",
                   "bsm1_creation_time", "bsm1_arrival_time", "bsm2_creation_time", "bsm2_arrival_time"}
FORBIDDEN_SUBSTR = ["attack", "label", "reported_id", "row_id"]
BASELINE_PARAMS = dict(criterion="gini", max_depth=None, min_samples_split=2, min_samples_leaf=1,
                       class_weight=None)
BALANCED_PARAMS = dict(BASELINE_PARAMS, class_weight="balanced")
SEARCH_SPACE = {
    "max_depth": [3, 5, 10, 15, None],
    "min_samples_split": [2, 5, 10],
    "min_samples_leaf": [1, 2, 5, 10],
    "criterion": ["gini", "entropy"],
    "class_weight": [None, "balanced"],
}
LOG = logging.getLogger("dt")


# ----------------------------------------------------------------------------------------------------------
# Utilities
# ----------------------------------------------------------------------------------------------------------
def setup_logging(path: Path) -> None:
    LOG.setLevel(logging.INFO)
    LOG.handlers.clear()
    fmt = logging.Formatter("%(asctime)s | %(message)s", "%H:%M:%S")
    for h in (logging.StreamHandler(sys.stdout), logging.FileHandler(path, mode="w", encoding="utf-8")):
        h.setFormatter(fmt)
        LOG.addHandler(h)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def jdump(obj, path: Path) -> None:
    def default(o):
        if isinstance(o, (np.integer,)):
            return int(o)
        if isinstance(o, (np.floating,)):
            return None if np.isnan(o) else float(o)
        if isinstance(o, np.ndarray):
            return o.tolist()
        return str(o)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, default=default)


def params_key(p: dict) -> str:
    return json.dumps({k: p[k] for k in sorted(p)}, sort_keys=True, default=str)


# ----------------------------------------------------------------------------------------------------------
# 1. Loading and validating the Part 1 archive
# ----------------------------------------------------------------------------------------------------------
def resolve_data_dir(arg: str | None, script_dir: Path) -> Path:
    data_dir = Path(arg) if arg else script_dir / "Decision_Tree_Sybil_Preprocessing"
    if not (data_dir / "X_train.csv").exists():
        zp = script_dir / "Decision_Tree_Sybil_Preprocessing.zip"
        if arg is None and zp.exists():
            LOG.info("Extracting bundled archive %s -> %s", zp.name, script_dir)
            with zipfile.ZipFile(zp) as z:
                z.extractall(script_dir)
        else:
            raise FileNotFoundError(f"Preprocessing folder not found: {data_dir}")
    return data_dir


def load_inputs(data_dir: Path) -> dict:
    missing = [f for f in REQUIRED_INPUTS if not (data_dir / f).exists()]
    if missing:
        raise FileNotFoundError(f"Missing required preprocessing files: {missing}")
    d = {
        "X_train": pd.read_csv(data_dir / "X_train.csv"),
        "X_test": pd.read_csv(data_dir / "X_test.csv"),
        "y_train": pd.read_csv(data_dir / "y_train.csv")["label"],
        "y_test": pd.read_csv(data_dir / "y_test.csv")["label"],
        "meta_train": pd.read_csv(data_dir / "train_metadata.csv"),
        "meta_test": pd.read_csv(data_dir / "test_metadata.csv"),
        "feature_columns": json.load(open(data_dir / "feature_columns.json")),
        "target_mapping": json.load(open(data_dir / "target_mapping.json")),
        "pp_config": json.load(open(data_dir / "preprocessing_config.json")),
    }
    return d


def check(results: list, name: str, ok: bool, detail: str = "") -> bool:
    results.append((name, bool(ok), detail))
    LOG.info("[%s] %s %s", "PASS" if ok else "FAIL", name, f"({detail})" if detail else "")
    return bool(ok)


def validate_inputs(d: dict, data_dir: Path) -> list:
    """Archive inspection (task section 2). Nothing is modified; problems are reported as FAIL."""
    res: list = []
    Xtr, Xte, ytr, yte = d["X_train"], d["X_test"], d["y_train"], d["y_test"]
    mtr, mte, fc = d["meta_train"], d["meta_test"], d["feature_columns"]
    check(res, "input: required files present", True, f"{len(REQUIRED_INPUTS)} required files found")
    check(res, "input: optional files present",
          all((data_dir / f).exists() for f in OPTIONAL_INPUTS),
          ", ".join(f"{f}={(data_dir / f).exists()}" for f in OPTIONAL_INPUTS))
    check(res, "input: shapes consistent (rows X == y == metadata)",
          len(Xtr) == len(ytr) == len(mtr) and len(Xte) == len(yte) == len(mte),
          f"train X{Xtr.shape} y{ytr.shape} meta{mtr.shape}; test X{Xte.shape} y{yte.shape} meta{mte.shape}")
    check(res, "input: sample counts equal preprocessing_config (n_train/n_test/n_features)",
          (len(Xtr), len(Xte), Xtr.shape[1]) == (d["pp_config"]["n_train"], d["pp_config"]["n_test"],
                                                 d["pp_config"]["n_features"]),
          f"{len(Xtr)}/{len(Xte)}/{Xtr.shape[1]}")
    check(res, "input: feature names/order identical in train, test and feature_columns.json",
          list(Xtr.columns) == list(Xte.columns) == list(fc), f"{len(fc)} features")
    check(res, "input: target is binary 0/1 in both splits",
          set(ytr.unique()) <= {0, 1} and set(yte.unique()) <= {0, 1} and ytr.nunique() == 2 and yte.nunique() == 2,
          f"train {ytr.value_counts().sort_index().to_dict()}, test {yte.value_counts().sort_index().to_dict()}")
    tm = d["target_mapping"]["mapping"]
    check(res, "input: target mapping is 0=Genuine, 1=Sybil",
          tm["0"]["name"] == "Genuine" and tm["1"]["name"] == "Sybil")
    leak = sorted(c for c in Xtr.columns
                  if c in FORBIDDEN_EXACT or any(s in c.lower() for s in FORBIDDEN_SUBSTR))
    check(res, "input: no target / attack-family / id / metadata columns among features", not leak,
          f"offending: {leak}" if leak else "none found")
    check(res, "input: metadata columns are not in X",
          not (set(mtr.columns) & set(Xtr.columns)), f"metadata columns: {list(mtr.columns)}")
    check(res, "input: metadata matches target (attack_type Genuine <-> label 0)",
          bool(((mtr["attack_type"] == "Genuine") == (ytr == 0)).all()
               and ((mte["attack_type"] == "Genuine") == (yte == 0)).all()))
    overlap = set(mtr["reported_id"]) & set(mte["reported_id"])
    check(res, "input: no sender (reported_id) in both train and test", not overlap,
          f"{mtr['reported_id'].nunique()} train senders, {mte['reported_id'].nunique()} test senders")
    check(res, "input: no NaN/inf and all numeric in X",
          bool(np.isfinite(Xtr.to_numpy(float)).all() and np.isfinite(Xte.to_numpy(float)).all()))
    ind = [c for c in Xtr.columns if c.endswith("_was_missing")]
    check(res, "input: missing-indicator features found exactly as expected", sorted(ind) == sorted(MISSING_INDICATORS),
          f"{ind}")
    # consistency with the *_processed.csv files (features + label) when available
    for split, X, y in (("train", Xtr, ytr), ("test", Xte, yte)):
        p = data_dir / f"{split}_processed.csv"
        if p.exists():
            pr = pd.read_csv(p)
            same = list(pr.columns) == list(X.columns) + ["label"] and np.allclose(
                pr[list(X.columns)].to_numpy(float), X.to_numpy(float)) and (pr["label"].to_numpy() == y.to_numpy()).all()
            check(res, f"input: {split}_processed.csv equals X_{split}/y_{split}", bool(same))
    pj = data_dir / "preprocessor.joblib"
    if pj.exists():
        try:
            pp = joblib.load(pj)
            ok = isinstance(pp, dict) and list(pp.get("output_columns", [])) == list(fc)
            check(res, "input: preprocessor.joblib readable and output_columns == feature_columns", ok,
                  "loaded for inspection only (not used to transform data)")
        except Exception as e:  # pragma: no cover
            check(res, "input: preprocessor.joblib readable", False, repr(e))
    return res


# ----------------------------------------------------------------------------------------------------------
# 2. Metrics
# ----------------------------------------------------------------------------------------------------------
def compute_metrics(y_true, y_pred, y_score) -> dict:
    """All metrics; class 1 (Sybil) is the positive class. Undefined metrics are reported honestly."""
    y_true, y_pred, y_score = np.asarray(y_true), np.asarray(y_pred), np.asarray(y_score)
    p, r, f, s = precision_recall_fscore_support(y_true, y_pred, labels=LABELS, zero_division=0)
    pm, rm, fm, _ = precision_recall_fscore_support(y_true, y_pred, labels=LABELS, average="macro", zero_division=0)
    pw, rw, fw, _ = precision_recall_fscore_support(y_true, y_pred, labels=LABELS, average="weighted", zero_division=0)
    cm = confusion_matrix(y_true, y_pred, labels=LABELS)
    tn, fp, fn, tp = (int(v) for v in cm.ravel())
    undefined = []
    for c in LABELS:
        if (y_pred == c).sum() == 0:
            undefined.append(f"precision_{CLASS_NAMES[c]} undefined (no predictions of this class) -> reported as 0.0")
        if (y_true == c).sum() == 0:
            undefined.append(f"recall_{CLASS_NAMES[c]} undefined (no true samples of this class) -> reported as 0.0")
    denom = np.sqrt(float(tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    if denom == 0:
        undefined.append("MCC undefined (a row or column of the confusion matrix is empty) -> reported as 0.0")
    out = {
        "n_samples": int(len(y_true)),
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "balanced_accuracy": float(balanced_accuracy_score(y_true, y_pred)),
        "precision_genuine": float(p[0]), "precision_sybil": float(p[1]),
        "recall_genuine": float(r[0]), "recall_sybil": float(r[1]),
        "f1_genuine": float(f[0]), "f1_sybil": float(f[1]),
        "support_genuine": int(s[0]), "support_sybil": int(s[1]),
        "macro_precision": float(pm), "macro_recall": float(rm), "macro_f1": float(fm),
        "weighted_precision": float(pw), "weighted_recall": float(rw), "weighted_f1": float(fw),
        "mcc": float(matthews_corrcoef(y_true, y_pred)),
        "confusion_matrix_[[TN,FP],[FN,TP]]": cm.tolist(),
        "true_negatives_genuine_correct": tn, "false_positives_genuine_flagged_as_sybil": fp,
        "false_negatives_sybil_missed": fn, "true_positives_sybil_detected": tp,
        "false_alarm_rate_on_genuine": float(fp / (tn + fp)) if (tn + fp) else None,
        "miss_rate_on_sybil": float(fn / (fn + tp)) if (fn + tp) else None,
        "roc_auc": None, "pr_auc_average_precision": None, "pr_auc_trapezoid": None,
        "classification_report": classification_report(y_true, y_pred, labels=LABELS,
                                                       target_names=["Genuine", "Sybil"], digits=4, zero_division=0),
        "undefined_or_degenerate_metrics": undefined,
    }
    if len(np.unique(y_true)) == 2:
        out["roc_auc"] = float(roc_auc_score(y_true, y_score))
        out["pr_auc_average_precision"] = float(average_precision_score(y_true, y_score))
        pr, rc, _ = precision_recall_curve(y_true, y_score)
        out["pr_auc_trapezoid"] = float(auc(rc, pr))
    else:
        undefined.append("ROC-AUC / PR-AUC undefined (only one class in y_true)")
    return out


def flat(m: dict) -> dict:
    keep = ["accuracy", "balanced_accuracy", "precision_genuine", "recall_genuine", "f1_genuine",
            "precision_sybil", "recall_sybil", "f1_sybil", "macro_precision", "macro_recall", "macro_f1",
            "weighted_precision", "weighted_recall", "weighted_f1", "mcc", "roc_auc", "pr_auc_average_precision",
            "pr_auc_trapezoid", "true_negatives_genuine_correct", "false_positives_genuine_flagged_as_sybil",
            "false_negatives_sybil_missed", "true_positives_sybil_detected", "false_alarm_rate_on_genuine",
            "miss_rate_on_sybil"]
    return {k: m[k] for k in keep}


# ----------------------------------------------------------------------------------------------------------
# 3. Grouped, class-stratified cross-validation on the TRAINING data only
# ----------------------------------------------------------------------------------------------------------
def make_grouped_stratified_folds(y: pd.Series, groups: pd.Series, n_splits: int, seed: int):
    """Deterministic grouped CV in which every fold gets >=1 genuine sender and a similar number of rows.

    Genuine senders are spread one-per-fold (largest first). Sybil senders are shuffled (seeded), then
    assigned largest-first to the fold with the fewest rows so far. A sender is therefore in exactly one
    validation fold. Raises if a valid split is impossible (fewer genuine senders than folds).
    """
    y = np.asarray(y)
    g = np.asarray(groups)
    sender_label = pd.DataFrame({"g": g, "y": y}).groupby("g")["y"].agg(["min", "max", "size"])
    if (sender_label["min"] != sender_label["max"]).any():
        raise ValueError("A sender has rows of both classes; grouped stratification is not possible.")
    gen = sender_label[sender_label["min"] == 0]["size"].sort_values(ascending=False, kind="stable")
    syb = sender_label[sender_label["min"] == 1]["size"]
    if len(gen) < n_splits:
        raise ValueError(f"Only {len(gen)} genuine senders in training data: cannot build {n_splits} grouped folds "
                         "that all contain a genuine sender.")
    fold_of: dict = {}
    fold_rows = np.zeros(n_splits, dtype=int)
    fold_gen_rows = np.zeros(n_splits, dtype=int)
    for sender, size in gen.items():  # genuine: one sender per fold first, then fewest genuine rows
        k = int(np.argmin(fold_gen_rows))
        fold_of[sender] = k
        fold_rows[k] += size
        fold_gen_rows[k] += size
    order = list(syb.index)
    random.Random(seed).shuffle(order)
    order.sort(key=lambda s: -syb[s])  # stable: ties keep the seeded shuffle order
    for sender in order:
        k = int(np.argmin(fold_rows))
        fold_of[sender] = k
        fold_rows[k] += syb[sender]
    fold_idx = np.array([fold_of[s] for s in g])
    folds = []
    for k in range(n_splits):
        va = np.where(fold_idx == k)[0]
        tr = np.where(fold_idx != k)[0]
        folds.append((tr, va))
    return folds


def check_folds(folds, y, groups) -> tuple[bool, str]:
    y, groups = np.asarray(y), np.asarray(groups)
    msgs, ok = [], True
    all_val = np.concatenate([va for _, va in folds])
    ok &= len(all_val) == len(np.unique(all_val)) == len(y)
    for k, (tr, va) in enumerate(folds):
        leak = set(groups[tr]) & set(groups[va])
        both = set(np.unique(y[va])) == {0, 1} and set(np.unique(y[tr])) == {0, 1}
        ok &= (not leak) and both
        msgs.append(f"fold{k}: val rows={len(va)} (genuine {(y[va] == 0).sum()}, sybil {(y[va] == 1).sum()}), "
                    f"val senders={len(set(groups[va]))}, sender-overlap={len(leak)}")
    return bool(ok), "; ".join(msgs)


def cv_evaluate(params: dict, X: pd.DataFrame, y: pd.Series, folds, seed: int) -> dict:
    oof_pred = np.full(len(y), -1, dtype=int)
    oof_score = np.zeros(len(y))
    per_fold, leaves = [], []
    for tr, va in folds:
        m = DecisionTreeClassifier(**params, random_state=seed).fit(X.iloc[tr], y.iloc[tr])
        pred = m.predict(X.iloc[va])
        oof_pred[va] = pred
        oof_score[va] = m.predict_proba(X.iloc[va])[:, 1]
        yv = y.iloc[va]
        per_fold.append({
            "macro_f1": f1_score(yv, pred, average="macro", labels=LABELS, zero_division=0),
            "balanced_accuracy": balanced_accuracy_score(yv, pred),
            "recall_genuine": float(((pred == 0) & (yv == 0)).sum() / max((yv == 0).sum(), 1)),
            "recall_sybil": float(((pred == 1) & (yv == 1)).sum() / max((yv == 1).sum(), 1)),
        })
        leaves.append(m.get_n_leaves())
    assert (oof_pred >= 0).all()
    pf = pd.DataFrame(per_fold)
    pooled = compute_metrics(y, oof_pred, oof_score)
    return {
        "oof_macro_f1": pooled["macro_f1"], "oof_balanced_accuracy": pooled["balanced_accuracy"],
        "oof_mcc": pooled["mcc"], "oof_recall_genuine": pooled["recall_genuine"],
        "oof_recall_sybil": pooled["recall_sybil"], "oof_precision_sybil": pooled["precision_sybil"],
        "mean_fold_macro_f1": pf["macro_f1"].mean(), "std_fold_macro_f1": pf["macro_f1"].std(ddof=0),
        "mean_fold_balanced_accuracy": pf["balanced_accuracy"].mean(),
        "min_fold_recall_genuine": pf["recall_genuine"].min(), "mean_fold_recall_sybil": pf["recall_sybil"].mean(),
        "mean_n_leaves": float(np.mean(leaves)),
    }


def run_tuning(X, y, groups, folds, seed, n_configs):
    grid = [dict(zip(SEARCH_SPACE, v)) for v in itertools.product(*SEARCH_SPACE.values())]
    rng = random.Random(seed)
    sampled = rng.sample(grid, min(n_configs, len(grid)))
    seen = {params_key(p) for p in sampled}
    for ref in (BASELINE_PARAMS, BALANCED_PARAMS):  # reference configs are always evaluated
        if params_key(ref) not in seen:
            sampled.append(dict(ref))
    LOG.info("Tuning: grid size %d, evaluating %d configurations x %d grouped folds", len(grid), len(sampled), len(folds))
    rows = []
    for i, p in enumerate(sampled):
        r = cv_evaluate(p, X, y, folds, seed)
        rows.append({"config_id": i, **{k: ("None" if v is None else v) for k, v in p.items()}, **r})
    df = pd.DataFrame(rows)
    df["_leaves"] = df["mean_n_leaves"]
    df = df.sort_values(["oof_macro_f1", "mean_fold_macro_f1", "_leaves"], ascending=[False, False, True],
                        kind="stable").reset_index(drop=True)
    df["rank"] = np.arange(1, len(df) + 1)
    df = df.drop(columns="_leaves")
    best_row = df.iloc[0]
    best = {k: (None if str(best_row[k]) == "None" else best_row[k]) for k in SEARCH_SPACE}
    best["max_depth"] = None if best["max_depth"] is None else int(best["max_depth"])
    best["min_samples_split"] = int(best["min_samples_split"])
    best["min_samples_leaf"] = int(best["min_samples_leaf"])
    return df, best


def ablation_diagnostics(config_params, models, Xtr, ytr, Xte, yte, feature_columns, no_ind_cols, seed, n_seeds=20):
    """Diagnostics that help to read the ablation (descriptive only, nothing is selected from them).

    1. Do the saved trees use the indicators in any split?
    2. Control C: keep all 56 columns but set the two indicators to a constant 0 in train and test. If the
       indicators are unused, predictions must equal Experiment A's (same column count -> same tie-breaking).
    3. Seed sensitivity: random_state only breaks ties between equally good splits, but this can still change a
       tree. Test balanced accuracy of A and B over seeds 0..n_seeds-1 shows the size of this noise.
    """
    rows, ctrl, used_ind = [], {}, {}
    for n, p in config_params.items():
        m = models[n]
        used = {feature_columns[i] for i in set(m.tree_.feature) if i >= 0}
        used_ind[n] = sorted(used & set(MISSING_INDICATORS))
        Xc_tr, Xc_te = Xtr.copy(), Xte.copy()
        Xc_tr[MISSING_INDICATORS] = 0
        Xc_te[MISSING_INDICATORS] = 0
        mc = DecisionTreeClassifier(**p, random_state=seed).fit(Xc_tr, ytr)
        ctrl[n] = bool((mc.predict(Xc_te) == m.predict(Xte[feature_columns])).all())
        for exp, cols in (("A_full_features", feature_columns), ("B_without_missing_indicators", no_ind_cols)):
            accs = []
            for sd in range(n_seeds):
                mm = DecisionTreeClassifier(**p, random_state=sd).fit(Xtr[cols], ytr)
                accs.append(balanced_accuracy_score(yte, mm.predict(Xte[cols])))
            rows.append({"model_config": n, "experiment": exp, "n_seeds": n_seeds, "seeds": f"0..{n_seeds - 1}",
                         "test_balanced_accuracy_mean": float(np.mean(accs)), "test_balanced_accuracy_std": float(np.std(accs)),
                         "test_balanced_accuracy_min": float(np.min(accs)), "test_balanced_accuracy_max": float(np.max(accs))})
    return pd.DataFrame(rows), ctrl, used_ind


# ----------------------------------------------------------------------------------------------------------
# 4. Plots
# ----------------------------------------------------------------------------------------------------------
def plot_confusion(cm, title, path):
    cm = np.asarray(cm)
    fig, ax = plt.subplots(figsize=(6, 5.2))
    im = ax.imshow(cm, cmap="Blues")
    ax.set_xticks([0, 1], ["Genuine", "Sybil"])
    ax.set_yticks([0, 1], ["Genuine", "Sybil"])
    ax.set_xlabel("Predicted class")
    ax.set_ylabel("Actual class")
    ax.set_title(title, fontsize=11)
    rowsum = cm.sum(axis=1, keepdims=True)
    for i in range(2):
        for j in range(2):
            col = "white" if cm[i, j] > cm.max() / 2 else "black"
            ax.text(j, i, f"{cm[i, j]}", ha="center", va="center", color=col, fontsize=20, fontweight="bold")
            ax.text(j, i + 0.28, f"({100 * cm[i, j] / max(rowsum[i, 0], 1):.1f}% of actual {CLASS_NAMES[i]})",
                    ha="center", va="center", color=col, fontsize=8)
    fig.colorbar(im, ax=ax, fraction=0.046)
    fig.tight_layout()
    fig.savefig(path, dpi=200, bbox_inches="tight")
    plt.close(fig)


def plot_tree_view(model, feature_names, depth_limit, path, title_prefix):
    full_depth = model.get_depth()
    shown = min(depth_limit, full_depth)
    truncated = full_depth > depth_limit
    fig, ax = plt.subplots(figsize=(30, 4.5 + 3.2 * shown))
    plot_tree(model, max_depth=depth_limit, feature_names=list(feature_names), class_names=["Genuine", "Sybil"],
              filled=True, rounded=True, impurity=False, fontsize=9, ax=ax, proportion=False)
    note = (f"TRUNCATED VIEW: top {shown} of {full_depth} levels shown ({model.get_n_leaves()} leaves in the full model)"
            if truncated else f"Full tree: depth {full_depth}, {model.get_n_leaves()} leaves")
    ax.set_title(f"{title_prefix} - {note}\n(value = [Genuine, Sybil] training samples in node; "
                 "'class' = majority class)", fontsize=16)
    fig.tight_layout()
    fig.savefig(path, dpi=130, bbox_inches="tight")
    plt.close(fig)
    return truncated, shown, full_depth


def plot_importance(imp_df, path, top=15, title="Decision Tree feature importance (selected model)"):
    nz = imp_df[imp_df["importance"] > 1e-9]
    top_df = nz.head(top).iloc[::-1]
    colors = ["#d95f02" if f in MISSING_INDICATORS else "#1f77b4" for f in top_df["feature"]]
    fig, ax = plt.subplots(figsize=(9, 0.42 * len(top_df) + 2.2))
    ax.barh(top_df["feature"], top_df["importance"], color=colors)
    for y_, v in enumerate(top_df["importance"]):
        ax.text(v, y_, f" {v:.3f}", va="center", fontsize=8)
    mi = imp_df[imp_df["feature"].isin(MISSING_INDICATORS)]
    mi_txt = "; ".join(f"{r.feature} = {r.importance:.4f} (rank {r.rank})" for r in mi.itertuples())
    ax.set_xlabel("Impurity-based importance (Gini/entropy decrease, sums to 1 over all features)")
    ax.set_title(f"{title}\n{len(top_df)} features with non-zero importance shown; {len(imp_df) - len(nz)} of {len(imp_df)} features have zero importance.\n"
                 f"Missing indicators (orange if shown): {mi_txt}", fontsize=9)
    fig.tight_layout()
    fig.savefig(path, dpi=200, bbox_inches="tight")
    plt.close(fig)


def plot_curves(y_true, scores: dict, roc_path, pr_path):
    y_true = np.asarray(y_true)
    fig, ax = plt.subplots(figsize=(6.5, 6))
    for name, s in scores.items():
        fpr, tpr, _ = roc_curve(y_true, s)
        ax.plot(fpr, tpr, drawstyle="steps-post", label=f"{name} (AUC = {roc_auc_score(y_true, s):.3f})")
    ax.plot([0, 1], [0, 1], "k--", lw=1, label="Chance")
    ax.set_xlabel("False positive rate (genuine flagged as Sybil)")
    ax.set_ylabel("True positive rate (Sybil recall)")
    ax.set_title("ROC curve - Sybil as positive class (held-out test set)\n"
                 "Tree scores are coarse leaf probabilities, so curves have few points", fontsize=10)
    ax.legend(loc="lower right", fontsize=9)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(roc_path, dpi=200, bbox_inches="tight")
    plt.close(fig)
    fig, ax = plt.subplots(figsize=(6.5, 6))
    for name, s in scores.items():
        pr, rc, _ = precision_recall_curve(y_true, s)
        ax.plot(rc, pr, drawstyle="steps-post",
                label=f"{name} (AP = {average_precision_score(y_true, s):.3f})")
    prev = y_true.mean()
    ax.axhline(prev, color="k", ls="--", lw=1, label=f"No-skill (Sybil prevalence = {prev:.3f})")
    ax.set_xlabel("Recall (Sybil)")
    ax.set_ylabel("Precision (Sybil)")
    ax.set_ylim(0, 1.02)
    ax.set_title("Precision-recall curve - Sybil detection (held-out test set)\n"
                 "High prevalence of Sybil (~90%) makes the no-skill baseline already high", fontsize=10)
    ax.legend(loc="lower left", fontsize=9)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(pr_path, dpi=200, bbox_inches="tight")
    plt.close(fig)


def plot_ablation(abl_df, path):
    d = abl_df[abl_df["experiment"].isin(["A_full_features", "B_without_missing_indicators"]) &
               (abl_df["model_config"] == "best")]
    metrics = ["balanced_accuracy", "recall_genuine", "recall_sybil", "macro_f1", "precision_sybil", "mcc"]
    a = d[d["experiment"] == "A_full_features"].iloc[0]
    b = d[d["experiment"] == "B_without_missing_indicators"].iloc[0]
    x = np.arange(len(metrics))
    fig, ax = plt.subplots(figsize=(9, 4.8))
    ax.bar(x - 0.2, [a[m] for m in metrics], 0.4, label="A: all 56 features")
    ax.bar(x + 0.2, [b[m] for m in metrics], 0.4, label="B: without 2 missing-indicators (54)")
    for i, m in enumerate(metrics):
        ax.text(i - 0.2, a[m] + 0.01, f"{a[m]:.2f}", ha="center", fontsize=8)
        ax.text(i + 0.2, b[m] + 0.01, f"{b[m]:.2f}", ha="center", fontsize=8)
    ax.set_xticks(x, metrics, rotation=20)
    ax.set_ylim(0, 1.1)
    ax.set_title("Missing-indicator ablation - selected configuration, held-out test set")
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=200, bbox_inches="tight")
    plt.close(fig)


# ----------------------------------------------------------------------------------------------------------
# 6. Report (all numbers are filled in from the actual run)
# ----------------------------------------------------------------------------------------------------------
def _t(df: pd.DataFrame, cols=None, digits=4) -> str:
    d = df[cols] if cols else df
    return d.to_string(index=False, float_format=lambda v: f"{v:.{digits}f}")


def write_report(c: dict) -> None:
    M, P, out = c["metrics"], c["config_params"], c["out"]
    cfg, abl, imp, tun, prim = c["config"], c["abl"], c["imp"], c["tuning_df"], c["primary"]
    data = cfg["data"]
    g = lambda n, k: M[n][k]
    names = list(M)
    cm = lambda n: M[n]["confusion_matrix_[[TN,FP],[FN,TP]]"]
    L = []
    w = L.append
    w("IMPLEMENTATION REPORT - DECISION TREE FOR VANET SYBIL ATTACK DETECTION (PART 2)")
    w("=" * 82)
    w("All numbers below were computed by decision_tree_implementation.py in the run documented in execution_log.txt.")
    w("Class 1 = Sybil is the positive class. Test metrics come from the held-out test set of Part 1 (never used for")
    w("fitting, tuning or selection). Cross-validation (CV) numbers come from the training data only.\n")

    w("1. WHAT A DECISION TREE IS AND HOW IT CLASSIFIES")
    w("-" * 82)
    w("A Decision Tree is a supervised model made of yes/no tests on single features. Starting at the root, each")
    w("record follows the branch whose test it satisfies (for example 'bsm1_kPCS <= 1.00') until it reaches a leaf;")
    w("the leaf's majority class (or class proportions, which give predict_proba) is the prediction. During training")
    w("scikit-learn's CART algorithm greedily chooses, at every node, the feature and threshold that most reduce")
    w("impurity (Gini or entropy) of the two child nodes, and keeps splitting until nodes are pure or a stopping")
    w("rule (max_depth, min_samples_split, min_samples_leaf) applies. Trees need no feature scaling and give")
    w("readable rules (selected_tree_rules.txt), but an unrestricted tree can memorise its training data.\n")

    w("2. DATA (Part 1 archive = source of truth) AND VERIFICATION")
    w("-" * 82)
    w(f"Train: {data['n_train']} rows (Genuine {data['train_class_counts']['Genuine']}, Sybil {data['train_class_counts']['Sybil']}), "
      f"{data['train_senders']} senders, of which {data['genuine_senders_train']} genuine senders.")
    w(f"Test : {data['n_test']} rows (Genuine {data['test_class_counts']['Genuine']}, Sybil {data['test_class_counts']['Sybil']}), "
      f"{data['test_senders']} senders, of which {data['genuine_senders_test']} genuine senders.")
    w(f"Features: {data['n_features']} (54 numeric + 2 missing indicators: {', '.join(MISSING_INDICATORS)}).")
    w("The split, preprocessing (median imputation fitted on train, constant columns removed, no scaling, no")
    w("resampling) and feature list were used exactly as delivered. Inspection checks (shapes, identical feature")
    w("order, binary target 0=Genuine/1=Sybil, no sender in both splits, no target/attack-family/id/timestamp column")
    w("in X, processed CSVs consistent with X/y) all passed; see execution_log.txt. The input files' SHA-256 hashes")
    w("were identical before and after the run. Class imbalance: about 90% of rows are Sybil in both splits, so")
    w("accuracy alone is a weak indicator (a model that always says 'Sybil' would score ~90%).\n")

    w("3. METHOD")
    w("-" * 82)
    w(f"Random seed {cfg['random_seed']} everywhere. scikit-learn {c['env']['scikit_learn']}, numpy {c['env']['numpy']}, "
      f"pandas {c['env']['pandas']}, Python {c['env']['python']}.")
    w(f"(a) Baseline: DecisionTreeClassifier({', '.join(f'{k}={v}' for k, v in P['baseline'].items())}, random_state=42) - "
      "unrestricted depth, no class weighting.")
    w("(b) Balanced: identical, but class_weight='balanced' (errors on the rare Genuine class cost ~9x more).")
    if tun is not None:
        sp = cfg["tuning"]
        w(f"(c) Tuning: {sp['configurations_evaluated']} configurations (random sample of the {sp['full_grid_size']}-point grid "
          "max_depth {3,5,10,15,None} x min_samples_split {2,5,10} x min_samples_leaf {1,2,5,10} x criterion {gini,entropy} x")
        w("    class_weight {None,balanced}; the baseline and balanced configurations are always included) were compared with")
        w(f"    {c['args']['cv_folds']}-fold grouped cross-validation on the TRAINING data only. Groups = reported_id from train_metadata.csv.")
        w("    Because only 5 genuine senders exist in the training data, a custom deterministic splitter places exactly one")
        w("    genuine sender in each validation fold and balances the Sybil senders by row count. A sender never appears in")
        w("    both the training and validation part of a fold (checked). Fold details: " + c["folds_detail"])
        w("    Selection metric: macro-F1 computed on the pooled out-of-fold predictions (every training row is predicted by a")
        w("    model that never saw its sender). Macro-F1 weights the rare Genuine class equally with Sybil, and pooling avoids")
        w("    the extremely noisy per-fold scores of folds that hold only 3 or 6 genuine rows. Ties: mean per-fold macro-F1,")
        w("    then fewer leaves. The winner was refitted on the full training set and evaluated once on the test set.")
        w(f"    Selected: {c['best_params']}")
    w("(d) Missing-indicator ablation: same configuration, seed and rows; Experiment A uses all 56 features, Experiment B")
    w("    drops only bsm1_delay_was_missing and bsm2_delay_was_missing (54 features). Diagnostic only; not used for selection.\n")

    w("4. TEST-SET RESULTS (held-out, n = %d; Genuine %d / Sybil %d)" % (len(c["preds_df"]), data["test_class_counts"]["Genuine"], data["test_class_counts"]["Sybil"]))
    w("-" * 82)
    comp = pd.read_csv(out / "model_comparison.csv")
    w(_t(comp, ["model", "class_weight", "tree_depth", "tree_leaves", "accuracy", "balanced_accuracy", "recall_genuine",
                "recall_sybil", "precision_sybil", "f1_sybil", "macro_f1", "mcc"]))
    w("")
    w(_t(comp, ["model", "precision_genuine", "f1_genuine", "roc_auc", "pr_auc_average_precision",
                "true_negatives_genuine_correct", "false_positives_genuine_flagged_as_sybil",
                "false_negatives_sybil_missed", "true_positives_sybil_detected"]))
    w("")
    w("Confusion matrices [[TN, FP], [FN, TP]] (rows = actual Genuine/Sybil, columns = predicted Genuine/Sybil):")
    for n in names:
        w(f"  {n:9s} {cm(n)}")
    w("Weighted and macro averages, full classification reports and undefined-metric notes: classification_report.txt and the")
    w("*_metrics.json files. No metric was undefined for any model.")
    w("Note on ROC-AUC: a fully grown tree has (almost) pure leaves, so its predicted probabilities are nearly all 0 or 1;")
    w("the ROC curve then has essentially one operating point and ROC-AUC is about equal to balanced accuracy (baseline:")
    w(f"ROC-AUC {g('baseline','roc_auc'):.4f} vs balanced accuracy {g('baseline','balanced_accuracy'):.4f}). ROC/PR-AUC therefore add little beyond the confusion matrix here.\n")

    w("5. WHAT THE CONFUSION MATRICES SHOW")
    w("-" * 82)
    for n in names:
        tn, fp, fn, tp = cm(n)[0] + cm(n)[1]
        w(f"{n}: {fn} of {tp + fn} Sybil records missed (miss rate {100 * fn / (tp + fn):.2f}%); {fp} of {tn + fp} genuine records "
          f"wrongly flagged as Sybil (false-alarm rate {100 * fp / (tn + fp):.1f}%).")
    w("Both error types matter differently: a missed Sybil record is an undetected attack message, a false alarm is a")
    w("legitimate vehicle's message flagged. With only 28 genuine test rows (3 senders) one extra false alarm moves genuine")
    w("recall by 3.6 percentage points, so genuine-class numbers are coarse.")
    ea_g = c["ea_g"]
    for n in names:
        gg = ea_g[ea_g["model"] == n]
        w(f"  {n}: genuine test rows correct per sender: " + ", ".join(f"{int(r.genuine_sender)}: {int(r.n_correct)}/{int(r.n_rows)}" for r in gg.itertuples()))
    w("Errors on genuine traffic are concentrated in specific senders (error_analysis_genuine_senders.csv): the 2-row sender")
    w("is misclassified by every model, so the result for genuine traffic depends on which few senders land in the test set.\n")

    w("6. BASELINE vs CLASS-WEIGHTED (BALANCED) MODEL")
    w("-" * 82)
    b, bl = "baseline", "balanced"
    w(f"Balanced accuracy {g(b,'balanced_accuracy'):.4f} -> {g(bl,'balanced_accuracy'):.4f}; genuine recall {g(b,'recall_genuine'):.4f} -> {g(bl,'recall_genuine'):.4f}; "
      f"Sybil recall {g(b,'recall_sybil'):.4f} -> {g(bl,'recall_sybil'):.4f}; macro-F1 {g(b,'macro_f1'):.4f} -> {g(bl,'macro_f1'):.4f}; "
      f"Sybil precision {g(b,'precision_sybil'):.4f} -> {g(bl,'precision_sybil'):.4f}; MCC {g(b,'mcc'):.4f} -> {g(bl,'mcc'):.4f}.")
    dfp = M[b]["false_positives_genuine_flagged_as_sybil"] - M[bl]["false_positives_genuine_flagged_as_sybil"]
    dfn = M[b]["false_negatives_sybil_missed"] - M[bl]["false_negatives_sybil_missed"]
    w(f"In counts, class weighting changed false alarms on genuine traffic by {-dfp:+d} and missed Sybil records by {-dfn:+d} on this test set.")
    w("Trade-off: weighting makes the tree pay more for errors on the rare Genuine class, which usually lowers false alarms but")
    w("can cost Sybil recall when the classes overlap. Here the test-set differences are one to two records, which is within the")
    w("noise expected from 28 genuine rows from 3 senders; the test set alone cannot establish that one is better. The grouped CV")
    if tun is not None:
        rb = tun[(tun["max_depth"].astype(str) == "None") & (tun["min_samples_split"] == 2) & (tun["min_samples_leaf"] == 1) & (tun["criterion"] == "gini")]
        cvb = rb[rb["class_weight"].astype(str) == "None"].iloc[0]
        cvl = rb[rb["class_weight"].astype(str) == "balanced"].iloc[0]
        w(f"on training data gives a second view: pooled out-of-fold macro-F1 baseline {cvb['oof_macro_f1']:.4f} vs balanced {cvl['oof_macro_f1']:.4f}; "
          f"genuine recall {cvb['oof_recall_genuine']:.4f} vs {cvl['oof_recall_genuine']:.4f}; Sybil recall {cvb['oof_recall_sybil']:.4f} vs {cvl['oof_recall_sybil']:.4f}.")
    w("")

    if tun is not None:
        w("7. HYPERPARAMETER TUNING AND THE SELECTED MODEL")
        w("-" * 82)
        top = tun.iloc[0]
        close = int((tun["oof_macro_f1"] >= top["oof_macro_f1"] - 0.01).sum())
        w(_t(tun.head(5), ["rank", "max_depth", "min_samples_split", "min_samples_leaf", "criterion", "class_weight",
                           "oof_macro_f1", "oof_recall_genuine", "oof_recall_sybil", "mean_fold_macro_f1", "mean_n_leaves"]))
        w(f"Pooled out-of-fold macro-F1 over all {len(tun)} configurations ranges from {tun['oof_macro_f1'].min():.3f} to {tun['oof_macro_f1'].max():.3f}; "
          f"{close} configurations lie within 0.01 of the winner, so the choice among the top configurations is not a statistically")
        w("meaningful decision (the CV rests on only 5 genuine senders). The winner is 'selected by the pre-specified rule', not 'proven best'.")
        w(f"Per-fold macro-F1 is very unstable (selected config: mean {top['mean_fold_macro_f1']:.3f}, std {top['std_fold_macro_f1']:.3f}). The highest minimum per-fold genuine recall "
          f"reached by any configuration is {tun['min_fold_recall_genuine'].max():.2f}" +
          (": for every configuration at least one held-out genuine sender (the smallest ones, 3-6 rows) was classified entirely as Sybil." if tun['min_fold_recall_genuine'].max() == 0 else "."))
        w(f"Selected model on the test set: balanced accuracy {g('best','balanced_accuracy'):.4f}, genuine recall {g('best','recall_genuine'):.4f}, Sybil recall {g('best','recall_sybil'):.4f}, "
          f"macro-F1 {g('best','macro_f1'):.4f}, Sybil precision {g('best','precision_sybil'):.4f}, MCC {g('best','mcc'):.4f}; depth {c['models']['best'].get_depth()}, {c['models']['best'].get_n_leaves()} leaves "
          f"(simpler than the unrestricted trees: {c['models']['baseline'].get_n_leaves()} / {c['models']['balanced'].get_n_leaves()} leaves).")
        dfa = cm('balanced')[0][1] - cm('best')[0][1]
        dmiss = cm('best')[1][0] - cm('balanced')[1][0]
        w(f"Compared with the plain balanced tree on the test set, the selected tree makes {abs(dfa)} {'fewer' if dfa >= 0 else 'more'} false alarm(s) on genuine records and "
          f"{abs(dmiss)} {'more' if dmiss >= 0 else 'fewer'} missed Sybil record(s): a difference of about one record each way, not evidence of a real improvement.")
        cvgap = f"CV vs test: for the selected configuration pooled out-of-fold genuine recall was {top['oof_recall_genuine']:.3f} and macro-F1 {top['oof_macro_f1']:.3f}, versus {g('best','recall_genuine'):.3f} and {g('best','macro_f1'):.3f} on the test set. "
        w(cvgap + "The test set is therefore likely to be on the favourable side (it contains 3 genuine senders; the CV pools all 5 training senders),")
        w("and the CV figure is probably the more realistic indication of how the model treats genuine senders it has not seen.\n")

    w("8. MISSING-INDICATOR ABLATION")
    w("-" * 82)
    pa = abl[abl["primary_ablation"]]
    w(f"Primary comparison (configuration '{prim}'):")
    w(_t(pa, ["experiment", "n_features", "balanced_accuracy", "recall_genuine", "recall_sybil", "macro_f1", "precision_sybil", "mcc",
              "cv_oof_macro_f1_train_only", "cv_oof_recall_genuine_train_only"]))
    w("Same comparison for the baseline and balanced configurations (full table: missing_indicator_ablation.csv):")
    oth = abl[~abl["primary_ablation"]]
    w(_t(oth, ["model_config", "experiment", "balanced_accuracy", "recall_genuine", "recall_sybil", "macro_f1", "precision_sybil", "mcc",
               "cv_oof_macro_f1_train_only", "cv_oof_recall_genuine_train_only"]))
    mi_imp = imp[imp["is_missing_indicator"]]
    w(f"Importance of the two indicators in the selected tree: {', '.join(f'{r.feature} = {r.importance:.4f} (rank {r.rank})' for r in mi_imp.itertuples())}.")
    dB = pa[pa["experiment"] == "delta_B_minus_A"].iloc[0]
    w(f"Interpretation: for the selected configuration, removing the indicators changed test balanced accuracy by {dB['balanced_accuracy']:+.4f}, genuine recall by "
      f"{dB['recall_genuine']:+.4f}, Sybil recall by {dB['recall_sybil']:+.4f}, macro-F1 by {dB['macro_f1']:+.4f}, Sybil precision by {dB['precision_sybil']:+.4f} and MCC by {dB['mcc']:+.4f}; "
      f"the pooled training-CV macro-F1 changed by {dB['cv_oof_macro_f1_train_only']:+.4f}.")
    dd = abl[(abl["experiment"] == "delta_B_minus_A") & (~abl["primary_ablation"])]
    w("For the other two configurations the test balanced-accuracy changes were " + ", ".join(f"{r.model_config}: {r.balanced_accuracy:+.4f}" for r in dd.itertuples()) +
      " and the CV genuine-recall changes " + ", ".join(f"{r.model_config}: {r.cv_oof_recall_genuine_train_only:+.4f}" for r in dd.itertuples()) + ".")
    dg = c["diag_df"]
    w("Diagnostics (ablation_seed_sensitivity.csv; descriptive only):")
    w("  indicators used in any split of the saved trees: " + "; ".join(f"{n}: {c['used_ind'][n] or 'none'}" for n in c["used_ind"]))
    w("  control C (indicators kept as constant-0 columns, 56 columns) gives predictions identical to Experiment A: " + "; ".join(f"{n}: {v}" for n, v in c["ctrl_equal"].items()))
    w("  test balanced accuracy over seeds 0-19 (mean +/- std [min, max]):")
    for r_ in dg.itertuples():
        w(f"    {r_.model_config:9s} {r_.experiment:30s} {r_.test_balanced_accuracy_mean:.4f} +/- {r_.test_balanced_accuracy_std:.4f} [{r_.test_balanced_accuracy_min:.4f}, {r_.test_balanced_accuracy_max:.4f}]")
    unused_all = all(not v for v in c["used_ind"].values())
    if unused_all:
        w("Reading: none of the three trees uses the missing indicators in any split (importance 0), although bsm2_delay_was_missing is strongly")
        w("associated with the class in the data (Part 1: 70.7% of Sybil vs 3.4% of genuine rows). Other features (the plausibility-type values below)")
        w("separate the classes at least as well, so the trees did not need the indicators.")
        if all(c["ctrl_equal"].values()):
            w("The differences seen after dropping the columns are not caused by the indicators: with the indicators neutralised but the column count unchanged the")
            w("predictions are exactly those of Experiment A. The differences arise because sklearn breaks ties between equally good splits with a random feature")
            w("permutation whose outcome depends on the number of columns (and on the seed); the seed-sensitivity table shows how large that noise is, in the same")
            w("range as the A-vs-B differences. They must not be read as reliance on missingness.")
        w("Conclusion: no evidence that these models rely on the two indicators. This is a diagnostic on one dataset: other logging artefacts (e.g. the delay")
        w("values themselves, which carry the same missingness through median imputation) or the absolute-position features could still act as shortcuts.")
        w("It does not show generalisation to other datasets.\n")
    else:
        w("Reading: at least one saved tree uses a missing indicator; compare the A-vs-B differences above with the seed noise listed here before concluding")
        w("that the model relies on missingness. This is a diagnostic on one dataset and does not show generalisation to other datasets.\n")

    w("9. FEATURE IMPORTANCE (selected model: %s)" % prim)
    w("-" * 82)
    w(_t(imp.head(10), ["rank", "feature", "importance", "cumulative_importance"], digits=4))
    nz = int((imp["importance"] > 1e-9).sum())
    w(f"Only {nz} of {len(imp)} features are used by the selected tree; the top two features carry {imp['importance'].head(2).sum():.1%} of the total importance. Full table: feature_importance.csv.")
    w("Possible relevance (hypotheses, not findings): bsm1_kPCS and bsm1_psC are plausibility/consistency check values of the first BSM")
    w("(naming from the dataset; their exact definition is outside Part 1's documentation). In the training data Sybil rows frequently sit at the")
    w("saturated value 1.0 whereas genuine rows are spread below 1 (selected_tree_rules.txt, first split bsm1_kPCS <= 1.00). That could reflect how the")
    w("simulator's plausibility detector treats fabricated identities rather than a property transferable to other attackers or detectors.")
    w("Heading and absolute position features (bsm1_heading_x, bsm2_pos_x, bsm1_pos_x) also appear in the selected tree; Part 1 warned that")
    w("with 8 genuine senders location can act as a sender proxy, so these splits may encode 'where genuine vehicles drive in this simulation'.")
    w("Cautions: impurity-based importance is not causal evidence; correlated features share importance (so a feature with low importance may still")
    w("be informative); importance is computed on training data and says nothing about other datasets. The three models rank features differently")
    w("(baseline top: " + ", ".join(f"{r['feature']} {r['importance']:.3f}" for r in c['imp_pairs']['baseline'][:3]) + "), which also shows how unstable the ranking is.\n")

    w("10. ANALYSIS BY SYBIL VARIANT (descriptive, test set)")
    w("-" * 82)
    ea = c["ea"]
    piv = ea.pivot_table(index="attack_type", columns="model", values="accuracy_within_type")
    cnt = ea.drop_duplicates("attack_type").set_index("attack_type")[["true_class", "n_rows", "n_senders"]]
    w(pd.concat([cnt, piv], axis=1).to_string(float_format=lambda v: f"{v:.3f}"))
    w("DataReplaySybil rows are absent from the test set (27 rows in the whole dataset, all in training), so nothing can be said about that variant.\n")

    w("11. LIMITATIONS")
    w("-" * 82)
    for t in [
        "Only 8 genuine senders exist in the whole dataset: 5 in training, 3 in the test set (28 rows, one sender has 2 rows). Genuine-class recall,",
        "balanced accuracy, macro-F1 and MCC are therefore unstable; a different grouped split would give different numbers (Part 1 reports 1-5",
        "genuine test senders across seeds). A single test set cannot give a reliable confidence interval; none is claimed.",
        "Test results (balanced accuracy %.3f-%.3f across the three models) are noticeably higher than the grouped-CV estimates on training data, which is" % (min(g(n, 'balanced_accuracy') for n in names), max(g(n, 'balanced_accuracy') for n in names)),
        "consistent with the test set being easy for genuine traffic; the test numbers should not be read as expected performance.",
        "The Sybil class is dominated by one variant (DoSRandomSybil); sender ids from one physical attacker appear as different reported_ids, so",
        "grouping by sender may not fully separate attackers, and the CV/test split may be optimistic for Sybil traffic.",
        "Absolute position, heading and the plausibility values may reflect simulation geometry or detector behaviour rather than attacker behaviour.",
        "Tie-breaking randomness matters: over seeds 0-19 the test balanced accuracy of the full-feature trees ranged " + "; ".join(
            f"{r_.model_config} {r_.test_balanced_accuracy_min:.3f}-{r_.test_balanced_accuracy_max:.3f}" for r_ in c["diag_df"][c["diag_df"]["experiment"] == "A_full_features"].itertuples()) + ".",
        "The reported numbers use seed 42 (fixed in advance, not chosen from these runs); single-tree results should be read with this spread in mind.",
        "Hyperparameter selection compared %s configurations on 5 genuine senders; differences among the top configurations are within noise." % (len(tun) if tun is not None else 'n/a'),
        "Part 1 fitted the imputation medians on the full training set; inside the CV folds this leaks medians (not labels) of the validation rows, which is",
        "negligible for a tree but was not re-fitted per fold because Part 1 outputs were not to be altered.",
        "The test set was evaluated for every reported model and ablation variant (reporting only); the final configuration was fixed by CV before the",
        "test evaluation, but the repeated reporting means the test numbers should not be used for further tuning.",
        "Nothing here shows performance on unseen VANET environments, other simulators, other attack implementations or real deployments. The model is",
        "not deployment-ready and the experiment does not demonstrate real-world Sybil detection capability."]:
        w(t)
    w("")
    w("12. CONCLUSIONS")
    w("-" * 82)
    w(f"On the Part 1 held-out split, all three Decision Trees separate Genuine from Sybil records with high test accuracy ({min(g(n,'accuracy') for n in names):.3f}-{max(g(n,'accuracy') for n in names):.3f}),")
    w(f"which is only modestly above the {data['test_class_counts']['Sybil'] / data['n_test']:.3f} majority-class rate; the more informative figures are balanced accuracy ({min(g(n,'balanced_accuracy') for n in names):.3f}-{max(g(n,'balanced_accuracy') for n in names):.3f})")
    w("and genuine recall, which depend on only three genuine senders. Class weighting and a simpler, CV-selected tree reduced false alarms on genuine")
    w("traffic in this test set without a material loss of Sybil recall, but the differences are one to two records.")
    if all(not v for v in c["used_ind"].values()):
        w("The two missing-indicator features are not used by any of the trees (see section 8), so their removal does not reflect a reliance on missingness.")
    else:
        w("At least one tree uses a missing-indicator feature; see section 8 for how to read the ablation.")
    w("The selected tree relies mainly on two plausibility-type features of the first message plus a few position/heading splits. The grouped CV shows that genuine senders unseen in training are often misclassified, so the")
    w("apparent test performance should be treated as optimistic and preliminary.\n")

    w("13. REPRODUCIBILITY AND RUNTIME")
    w("-" * 82)
    w("Command: python decision_tree_implementation.py   (details in README.txt). Parameters, versions, hashes and validation results: model_configuration.json.")
    w("Runtime (s): " + ", ".join(f"{k}={v:.1f}" for k, v in c["timings"].items()))
    w("Validation checks passed at report time: %d/%d (see execution_log.txt for the full list)." % (sum(ok for _, ok, _ in c["checks"]), len(c["checks"])))
    (out / "implementation_report.txt").write_text("\n".join(L) + "\n", encoding="utf-8")


# ----------------------------------------------------------------------------------------------------------
# 5. Main pipeline
# ----------------------------------------------------------------------------------------------------------
def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data-dir", default=None)
    ap.add_argument("--output-dir", default=None)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--cv-folds", type=int, default=5)
    ap.add_argument("--n-configs", type=int, default=60)
    ap.add_argument("--tree-plot-depth", type=int, default=3)
    args = ap.parse_args()

    t_start = time.perf_counter()
    timings: dict = {}
    script_dir = Path(__file__).resolve().parent
    out = Path(args.output_dir).resolve() if args.output_dir else script_dir
    out.mkdir(parents=True, exist_ok=True)
    (out / "plots").mkdir(exist_ok=True)
    setup_logging(out / "execution_log.txt")
    seed = args.seed
    np.random.seed(seed)
    random.seed(seed)

    LOG.info("=== Decision Tree - VANET Sybil detection (Part 2) ===")
    env = {"python": platform.python_version(), "platform": platform.platform(), "scikit_learn": sklearn.__version__,
           "numpy": np.__version__, "pandas": pd.__version__, "matplotlib": matplotlib.__version__,
           "joblib": joblib.__version__}
    LOG.info("Environment: %s", env)
    LOG.info("Arguments: %s", vars(args))

    # ---- load + inspect inputs --------------------------------------------------------------------------
    t0 = time.perf_counter()
    data_dir = resolve_data_dir(args.data_dir, script_dir)
    LOG.info("Preprocessing folder: %s", data_dir)
    input_files = [f for f in REQUIRED_INPUTS + OPTIONAL_INPUTS if (data_dir / f).exists()]
    hashes_before = {f: sha256(data_dir / f) for f in input_files}
    d = load_inputs(data_dir)
    all_checks = validate_inputs(d, data_dir)
    Xtr, Xte, ytr, yte = d["X_train"], d["X_test"], d["y_train"], d["y_test"]
    mtr, mte = d["meta_train"], d["meta_test"]
    feature_columns = list(d["feature_columns"])
    if not all(ok for _, ok, _ in all_checks):
        LOG.error("Input validation failed - stopping. Nothing was modified.")
        return 2
    groups_tr = mtr["reported_id"]
    n_gen_senders_tr = groups_tr[ytr == 0].nunique()
    LOG.info("Train: %d rows (Genuine %d / Sybil %d), %d senders (%d genuine senders)", len(Xtr), (ytr == 0).sum(),
             (ytr == 1).sum(), groups_tr.nunique(), n_gen_senders_tr)
    LOG.info("Test : %d rows (Genuine %d / Sybil %d), %d senders", len(Xte), (yte == 0).sum(), (yte == 1).sum(),
             mte["reported_id"].nunique())
    LOG.info("Features: %d (missing indicators: %s)", len(feature_columns), MISSING_INDICATORS)
    timings["load_and_inspect_s"] = time.perf_counter() - t0

    # ---- baseline + balanced ----------------------------------------------------------------------------
    t0 = time.perf_counter()
    models, preds, scores, metrics = {}, {}, {}, {}

    def fit_eval(name: str, params: dict, X1, X2):
        m = DecisionTreeClassifier(**params, random_state=seed).fit(X1, ytr)
        pr, sc = m.predict(X2), m.predict_proba(X2)[:, 1]
        return m, pr, sc, compute_metrics(yte, pr, sc)

    for name, params in (("baseline", BASELINE_PARAMS), ("balanced", BALANCED_PARAMS)):
        m, pr, sc, met = fit_eval(name, params, Xtr, Xte)
        models[name], preds[name], scores[name], metrics[name] = m, pr, sc, met
        LOG.info("%s (%s): depth=%d leaves=%d | TEST acc=%.4f bal_acc=%.4f recall_gen=%.4f recall_syb=%.4f macroF1=%.4f MCC=%.4f",
                 name, params, m.get_depth(), m.get_n_leaves(), met["accuracy"], met["balanced_accuracy"],
                 met["recall_genuine"], met["recall_sybil"], met["macro_f1"], met["mcc"])
    timings["baseline_balanced_s"] = time.perf_counter() - t0

    # ---- grouped CV tuning on training data only --------------------------------------------------------
    t0 = time.perf_counter()
    tuning_feasible = True
    try:
        folds = make_grouped_stratified_folds(ytr, groups_tr, args.cv_folds, seed)
        ok, detail = check_folds(folds, ytr, groups_tr)
        check(all_checks, "tuning: grouped stratified folds valid (no sender in train+val of a fold, both classes in "
                          "every train and validation part)", ok, detail)
        tuning_feasible = ok
    except ValueError as e:
        tuning_feasible = False
        LOG.warning("Grouped CV not feasible: %s", e)
    best_params, tuning_df = None, None
    if tuning_feasible:
        tuning_df, best_params = run_tuning(Xtr, ytr, groups_tr, folds, seed, args.n_configs)
        tuning_df.to_csv(out / "hyperparameter_tuning_results.csv", index=False)
        top = tuning_df.head(5)[["rank", "max_depth", "min_samples_split", "min_samples_leaf", "criterion",
                                 "class_weight", "oof_macro_f1", "mean_fold_macro_f1", "mean_n_leaves"]]
        LOG.info("Top-5 CV configurations (training data only):\n%s", top.to_string(index=False))
        LOG.info("Selected by CV (pooled out-of-fold macro-F1): %s", best_params)
        m, pr, sc, met = fit_eval("best", best_params, Xtr, Xte)  # single test evaluation of the chosen config
        models["best"], preds["best"], scores["best"], metrics["best"] = m, pr, sc, met
        LOG.info("best: depth=%d leaves=%d | TEST acc=%.4f bal_acc=%.4f recall_gen=%.4f recall_syb=%.4f macroF1=%.4f MCC=%.4f",
                 m.get_depth(), m.get_n_leaves(), met["accuracy"], met["balanced_accuracy"], met["recall_genuine"],
                 met["recall_sybil"], met["macro_f1"], met["mcc"])
    timings["tuning_s"] = time.perf_counter() - t0
    primary = "best" if "best" in models else "balanced"
    primary_params = best_params if best_params else BALANCED_PARAMS
    config_params = {"baseline": BASELINE_PARAMS, "balanced": BALANCED_PARAMS}
    if best_params:
        config_params["best"] = best_params

    # ---- save models, metrics -----------------------------------------------------------------------------
    for name, m in models.items():
        joblib.dump(m, out / f"decision_tree_{name}.joblib")
    for name in models:
        mj = dict(metrics[name], model=name, params=config_params[name], evaluated_on="held-out test set (X_test/y_test)",
                  tree_depth=models[name].get_depth(), tree_leaves=models[name].get_n_leaves())
        fname = {"baseline": "baseline_metrics.json", "balanced": "balanced_metrics.json",
                 "best": "best_model_metrics.json"}[name]
        jdump(mj, out / fname)
    with open(out / "classification_report.txt", "w", encoding="utf-8") as f:
        f.write("CLASSIFICATION REPORTS - HELD-OUT TEST SET (class 1 = Sybil is the positive class)\n")
        f.write(f"Test rows: {len(yte)} (Genuine {int((yte == 0).sum())}, Sybil {int((yte == 1).sum())})\n")
        f.write("Only 3 genuine test senders exist -> genuine-class numbers are statistically unstable.\n\n")
        for name in models:
            met = metrics[name]
            f.write("=" * 78 + f"\nModel: {name}   params: {config_params[name]}\n" + "=" * 78 + "\n")
            f.write(met["classification_report"] + "\n")
            f.write(f"accuracy={met['accuracy']:.4f}  balanced_accuracy={met['balanced_accuracy']:.4f}  "
                    f"MCC={met['mcc']:.4f}\n")
            f.write(f"ROC-AUC={met['roc_auc']:.4f}  PR-AUC(average precision)={met['pr_auc_average_precision']:.4f}  "
                    f"PR-AUC(trapezoid)={met['pr_auc_trapezoid']:.4f}\n")
            f.write(f"Confusion matrix [[TN,FP],[FN,TP]] (rows actual Genuine/Sybil, cols predicted Genuine/Sybil): "
                    f"{met['confusion_matrix_[[TN,FP],[FN,TP]]']}\n")
            f.write(f"Undefined/degenerate metrics: {met['undefined_or_degenerate_metrics'] or 'none'}\n\n")

    # comparison table
    comp_cols = ["balanced_accuracy", "recall_genuine", "recall_sybil", "macro_f1", "precision_sybil", "f1_sybil", "mcc",
                 "accuracy", "precision_genuine", "f1_genuine", "roc_auc", "pr_auc_average_precision",
                 "true_negatives_genuine_correct", "false_positives_genuine_flagged_as_sybil",
                 "false_negatives_sybil_missed", "true_positives_sybil_detected", "false_alarm_rate_on_genuine",
                 "miss_rate_on_sybil"]
    rows = []
    for name in models:
        rows.append({"model": name, "class_weight": str(config_params[name]["class_weight"]),
                     "max_depth": str(config_params[name]["max_depth"]),
                     "min_samples_split": config_params[name]["min_samples_split"],
                     "min_samples_leaf": config_params[name]["min_samples_leaf"],
                     "criterion": config_params[name]["criterion"], "tree_depth": models[name].get_depth(),
                     "tree_leaves": models[name].get_n_leaves(), **{c: metrics[name][c] for c in comp_cols}})
    pd.DataFrame(rows).to_csv(out / "model_comparison.csv", index=False)

    # predictions (for traceability and metric re-computation); metadata columns are NOT model inputs
    pred_df = pd.DataFrame({"row_id": mte["row_id"], "reported_id": mte["reported_id"],
                            "attack_type": mte["attack_type"], "y_true": yte.to_numpy()})
    for name in models:
        pred_df[f"{name}_pred"] = preds[name]
        pred_df[f"{name}_proba_sybil"] = scores[name]
    pred_df.to_csv(out / "test_predictions.csv", index=False)

    # error analysis (descriptive only, not used for any selection)
    ea = []
    for name in models:
        for at, g in pred_df.groupby("attack_type"):
            correct = (g[f"{name}_pred"] == g["y_true"])
            ea.append({"model": name, "attack_type": at, "true_class": CLASS_NAMES[int(g["y_true"].iloc[0])],
                       "n_rows": len(g), "n_senders": g["reported_id"].nunique(), "n_correct": int(correct.sum()),
                       "accuracy_within_type": float(correct.mean())})
    pd.DataFrame(ea).to_csv(out / "error_analysis_by_attack_type.csv", index=False)
    ea_g = []
    for name in models:
        for sid, g in pred_df[pred_df["y_true"] == 0].groupby("reported_id"):
            ea_g.append({"model": name, "genuine_sender": sid, "n_rows": len(g),
                         "n_correct": int((g[f"{name}_pred"] == 0).sum())})
    pd.DataFrame(ea_g).to_csv(out / "error_analysis_genuine_senders.csv", index=False)

    # ---- feature importance (selected model) ----------------------------------------------------------------
    sel = models[primary]
    imp = pd.DataFrame({"feature": feature_columns, "importance": sel.feature_importances_,
                        "is_missing_indicator": [f in MISSING_INDICATORS for f in feature_columns]})
    imp = imp.sort_values("importance", ascending=False, kind="stable").reset_index(drop=True)
    imp["rank"] = np.arange(1, len(imp) + 1)
    imp["cumulative_importance"] = imp["importance"].cumsum()
    imp.to_csv(out / "feature_importance.csv", index=False)
    imp_pairs = {}
    for name in models:
        i2 = pd.DataFrame({"feature": feature_columns, "importance": models[name].feature_importances_})
        imp_pairs[name] = i2.sort_values("importance", ascending=False, kind="stable").head(5).to_dict("records")
    (out / "selected_tree_rules.txt").write_text(
        f"Complete rule set of the selected ('{primary}') Decision Tree - params {config_params[primary]}\n"
        "weights = class-weighted training samples [Genuine, Sybil] in the leaf (class_weight applied if 'balanced')\n\n"
        + export_text(sel, feature_names=feature_columns, show_weights=True), encoding="utf-8")
    LOG.info("Top features (%s model): %s", primary, [(r.feature, round(r.importance, 4)) for r in imp.head(8).itertuples()])

    # ---- missing-indicator ablation --------------------------------------------------------------------------
    t0 = time.perf_counter()
    no_ind_cols = [c for c in feature_columns if c not in MISSING_INDICATORS]
    abl_rows, abl_importance = [], {}
    for cname in dict.fromkeys([primary, "baseline", "balanced"]):
        p = config_params[cname]
        for exp, cols in (("A_full_features", feature_columns), ("B_without_missing_indicators", no_ind_cols)):
            m = DecisionTreeClassifier(**p, random_state=seed).fit(Xtr[cols], ytr)
            pr, sc = m.predict(Xte[cols]), m.predict_proba(Xte[cols])[:, 1]
            met = compute_metrics(yte, pr, sc)
            cvm = cv_evaluate(p, Xtr[cols], ytr, folds, seed) if tuning_feasible else {}
            if exp == "A_full_features" and cname in models:  # consistency with the saved model
                assert (pr == preds[cname]).all(), "Experiment A must reproduce the saved model's predictions"
            if exp.startswith("B") and cname == primary:
                abl_importance = dict(zip(cols, m.feature_importances_))
            abl_rows.append({"model_config": cname,
                             "primary_ablation": cname == primary, "experiment": exp, "n_features": len(cols),
                             "tree_depth": m.get_depth(), "tree_leaves": m.get_n_leaves(),
                             **{k: v for k, v in flat(met).items() if k in (
                                 "balanced_accuracy", "recall_genuine", "recall_sybil", "macro_f1", "precision_sybil",
                                 "mcc", "accuracy", "f1_sybil", "roc_auc", "pr_auc_average_precision",
                                 "false_positives_genuine_flagged_as_sybil", "false_negatives_sybil_missed")},
                             "cv_oof_macro_f1_train_only": cvm.get("oof_macro_f1"),
                             "cv_oof_balanced_accuracy_train_only": cvm.get("oof_balanced_accuracy"),
                             "cv_oof_recall_genuine_train_only": cvm.get("oof_recall_genuine")})
    abl = pd.DataFrame(abl_rows)
    delta_rows = []
    num_cols = [c for c in abl.columns if abl[c].dtype.kind in "fi" and c not in ("n_features", "tree_depth", "tree_leaves")]
    for cname, g in abl.groupby("model_config", sort=False):
        a = g[g["experiment"] == "A_full_features"].iloc[0]
        b = g[g["experiment"] == "B_without_missing_indicators"].iloc[0]
        row = {"model_config": cname, "primary_ablation": a["primary_ablation"], "experiment": "delta_B_minus_A",
               "n_features": int(b["n_features"]) - int(a["n_features"])}
        row.update({c: b[c] - a[c] for c in num_cols})
        delta_rows.append(row)
    abl = pd.concat([abl, pd.DataFrame(delta_rows)], ignore_index=True)
    abl.to_csv(out / "missing_indicator_ablation.csv", index=False)
    LOG.info("Ablation (primary=%s):\n%s", primary, abl[abl["primary_ablation"]][
        ["experiment", "n_features", "balanced_accuracy", "recall_genuine", "recall_sybil", "macro_f1",
         "precision_sybil", "mcc"]].to_string(index=False))
    diag_df, ctrl_equal, used_ind = ablation_diagnostics(config_params, models, Xtr, ytr, Xte, yte, feature_columns,
                                                          no_ind_cols, seed)
    diag_df.to_csv(out / "ablation_seed_sensitivity.csv", index=False)
    LOG.info("Indicators used in any split: %s | control C (indicators zeroed) identical to A: %s", used_ind, ctrl_equal)
    timings["ablation_s"] = time.perf_counter() - t0

    # ---- plots ---------------------------------------------------------------------------------------------
    t0 = time.perf_counter()
    plot_confusion(metrics[primary]["confusion_matrix_[[TN,FP],[FN,TP]]"],
                   f"Confusion matrix - {primary} Decision Tree (held-out test set, n={len(yte)})", out / "confusion_matrix.png")
    for name in models:
        plot_confusion(metrics[name]["confusion_matrix_[[TN,FP],[FN,TP]]"],
                       f"Confusion matrix - {name} Decision Tree (test set, n={len(yte)})",
                       out / "plots" / f"confusion_matrix_{name}.png")
    truncated, shown, full_depth = plot_tree_view(sel, feature_columns, args.tree_plot_depth,
                                                  out / "decision_tree_visualization.png",
                                                  f"{primary} Decision Tree")
    plot_importance(imp, out / "feature_importance.png", title=f"Feature importance - {primary} Decision Tree")
    plot_curves(yte, {k: scores[k] for k in models}, out / "roc_curve.png", out / "precision_recall_curve.png")
    plot_ablation(abl, out / "plots" / "missing_indicator_ablation.png")
    timings["plots_s"] = time.perf_counter() - t0

    # ---- configuration / reproducibility ----------------------------------------------------------------------
    timings["total_before_validation_s"] = time.perf_counter() - t_start
    config = {
        "random_seed": seed, "environment": env, "command_line_arguments": vars(args),
        "data": {"n_train": len(Xtr), "n_test": len(Xte), "n_features": len(feature_columns),
                 "train_class_counts": {"Genuine": int((ytr == 0).sum()), "Sybil": int((ytr == 1).sum())},
                 "test_class_counts": {"Genuine": int((yte == 0).sum()), "Sybil": int((yte == 1).sum())},
                 "train_senders": int(groups_tr.nunique()), "test_senders": int(mte["reported_id"].nunique()),
                 "genuine_senders_train": int(n_gen_senders_tr),
                 "genuine_senders_test": int(mte["reported_id"][yte == 0].nunique()),
                 "feature_columns": feature_columns, "missing_indicator_features": MISSING_INDICATORS,
                 "input_sha256": hashes_before},
        "models": {n: {"class": "sklearn.tree.DecisionTreeClassifier", **config_params[n], "random_state": seed}
                   for n in models},
        "tuning": {"performed": tuning_feasible, "search_space": SEARCH_SPACE,
                   "full_grid_size": int(np.prod([len(v) for v in SEARCH_SPACE.values()])),
                   "configurations_evaluated": None if tuning_df is None else int(len(tuning_df)),
                   "cv": f"{args.cv_folds}-fold grouped (groups = reported_id from train_metadata.csv), class-stratified: "
                         "each fold holds out exactly one genuine sender; deterministic custom splitter",
                   "selection_metric": "pooled out-of-fold macro-F1 (all training rows predicted by a model that never saw "
                                       "their sender); ties -> mean per-fold macro-F1, then fewer leaves",
                   "selected_params": best_params, "uses_training_data_only": True},
        "ablation": {"removed_features": MISSING_INDICATORS, "n_features_A": len(feature_columns),
                     "n_features_B": len(no_ind_cols), "primary_config": primary},
        "tree_visualization": {"truncated": truncated, "levels_shown": shown, "full_depth": full_depth},
        "timings_seconds": timings,
    }
    jdump(config, out / "model_configuration.json")

    # ---- validation (task section 14) -----------------------------------------------------------------------------
    LOG.info("--- Validation checks ---")
    r = all_checks
    check(r, "val: models reload and predict identically on correctly ordered features",
          all((joblib.load(out / f"decision_tree_{n}.joblib").predict(Xte[feature_columns]) == preds[n]).all()
              and list(joblib.load(out / f"decision_tree_{n}.joblib").feature_names_in_) == feature_columns
              for n in models), f"models: {list(models)}")
    saved = pd.read_csv(out / "test_predictions.csv")
    check(r, "val: saved prediction rows == test rows", len(saved) == len(Xte) == len(yte), f"{len(saved)} rows")
    check(r, "val: saved predictions are aligned with test metadata row_id order",
          (saved["row_id"].to_numpy() == mte["row_id"].to_numpy()).all())
    for n in models:
        cmn = np.array(metrics[n]["confusion_matrix_[[TN,FP],[FN,TP]]"])
        check(r, f"val: {n} confusion matrix sums to {len(yte)}", cmn.sum() == len(yte), f"sum={cmn.sum()}")
        re = compute_metrics(saved["y_true"], saved[f"{n}_pred"], saved[f"{n}_proba_sybil"])
        keys = ["accuracy", "balanced_accuracy", "macro_f1", "mcc", "roc_auc", "pr_auc_average_precision",
                "recall_genuine", "recall_sybil", "precision_sybil"]
        same = all(abs(re[k] - json.load(open(out / {"baseline": "baseline_metrics.json", "balanced": "balanced_metrics.json",
                                                      "best": "best_model_metrics.json"}[n]))[k]) < 1e-12 for k in keys)
        check(r, f"val: {n} metrics JSON == metrics recomputed from saved predictions", same)
    if tuning_feasible:
        check(r, "val: tuning used training rows only (all CV indices < n_train, groups all from train metadata)",
              all(va.max() < len(Xtr) and tr.max() < len(Xtr) for tr, va in folds)
              and set(groups_tr.unique()).isdisjoint(set(mte["reported_id"].unique())))
        check(r, "val: best config chosen from CV table rank 1 (no test information)",
              params_key(best_params) == params_key({k: (None if str(tuning_df.iloc[0][k]) == "None" else
                                                          (int(tuning_df.iloc[0][k]) if k in ("min_samples_split", "min_samples_leaf", "max_depth") and str(tuning_df.iloc[0][k]) != "None" else tuning_df.iloc[0][k]))
                                                      for k in SEARCH_SPACE}))
    check(r, "val: ablation removes exactly the 2 missing indicators",
          set(feature_columns) - set(no_ind_cols) == set(MISSING_INDICATORS) and len(no_ind_cols) == len(feature_columns) - 2
          and all(c in Xtr.columns for c in no_ind_cols))
    check(r, "val: control C (indicators set to constant 0, 56 columns) reproduces A when indicators are unused",
          all(ctrl_equal[n] for n in models if not used_ind[n]), f"used_indicators={used_ind}, identical={ctrl_equal}")
    check(r, "val: same train/test rows and seed used in ablation (A reproduces saved model predictions)", True,
          "asserted during the ablation run")
    cd = pd.read_csv(data_dir / "class_distribution.csv")
    ref = cd[cd["dataset"] == "test"].set_index("label")["count"].to_dict()
    check(r, "val: test class distribution equals class_distribution.csv (no resampling)",
          ref == {0: int((yte == 0).sum()), 1: int((yte == 1).sum())},
          f"Genuine {(yte == 0).sum()}, Sybil {(yte == 1).sum()}")
    hashes_after = {f: sha256(data_dir / f) for f in input_files}
    check(r, "val: preprocessing input files unchanged by this run (SHA-256 before == after)", hashes_before == hashes_after,
          f"{len(input_files)} files")
    expected = ["decision_tree_baseline.joblib", "decision_tree_balanced.joblib", "baseline_metrics.json",
                "balanced_metrics.json", "classification_report.txt", "model_comparison.csv",
                "missing_indicator_ablation.csv", "feature_importance.csv", "confusion_matrix.png",
                "decision_tree_visualization.png", "feature_importance.png", "roc_curve.png",
                "precision_recall_curve.png", "model_configuration.json", "test_predictions.csv",
                "plots/missing_indicator_ablation.png", "selected_tree_rules.txt", "ablation_seed_sensitivity.csv", "error_analysis_by_attack_type.csv", "error_analysis_genuine_senders.csv"]
    if tuning_feasible:
        expected += ["decision_tree_best.joblib", "best_model_metrics.json", "hyperparameter_tuning_results.csv"]
    gone = [f for f in expected if not (out / f).exists() or (out / f).stat().st_size == 0]
    check(r, "val: all expected output files exist and are non-empty", not gone, f"missing: {gone}" if gone else f"{len(expected)} files")
    unreadable = []
    for f in expected:
        try:
            p = out / f
            if f.endswith(".csv"):
                pd.read_csv(p)
            elif f.endswith(".json"):
                json.load(open(p))
            elif f.endswith(".joblib"):
                joblib.load(p)
            elif f.endswith(".png"):
                plt.imread(p)
        except Exception as e:  # pragma: no cover
            unreadable.append((f, repr(e)))
    check(r, "val: all outputs readable (CSV/JSON/joblib/PNG parse)", not unreadable, str(unreadable) if unreadable else "")

    all_ok = all(ok for _, ok, _ in r)
    timings["total_s"] = time.perf_counter() - t_start
    config["timings_seconds"] = timings
    config["validation"] = [{"check": n, "passed": ok, "detail": dt} for n, ok, dt in r]
    jdump(config, out / "model_configuration.json")
    ctx = dict(out=out, env=env, config=config, metrics=metrics, models=models, config_params=config_params,
               imp=imp, abl=abl, tuning_df=tuning_df, best_params=best_params, primary=primary, preds_df=pred_df,
               ea=pd.read_csv(out / "error_analysis_by_attack_type.csv"),
               ea_g=pd.read_csv(out / "error_analysis_genuine_senders.csv"),
               checks=r, timings=timings, truncated=(truncated, shown, full_depth), abl_importance=abl_importance,
               imp_pairs=imp_pairs, diag_df=diag_df, ctrl_equal=ctrl_equal, used_ind=used_ind, folds_detail=check_folds(folds, ytr, groups_tr)[1] if tuning_feasible else "",
               args=vars(args), n_gen_senders_tr=n_gen_senders_tr)
    write_report(ctx)
    check(r, "val: implementation_report.txt written", (out / "implementation_report.txt").stat().st_size > 0)
    all_ok = all(ok for _, ok, _ in r)
    LOG.info("Validation: %d/%d checks passed. Total runtime %.1fs.", sum(ok for _, ok, _ in r), len(r), timings["total_s"])
    LOG.info("RESULT: %s", "ALL CHECKS PASSED" if all_ok else "SOME CHECKS FAILED")
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
