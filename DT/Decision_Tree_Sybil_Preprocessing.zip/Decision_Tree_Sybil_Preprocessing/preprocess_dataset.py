#!/usr/bin/env python3
"""
Part 1 (revised) - Sybil-specific preprocessing for a VANET Decision Tree experiment.

Binary task built from the ORIGINAL dataset:
    class 0 = Genuine   (attack_type == 'Genuine', source label 0)
    class 1 = Sybil     (attack_type in the four Sybil variants, source label 1)
    all other attack families are EXCLUDED (not relabelled, not in either class).

No classifier is trained here. Usage:
    python preprocess_dataset.py                          # reads two_bsm_clean.csv next to this script
    python preprocess_dataset.py --input X.csv --output-dir out/

Pipeline: load -> verify labels -> select subset -> row-wise cleaning (no learning) ->
sender-grouped stratified 80/20 split -> constant-feature removal and median imputation
fitted on TRAIN only -> save -> validate saved files -> write reports.
"""
import argparse
import hashlib
import json
import re
import sys
import tempfile
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer

# --------------------------------------------------------------------------- #
# Configuration
# --------------------------------------------------------------------------- #
SEED = 42
TEST_SIZE = 0.20
TARGET = "label"                  # NEW binary target (0 Genuine / 1 Sybil)
SOURCE_LABEL = "source_label"     # original 0/1 'label' column, kept in metadata only
GROUP_COL = "reported_id"         # sender id -> groups for the split
TYPE_COL = "attack_type"
FOLD_COL = "fold"
GENUINE_NAME = "Genuine"
EXPECTED_SYBIL = ["DoSRandomSybil", "GridSybil", "DoSDisruptiveSybil", "DataReplaySybil"]
DROP_EXACT_DUPLICATES = False     # repeated identical BSMs are kept (see report)
ABSOLUTE_TIME_COLS = ["bsm1_creation_time", "bsm1_arrival_time",
                      "bsm2_creation_time", "bsm2_arrival_time"]
META_COLS = ["row_id", GROUP_COL, FOLD_COL, TYPE_COL, SOURCE_LABEL]
STABILITY_SEEDS = range(100)

DATA_FILES = ["X_train.csv", "X_test.csv", "y_train.csv", "y_test.csv", "train_processed.csv",
              "test_processed.csv", "train_metadata.csv", "test_metadata.csv", "feature_columns.json"]
GENERATED_FILES = DATA_FILES + [
    "preprocessor.joblib", "target_mapping.json", "preprocessing_config.json",
    "dataset_inspection_report.txt", "feature_exclusion_report.csv", "class_distribution.csv",
    "excluded_attack_families.csv", "plots/class_distribution.png", "plots/sybil_variants.png"]


def log(msg=""):
    print(msg, flush=True)


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


# --------------------------------------------------------------------------- #
# Loading, label verification, subset selection
# --------------------------------------------------------------------------- #
def load_and_verify(path):
    """Read the raw CSV and verify that the label structure matches the task definition."""
    try:
        df = pd.read_csv(path)
    except FileNotFoundError:
        sys.exit(f"ERROR: input file not found: {path}. Put two_bsm_clean.csv next to the script or use --input.")
    except Exception as e:
        sys.exit(f"ERROR: could not read {path}: {e}")
    need = ["label", GROUP_COL, TYPE_COL, FOLD_COL] + ABSOLUTE_TIME_COLS + \
           ["bsm1_width", "bsm1_length", "bsm2_width", "bsm2_length"]
    miss = [c for c in need if c not in df.columns]
    if miss:
        sys.exit(f"ERROR: expected columns missing from dataset: {miss}")
    types = set(df[TYPE_COL].unique())
    found_sybil = sorted(t for t in types if re.search("sybil", t, re.I))
    if set(found_sybil) != set(EXPECTED_SYBIL):
        sys.exit(f"ERROR: Sybil categories in data {found_sybil} differ from expected {sorted(EXPECTED_SYBIL)}. "
                 "Please clarify the class definition before proceeding.")
    if GENUINE_NAME not in types:
        sys.exit(f"ERROR: no '{GENUINE_NAME}' category found; genuine class cannot be identified.")
    if not ((df["label"] == 0) == (df[TYPE_COL] == GENUINE_NAME)).all():
        sys.exit("ERROR: source label 0 does not coincide with attack_type == 'Genuine'; genuine class unverified.")
    if not (df.loc[df[TYPE_COL].isin(EXPECTED_SYBIL), "label"] == 1).all():
        sys.exit("ERROR: some Sybil rows carry source label != 1; original labels contradict the definition.")
    return df


def select_subset(df):
    """Keep Genuine + Sybil rows; build the new binary target; keep original label/row id as metadata."""
    keep = df[TYPE_COL].isin([GENUINE_NAME] + EXPECTED_SYBIL)
    sub = df[keep].copy()
    sub["row_id"] = sub.index.values                 # position in the ORIGINAL file
    sub[SOURCE_LABEL] = sub["label"]                 # original label (metadata only)
    sub[TARGET] = sub[TYPE_COL].isin(EXPECTED_SYBIL).astype(int)
    excl = df[~keep].groupby(TYPE_COL).agg(rows_excluded=("label", "size"),
                                            senders=(GROUP_COL, "nunique")).reset_index()
    return sub, excl.sort_values("rows_excluded", ascending=False)


# --------------------------------------------------------------------------- #
# Row-wise cleaning / feature engineering (nothing is learned -> safe pre-split)
# --------------------------------------------------------------------------- #
def clean_rows(df):
    """
    Derived features (also needed to use preprocessor.joblib on new data):
      bsm{1,2}_delay   = arrival - creation, NaN where arrival_time == 0 (invalid sentinel)
      dt_creation_1_2  = bsm1_creation - bsm2_creation (relative gap; absolute clocks are excluded)
      bsm{1,2}_placeholder = 1 if width==0 and length==0 (placeholder BSM)
    """
    out = df.copy()
    for k in ("bsm1", "bsm2"):
        arr, cre = out[f"{k}_arrival_time"], out[f"{k}_creation_time"]
        out[f"{k}_delay"] = np.where(arr > 0, arr - cre, np.nan)
    out["dt_creation_1_2"] = out["bsm1_creation_time"] - out["bsm2_creation_time"]
    for k in ("bsm1", "bsm2"):
        out[f"{k}_placeholder"] = ((out[f"{k}_width"] == 0) & (out[f"{k}_length"] == 0)).astype(int)
    if DROP_EXACT_DUPLICATES:
        out = out.drop_duplicates()
    return out


# --------------------------------------------------------------------------- #
# Sender-grouped, class-stratified split
# --------------------------------------------------------------------------- #
def stratified_group_split(groups_df, test_size, seed):
    """
    groups_df: one row per sender with columns [GROUP_COL, 'n' (rows), TARGET].
    Per class: shuffle senders (seed) and send a sender to test while that moves the test row
    count closer to test_size * (rows of that class). Whole senders only. Returns set of test ids.
    """
    rng = np.random.RandomState(seed)
    test_ids = []
    for _, sub in groups_df.groupby(TARGET):
        sub = sub.sample(frac=1.0, random_state=rng).reset_index(drop=True)
        target_rows, acc = test_size * sub.n.sum(), 0
        for _, r in sub.iterrows():
            if abs(acc + r.n - target_rows) < abs(acc - target_rows):
                test_ids.append(r[GROUP_COL])
                acc += r.n
    return set(test_ids)


def split_stability(gdf):
    """How much does the genuine part of the test set depend on the seed? (data property, no model)"""
    rows = []
    for s in STABILITY_SEEDS:
        t = stratified_group_split(gdf, TEST_SIZE, s)
        d = gdf[gdf[GROUP_COL].isin(t)]
        rows.append({"seed": s, "test_frac": d.n.sum() / gdf.n.sum(),
                     "genuine_test_senders": int(((d[TARGET] == 0)).sum()),
                     "genuine_test_rows": int(d[d[TARGET] == 0].n.sum()),
                     "sybil_test_rows": int(d[d[TARGET] == 1].n.sum())})
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------- #
# Inspection report
# --------------------------------------------------------------------------- #
def inspection_report(df, sub, excl, path_in):
    L = []
    add = L.append
    add("DATASET INSPECTION REPORT (original dataset + Sybil-specific subset)")
    add("=" * 78)
    add(f"File: {Path(path_in).name} (CSV)   Rows: {len(df)}   Columns: {df.shape[1]}")
    add("")
    add("PART I - ORIGINAL DATASET")
    add(f"{'column':24s}{'dtype':10s}{'missing':>8s}{'miss%':>8s}{'unique':>8s}{'min':>14s}{'max':>14s}")
    for c in df.columns:
        s = df[c]
        num = pd.api.types.is_numeric_dtype(s)
        add(f"{c:24s}{str(s.dtype):10s}{s.isna().sum():8d}{100*s.isna().mean():8.2f}{s.nunique():8d}"
            f"{(f'{s.min():.4g}' if num else ''):>14s}{(f'{s.max():.4g}' if num else ''):>14s}")
    add("")
    add("Sample rows (first 3, transposed):")
    add(df.head(3).T.to_string())
    add("")
    dup = df.duplicated()
    add(f"Exact duplicate rows: {dup.sum()} ({100*dup.mean():.2f}%); infinite values: "
        f"{int(np.isinf(df.select_dtypes('number')).sum().sum())}; missing values: {int(df.isna().sum().sum())}")
    add("Original attack_type distribution:")
    add(df[TYPE_COL].value_counts().to_string())
    add("Original label x attack_type: label 0 <=> 'Genuine', label 1 <=> every attack family (verified).")
    g = df.groupby(GROUP_COL)[["label"]].nunique()
    add(f"Senders ({GROUP_COL}): {df[GROUP_COL].nunique()}; senders with >1 label: {(g['label'] > 1).sum()}")
    add("")
    add("PART II - SYBIL-SPECIFIC SUBSET")
    add(f"Sybil categories verified in data: {sorted(EXPECTED_SYBIL)}")
    add("Class 0 = attack_type 'Genuine'; class 1 = the four Sybil categories; others excluded.")
    n0, n1 = int((sub[TARGET] == 0).sum()), int((sub[TARGET] == 1).sum())
    add(f"Retained rows: {len(sub)} (genuine {n0} = {100*n0/len(sub):.2f}%, Sybil {n1} = {100*n1/len(sub):.2f}%)")
    add(f"Excluded rows (other attack families): {int(excl.rows_excluded.sum())}")
    add(excl.to_string(index=False))
    add("")
    per = sub.groupby(TYPE_COL).agg(rows=("row_id", "size"), senders=(GROUP_COL, "nunique"),
                                    max_rows_per_sender=(GROUP_COL, lambda s: s.value_counts().max()))
    add("Retained categories (rows / senders):")
    add(per.to_string())
    add("")
    gen = sub[sub[TARGET] == 0].groupby(GROUP_COL).agg(rows=("row_id", "size"), fold=(FOLD_COL, "first"))
    add(f"GENUINE SENDERS: only {len(gen)} independent genuine senders exist:")
    add(gen.to_string())
    sy = sub[sub[TARGET] == 1].groupby(GROUP_COL).size()
    add(f"Sybil senders: {len(sy)}; rows/sender median {sy.median():.0f}, max {sy.max()}")
    add(f"Senders with more than one label in the subset: "
        f"{int((sub.groupby(GROUP_COL)[TARGET].nunique() > 1).sum())} -> sender grouping is valid.")
    add("")
    add("Fold x class (author's folds, NOT used for splitting):")
    add(pd.crosstab(sub[FOLD_COL], sub[TARGET]).to_string())
    add("")
    add("LEAKAGE / SUITABILITY REVIEW")
    add(f"- {GROUP_COL}: genuine ids range {sub[sub[TARGET]==0][GROUP_COL].min()}..{sub[sub[TARGET]==0][GROUP_COL].max()}, "
        f"Sybil ids {sub[sub[TARGET]==1][GROUP_COL].min()}..{sub[sub[TARGET]==1][GROUP_COL].max()} "
        "(fabricated Sybil ids, many far above any genuine id) -> not a model feature; used only as split group.")
    g0 = sub[sub[TARGET] == 0]
    for c in ["bsm1_creation_time", "bsm1_pos_x", "bsm1_pos_y"]:
        add(f"- {c}: genuine [{g0[c].min():.1f}, {g0[c].max():.1f}]; Sybil [{sub[sub[TARGET]==1][c].min():.1f}, "
            f"{sub[sub[TARGET]==1][c].max():.1f}]")
    s1 = sub[sub[TARGET] == 1]
    in_t = s1.bsm1_creation_time.between(g0.bsm1_creation_time.min(), g0.bsm1_creation_time.max()).mean()
    in_p = (s1.bsm1_pos_x.between(g0.bsm1_pos_x.min(), g0.bsm1_pos_x.max()) &
            s1.bsm1_pos_y.between(g0.bsm1_pos_y.min(), g0.bsm1_pos_y.max())).mean()
    add(f"  Sybil rows inside genuine time range: {100*in_t:.1f}%; inside genuine position bounding box: {100*in_p:.1f}%")
    for k in ("bsm1", "bsm2"):
        z = (sub[f"{k}_arrival_time"] == 0)
        add(f"- {k}_arrival_time == 0 (invalid sentinel): genuine {int(z[sub[TARGET]==0].sum())} "
            f"({100*z[sub[TARGET]==0].mean():.1f}%), Sybil {int(z[sub[TARGET]==1].sum())} ({100*z[sub[TARGET]==1].mean():.1f}%)")
    add(f"- Placeholder BSMs (width==0 & length==0): "
        f"{int(((sub.bsm1_width==0)&(sub.bsm1_length==0)).sum())} bsm1 rows, "
        f"{int(((sub.bsm2_width==0)&(sub.bsm2_length==0)).sum())} bsm2 rows in this subset")
    d = sub.drop(columns=["row_id"]).duplicated()
    add(f"- Exact duplicate rows within the subset: {int(d.sum())} (by attack_type: "
        f"{sub.drop(columns=['row_id'])[d][TYPE_COL].value_counts().to_dict()})")
    add("- Extreme plausibility values (e.g. kPSCSP down to -1006) are attack behaviour, not removed.")
    return "\n".join(L)


# --------------------------------------------------------------------------- #
# Build: split + fit on train + write all data files
# --------------------------------------------------------------------------- #
def build(df_raw, out, input_path, full=True):
    """Run the whole pipeline and write outputs to `out`. full=False skips reports/plots (repro rerun)."""
    out = Path(out)
    (out / "plots").mkdir(parents=True, exist_ok=True)
    sub, excl = select_subset(df_raw)
    work = clean_rows(sub)

    exclusion = {
        GROUP_COL: "Sender identifier; Sybil ids are fabricated (very large values), so the id would reveal the class. "
                   "Used only to group the split.",
        TYPE_COL: "Attack category; it directly defines the target (leakage). Kept in metadata only.",
        FOLD_COL: "Dataset author's CV fold id; experimental metadata, not a message property.",
        TARGET: "Target column (0 Genuine / 1 Sybil).",
        SOURCE_LABEL: "Original binary label (genuine vs any attack); source label, kept in metadata only.",
        "row_id": "Technical row identifier of the original file (metadata only).",
    }
    for c in ABSOLUTE_TIME_COLS:
        exclusion[c] = ("Absolute simulation clock: not a physical message property, and with only 8 genuine senders a "
                        "tree could memorise their time windows. Replaced by relative features "
                        "(bsm1_delay, bsm2_delay, dt_creation_1_2).")
    for k in ("bsm1", "bsm2"):
        exclusion[f"{k}_width"] = "Collinear with length and with the placeholder flag; constant in this subset."
        exclusion[f"{k}_length"] = "Collinear with width and with the placeholder flag; constant in this subset."
    feature_cols = [c for c in work.columns if c not in exclusion]

    # ---- split BEFORE anything is learned --------------------------------
    if (work.groupby(GROUP_COL)[TARGET].nunique() > 1).any():
        sys.exit("ERROR: a sender has more than one class; grouped split invalid.")
    gdf = work.groupby(GROUP_COL).agg(n=(TARGET, "size"), **{TARGET: (TARGET, "first")}).reset_index()
    test_ids = stratified_group_split(gdf, TEST_SIZE, SEED)
    is_test = work[GROUP_COL].isin(test_ids)
    tr, te = work[~is_test].copy(), work[is_test].copy()

    # ---- constant features: determined on TRAIN only ---------------------
    const = [c for c in feature_cols if tr[c].nunique(dropna=True) <= 1]
    for c in const:
        exclusion[c] = "Constant in the training data (no information in this Sybil-specific subset)."
    feature_cols = [c for c in feature_cols if c not in const]

    # ---- imputer fitted on TRAIN only -------------------------------------
    imputer = SimpleImputer(strategy="median", add_indicator=True)
    imputer.fit(tr[feature_cols])
    ind_cols = [f"{feature_cols[i]}_was_missing" for i in imputer.indicator_.features_]
    final_cols = feature_cols + ind_cols

    def transform(d):
        X = pd.DataFrame(imputer.transform(d[feature_cols]), columns=final_cols, index=d.index)
        X[ind_cols] = X[ind_cols].astype(int)
        return X

    X_train, X_test = transform(tr), transform(te)
    y_train, y_test = tr[TARGET].astype(int), te[TARGET].astype(int)

    X_train.to_csv(out / "X_train.csv", index=False)
    X_test.to_csv(out / "X_test.csv", index=False)
    y_train.to_frame().to_csv(out / "y_train.csv", index=False)
    y_test.to_frame().to_csv(out / "y_test.csv", index=False)
    pd.concat([X_train.reset_index(drop=True), y_train.reset_index(drop=True)], axis=1).to_csv(
        out / "train_processed.csv", index=False)
    pd.concat([X_test.reset_index(drop=True), y_test.reset_index(drop=True)], axis=1).to_csv(
        out / "test_processed.csv", index=False)
    tr[META_COLS].to_csv(out / "train_metadata.csv", index=False)
    te[META_COLS].to_csv(out / "test_metadata.csv", index=False)
    (out / "feature_columns.json").write_text(json.dumps(final_cols, indent=2))
    ctx = dict(sub=sub, excl=excl, work=work, tr=tr, te=te, gdf=gdf, exclusion=exclusion,
               feature_cols=feature_cols, final_cols=final_cols, const=const, imputer=imputer,
               ind_cols=ind_cols, test_ids=test_ids)
    if not full:
        return ctx

    joblib.dump({"imputer": imputer, "input_columns": feature_cols, "output_columns": final_cols,
                 "note": "Input frame must contain the derived columns produced by clean_rows()."},
                out / "preprocessor.joblib")
    (out / "target_mapping.json").write_text(json.dumps({
        "target_column": TARGET,
        "mapping": {"0": {"name": "Genuine", "included_attack_types": [GENUINE_NAME]},
                    "1": {"name": "Sybil", "included_attack_types": EXPECTED_SYBIL}},
        "excluded_attack_types": sorted(excl[TYPE_COL].tolist()),
        "note": "Excluded attack families are in neither class. Original label kept as 'source_label' in metadata."},
        indent=2))
    pd.DataFrame([{"column": k, "reason": v} for k, v in exclusion.items()]).to_csv(
        out / "feature_exclusion_report.csv", index=False)
    excl.to_csv(out / "excluded_attack_families.csv", index=False)

    def dist(d, name):
        vc = d[TARGET].value_counts().sort_index()
        return pd.DataFrame({"dataset": name, "label": vc.index, "class_name": ["Genuine", "Sybil"],
                             "count": vc.values, "percent": (100 * vc.values / len(d)).round(3)})
    cd = pd.concat([dist(work, "filtered_original"), dist(tr, "train"), dist(te, "test")])
    cd.to_csv(out / "class_distribution.csv", index=False)
    ctx["class_dist"] = cd

    config = {
        "input_file": Path(input_path).name, "task": "binary: 0 Genuine vs 1 Sybil (other attacks excluded)",
        "seed": SEED, "test_size": TEST_SIZE, "target": TARGET, "group_column": GROUP_COL,
        "split_strategy": "whole senders (reported_id), per-class greedy stratification, deterministic",
        "sybil_categories": EXPECTED_SYBIL, "genuine_category": GENUINE_NAME,
        "drop_exact_duplicates": DROP_EXACT_DUPLICATES,
        "sentinel_rule": "*_arrival_time == 0 -> delay = NaN",
        "derived_features": ["bsm1_delay", "bsm2_delay", "dt_creation_1_2", "bsm1_placeholder", "bsm2_placeholder"],
        "constant_features_removed_(train-determined)": const,
        "imputer": {"strategy": "median", "add_indicator": True, "fitted_on": "train only"},
        "scaling": "none", "resampling": "none (natural class distribution kept)",
        "n_features": len(final_cols), "n_train": len(tr), "n_test": len(te),
        "input_columns_for_preprocessor": feature_cols, "final_columns": final_cols}
    (out / "preprocessing_config.json").write_text(json.dumps(config, indent=2))

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(6, 4))
    cd.pivot(index="dataset", columns="class_name", values="count").loc[
        ["filtered_original", "train", "test"]].plot.bar(ax=ax)
    ax.set_title("Binary class counts (Genuine vs Sybil)"); ax.set_ylabel("rows")
    ax.tick_params(axis="x", rotation=0)
    plt.tight_layout(); plt.savefig(out / "plots" / "class_distribution.png", dpi=120); plt.close()
    fig, ax = plt.subplots(figsize=(7, 3.5))
    sub[TYPE_COL].value_counts().sort_values().plot.barh(ax=ax)
    ax.set_title("Rows per retained category"); ax.set_xlabel("rows")
    plt.tight_layout(); plt.savefig(out / "plots" / "sybil_variants.png", dpi=120); plt.close()
    return ctx


# --------------------------------------------------------------------------- #
# Validation on the SAVED files
# --------------------------------------------------------------------------- #
def validate(out, ctx, raw_hash_before, raw_hash_after, repro_ok, script_path):
    out = Path(out)
    res = []

    def chk(name, ok, detail=""):
        res.append((name, bool(ok), detail))

    exist = [f for f in GENERATED_FILES if not (out / f).exists()]
    Xtr, Xte = pd.read_csv(out / "X_train.csv"), pd.read_csv(out / "X_test.csv")
    ytr, yte = pd.read_csv(out / "y_train.csv"), pd.read_csv(out / "y_test.csv")
    trp, tep = pd.read_csv(out / "train_processed.csv"), pd.read_csv(out / "test_processed.csv")
    mtr, mte = pd.read_csv(out / "train_metadata.csv"), pd.read_csv(out / "test_metadata.csv")
    cols = json.loads((out / "feature_columns.json").read_text())
    cd = pd.read_csv(out / "class_distribution.csv")
    pre = joblib.load(out / "preprocessor.joblib")
    tm = json.loads((out / "target_mapping.json").read_text())
    json.loads((out / "preprocessing_config.json").read_text())
    pd.read_csv(out / "feature_exclusion_report.csv")

    chk("1. all generated files exist and open", not exist, f"missing: {exist}" if exist else f"{len(GENERATED_FILES)} files")
    chk("2. target contains only 0/1", set(ytr.label) <= {0, 1} and set(yte.label) <= {0, 1})
    chk("3. class 0 only Genuine (metadata)",
        set(mtr[ytr.label == 0][TYPE_COL]) | set(mte[yte.label == 0][TYPE_COL]) == {GENUINE_NAME}
        and (pd.concat([mtr, mte])[SOURCE_LABEL][pd.concat([ytr, yte]).label.values == 0] == 0).all())
    s1 = set(mtr[ytr.label == 1][TYPE_COL]) | set(mte[yte.label == 1][TYPE_COL])
    chk("4. class 1 only verified Sybil categories", s1 <= set(EXPECTED_SYBIL),
        f"present: {sorted(s1)}")
    allt = set(mtr[TYPE_COL]) | set(mte[TYPE_COL])
    chk("5. no other attack family in final data", allt <= set(EXPECTED_SYBIL) | {GENUINE_NAME})
    leak = {TARGET, TYPE_COL, GROUP_COL, FOLD_COL, SOURCE_LABEL, "row_id"} | set(ABSOLUTE_TIME_COLS)
    chk("6. target / leakage-prone columns absent from X", not (leak & set(Xtr.columns)) and not (leak & set(Xte.columns))
        and not any(Xtr[c].equals(ytr.label) for c in Xtr.columns))
    chk("7. train/test feature names and order identical", list(Xtr.columns) == list(Xte.columns) == cols)
    chk("8. X/y row counts match per split", len(Xtr) == len(ytr) == len(mtr) == len(trp) and
        len(Xte) == len(yte) == len(mte) == len(tep))
    chk("9. no sender in both train and test", set(mtr[GROUP_COL]).isdisjoint(set(mte[GROUP_COL])),
        f"{mtr[GROUP_COL].nunique()} train / {mte[GROUP_COL].nunique()} test senders")
    both = [Xtr, Xte]
    chk("10. no NaN / inf / non-numeric in X",
        all(not d.isna().any().any() and not np.isinf(d.values).any() and
            all(pd.api.types.is_numeric_dtype(t) for t in d.dtypes) for d in both))
    tr, te = ctx["tr"], ctx["te"]
    chk("11. imputer fitted on train only (stored medians == train medians)",
        np.allclose(pre["imputer"].statistics_, tr[ctx["feature_cols"]].median(skipna=True).values, equal_nan=True))
    chk("12. artifacts reload and reproduce X_test",
        np.allclose(pre["imputer"].transform(te[pre["input_columns"]]), Xte.values) and pre["output_columns"] == cols
        and tm["mapping"]["1"]["included_attack_types"] == EXPECTED_SYBIL)
    chk("13. rerun reproduces all data files (checked by rebuilding into a temp dir)", repro_ok)
    yy = pd.concat([ytr, yte]).label
    cnt = {(r.dataset, r.label): r["count"] for _, r in cd.iterrows()}
    ok14 = (cnt[("train", 0)] == (ytr.label == 0).sum() and cnt[("train", 1)] == (ytr.label == 1).sum() and
            cnt[("test", 0)] == (yte.label == 0).sum() and cnt[("test", 1)] == (yte.label == 1).sum() and
            cnt[("filtered_original", 0)] == (yy == 0).sum() and cnt[("filtered_original", 1)] == (yy == 1).sum())
    frac = len(Xte) / (len(Xtr) + len(Xte))
    chk("14. class_distribution.csv equals counts in saved y files; split near 80/20", ok14 and abs(frac - 0.2) < 0.02,
        f"test fraction {100*frac:.2f}%")
    chk("15. original dataset unchanged (SHA-256 before == after run)", raw_hash_before == raw_hash_after)
    src = Path(script_path).read_text()
    forbidden = ["sklearn.tree", "sklearn.ensemble", "sklearn.neighbors", "sklearn.linear_model", "sklearn.svm",
                 "sklearn.metrics", "sklearn.model_selection"]
    imports = [ln for ln in src.splitlines() if re.match(r"\s*(import|from)\s", ln)]
    chk("16. no classifier / metrics imported by the script (static check of import lines)",
        not any(f in ln for ln in imports for f in forbidden))
    chk("extra. both classes in both splits", set(ytr.label) == {0, 1} == set(yte.label),
        f"test genuine rows: {(yte.label==0).sum()}")
    return res


def file_hashes(d):
    return {f: sha256(Path(d) / f) for f in DATA_FILES}


def write_report(out, ctx, checks, stab, raw_sha, input_path):
    out = Path(out)
    ytr, yte = pd.read_csv(out / "y_train.csv").label, pd.read_csv(out / "y_test.csv").label
    Xtr = pd.read_csv(out / "X_train.csv")
    sub, excl, tr, te = ctx["sub"], ctx["excl"], ctx["tr"], ctx["te"]
    cd = pd.read_csv(out / "class_distribution.csv")
    n0, n1 = int((sub[TARGET] == 0).sum()), int((sub[TARGET] == 1).sum())
    z2 = lambda c: (sub[f"{c}_arrival_time"] == 0)
    g0 = sub[sub[TARGET] == 0]
    in_time = sub[sub[TARGET] == 1].bsm1_creation_time.between(
        g0.bsm1_creation_time.min(), g0.bsm1_creation_time.max()).mean()
    gtest = te[te[TARGET] == 0].groupby(GROUP_COL).size()
    gtrain = tr[tr[TARGET] == 0].groupby(GROUP_COL).size()
    R = ["PREPROCESSING REPORT - SYBIL-SPECIFIC (Genuine vs Sybil)", "=" * 78,
         f"Original dataset: {Path(input_path).name}, SHA-256 {raw_sha[:16]}... (unchanged by the run)", "",
         "1. TASK DEFINITION",
         f"Class 0 Genuine = attack_type '{GENUINE_NAME}' (source label 0).",
         f"Class 1 Sybil = attack_type in {EXPECTED_SYBIL} (source label 1). Names verified against the data.",
         "All other attack families are excluded (not relabelled, in neither class).", "",
         "2. ROWS RETAINED / EXCLUDED",
         f"Original rows: {int(excl.rows_excluded.sum()) + len(sub)}.  Retained: {len(sub)} "
         f"(Genuine {n0}, Sybil {n1}).  Excluded: {int(excl.rows_excluded.sum())}.",
         "Retained by category: " + str(sub[TYPE_COL].value_counts().to_dict()),
         "Excluded by attack family:", excl.to_string(index=False), "",
         "3. CLEANING DECISIONS",
         "- No missing, infinite or mistyped raw values.",
         f"- Invalid arrival_time == 0 treated as missing: bsm1 {int(z2('bsm1').sum())} rows "
         f"(genuine {int(z2('bsm1')[sub[TARGET]==0].sum())}), bsm2 {int(z2('bsm2').sum())} rows "
         f"(genuine {int(z2('bsm2')[sub[TARGET]==0].sum())}). Delay set to NaN, median-imputed (train median) and "
         "missing-indicator columns added.",
         "  WARNING: bsm2_arrival_time==0 occurs in "
         f"{100*z2('bsm2')[sub[TARGET]==1].mean():.1f}% of Sybil rows vs {100*z2('bsm2')[sub[TARGET]==0].mean():.1f}% of "
         "genuine rows, so 'bsm2_delay_was_missing' is strongly associated with the Sybil class. It may reflect how the "
         "dataset was logged rather than attacker behaviour; it was kept as instructed, but results that rely on it "
         "should be interpreted with care (consider an ablation in Part 2).",
         f"- Exact duplicates in subset: {int(sub.drop(columns=['row_id']).duplicated().sum())} (all GridSybil, repeated "
         "identical messages); kept - they stay inside one split because splitting is by sender.",
         "- Outliers not removed or clipped (extreme plausibility values carry attack signal).",
         f"- Constant features removed (determined on train): {ctx['const']}",
         "- No scaling, no resampling; natural class frequencies kept.", "",
         "4. TIMESTAMP / POSITION REVIEW",
         f"- Absolute timestamps excluded (simulation clock; {100*in_time:.1f}% of Sybil rows lie inside the genuine time range, so "
         "they add little legitimate signal while allowing scenario memorisation). Relative features kept.",
         "- Absolute positions (pos_x/pos_y, speed, accel, heading) retained as behavioural/physical features. Risk: "
         "genuine data come from 8 senders on specific roads, so location could act as a proxy for sender identity; "
         "a tree may partly learn 'where' rather than 'how'. Not removed because it is a physical message property.", "",
         "5. SPLIT",
         f"80/20, seed {SEED}, whole senders (reported_id), stratified per class by row count. "
         f"Train {len(tr)} rows / {tr[GROUP_COL].nunique()} senders; test {len(te)} rows / {te[GROUP_COL].nunique()} senders "
         f"({100*len(te)/len(sub):.2f}% of rows in test).",
         f"Genuine senders (id: rows) in test: { {int(k): int(v) for k, v in gtest.items()} } ; in train: { {int(k): int(v) for k, v in gtrain.items()} }",
         "Seed-sensitivity of the grouped split (100 seeds, data property only):",
         f"  genuine test rows min/median/max = {stab.genuine_test_rows.min()}/{stab.genuine_test_rows.median():.0f}/"
         f"{stab.genuine_test_rows.max()}; genuine test senders min/max = {stab.genuine_test_senders.min()}/"
         f"{stab.genuine_test_senders.max()}; overall test fraction min/max = {100*stab.test_frac.min():.1f}%/"
         f"{100*stab.test_frac.max():.1f}%.",
         f"  This split (seed {SEED}) has {int(gtest.sum())} genuine test rows from {len(gtest)} senders; it is the "
         f"{'lowest' if gtest.sum() <= stab.genuine_test_rows.min() else 'a mid/high'} value of that range.",
         "LIMITATION: with 8 genuine senders the genuine part of any single test set is a handful of senders and "
         "depends strongly on the seed. A grouped class-balanced split is feasible (both classes present in both sets) "
         "but statistically unstable for the genuine class. Alternatives for Part 2: grouped cross-validation on the "
         "training set (groups = reported_id in train_metadata.csv), leave-one-genuine-sender-out evaluation, or repeating "
         "the grouped split with several seeds. A random row split was NOT used. Also, Sybil ids emitted by one physical "
         "attacker would appear as different reported_ids (the dataset has no attacker id), so sender grouping may not "
         "fully separate attackers; the author's "
         "'fold' (in metadata) is a coarser alternative grouping (fold 2 contains no genuine rows).", "",
         "6. CLASS DISTRIBUTION", cd.to_string(index=False), "",
         f"7. FINAL FEATURES: {Xtr.shape[1]} columns ({len(ctx['feature_cols'])} numeric + {len(ctx['ind_cols'])} "
         f"missing-indicator: {ctx['ind_cols']})", "",
         "8. EXCLUDED COLUMNS", pd.DataFrame([{"column": k, "reason": v} for k, v in ctx["exclusion"].items()]).to_string(index=False),
         "", "9. VALIDATION RESULTS (performed by this script on the saved files)"]
    for name, ok, detail in checks:
        R.append(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f"  ({detail})" if detail else ""))
    R += ["",
          "Not covered inside the script: re-running from an extracted copy of the ZIP and confirming independence from "
          "files outside the folder; those were done manually when packaging (see delivery message).",
          "No classifier was trained and no performance metrics were computed."]
    (out / "preprocessing_report.txt").write_text("\n".join(R))


def main():
    here = Path(__file__).resolve().parent
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default=str(here / "two_bsm_clean.csv"))
    ap.add_argument("--output-dir", default=str(here))
    a = ap.parse_args()
    out = Path(a.output_dir)
    out.mkdir(parents=True, exist_ok=True)

    h0 = sha256(a.input) if Path(a.input).exists() else None
    df = load_and_verify(a.input)
    log(f"Loaded {df.shape[0]} rows x {df.shape[1]} columns; Sybil/Genuine labels verified")

    ctx = build(df, out, a.input, full=True)
    sub, excl = ctx["sub"], ctx["excl"]
    (out / "dataset_inspection_report.txt").write_text(inspection_report(df, sub, excl, a.input))
    log(f"Subset: {len(sub)} rows (genuine {(sub[TARGET]==0).sum()}, Sybil {(sub[TARGET]==1).sum()}); "
        f"excluded {int(excl.rows_excluded.sum())} rows of other attack families")
    log(f"Split: train {len(ctx['tr'])} / test {len(ctx['te'])}; features {len(ctx['final_cols'])}; "
        f"constant removed: {ctx['const']}")

    # reproducibility: rebuild into a temp directory and compare file hashes
    with tempfile.TemporaryDirectory() as tmp:
        build(df, tmp, a.input, full=False)
        repro_ok = file_hashes(tmp) == file_hashes(out)
    h1 = sha256(a.input)
    stab = split_stability(ctx["gdf"])
    checks = validate(out, ctx, h0, h1, repro_ok, __file__)
    log("\nVALIDATION")
    for n, ok, d in checks:
        log(f"  [{'PASS' if ok else 'FAIL'}] {n} {('- ' + d) if d else ''}")
    write_report(out, ctx, checks, stab, h1, a.input)
    if not (out / "preprocessing_report.txt").exists() or not all(ok for _, ok, _ in checks):
        sys.exit("VALIDATION FAILED - see messages above / preprocessing_report.txt")
    log("\n" + pd.read_csv(out / "class_distribution.csv").to_string(index=False))
    log("\nPart 1 (Sybil) complete. No model was trained.")


if __name__ == "__main__":
    main()
