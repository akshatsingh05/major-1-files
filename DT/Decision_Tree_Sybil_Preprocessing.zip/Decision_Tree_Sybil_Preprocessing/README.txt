VANET Sybil attack detection - Part 1 (revised): preprocessing for a Decision Tree
==================================================================================
PURPOSE
Prepare data for a later Decision Tree experiment that separates GENUINE traffic from SYBIL attacks.
This folder contains preprocessing only. No classifier was trained and no performance metrics were computed.
(The Decision Tree itself is Part 2 and is outside this task.)

CLASSES (target column 'label')
  0 = Genuine : attack_type 'Genuine'                       147 rows, 8 senders
  1 = Sybil   : DoSRandomSybil (778), GridSybil (305), DoSDisruptiveSybil (185), DataReplaySybil (27)
                                                           1,295 rows, 763 senders
Excluded (in neither class): the 15 other attack families, 7,607 rows
  (DoSDisruptive, DoSRandom, DoS, DataReplay, StaleMessages, ConstSpeed, RandomPos, ConstPosOffset,
   ConstPos, RandomPosOffset, RandomSpeed, Disruptive, ConstSpeedOffset, EventualStop, RandomSpeedOffset).
Counts per family: excluded_attack_families.csv.

INSTALL AND RUN
  pip install -r requirements.txt
  python preprocess_dataset.py              # uses two_bsm_clean.csv in this folder
  python preprocess_dataset.py --input FILE --output-dir DIR      # optional
The script verifies the labels, builds the subset, splits, fits preprocessing on train only, saves everything,
validates the saved files and writes preprocessing_report.txt (with the validation results). Reruns give identical data files.

PREPROCESSING SUMMARY
- Derived features: bsm1_delay, bsm2_delay (arrival - creation; NaN when arrival_time == 0, an invalid value),
  dt_creation_1_2, and width/length placeholder flags.
- Median imputation of the delays (fitted on train only) plus missing-indicator columns.
- Constant columns (determined on train) removed: bsm2_sP and both placeholder flags.
- Excluded from X (see feature_exclusion_report.csv): label, attack_type, source_label, row_id, reported_id, fold,
  the four absolute timestamps, width/length.
- Kept: duplicates (8 rows), outliers, absolute positions/speeds; no scaling, no resampling.
- 56 final features. IMPORTANT: bsm2_arrival_time == 0 occurs in 70.7% of Sybil rows vs 3.4% of genuine rows, so
  'bsm2_delay_was_missing' is strongly tied to the class and may be a logging artefact; consider an ablation in Part 2.

SPLIT
80/20 (seed 42) assigning whole senders (reported_id) to train or test, stratified per class by row count.
Train 1,155 rows (Genuine 119 / Sybil 1,036), test 287 rows (Genuine 28 / Sybil 259). No sender is in both sets.

LIMITATIONS
- Only 8 genuine senders exist. The test set holds 3 of them (28 rows); with other seeds it would hold 1 to 5 senders,
  so any genuine-class result on this single test set will be unstable. For Part 2 prefer grouped cross-validation
  (groups = reported_id from train_metadata.csv), leave-one-genuine-sender-out, or several grouped splits.
- Sybil ids from one physical attacker appear as different reported_ids (the data has no attacker id), so grouping by
  sender may not fully separate attackers.
- Genuine data come from few senders/places; absolute position may act as a sender proxy.

FILES
preprocess_dataset.py              complete pipeline
two_bsm_clean.csv                  original dataset (never modified)
X_train.csv X_test.csv             model features only (same columns, same order)
y_train.csv y_test.csv             binary target only
train_processed.csv test_processed.csv   features + label (same split)
train_metadata.csv test_metadata.csv     row_id, reported_id (groups), fold, attack_type, source_label - NOT features
preprocessor.joblib                dict with fitted imputer, input_columns, output_columns. Input frame must already contain
                                   the derived columns (use clean_rows() in the script, then
                                   imputer.transform(df[input_columns]))
feature_columns.json               ordered feature names
target_mapping.json                class definitions and included/excluded attack types
preprocessing_config.json          settings and decisions
dataset_inspection_report.txt      findings on the original data and the Sybil subset
preprocessing_report.txt           decisions, split, class counts, validation results
feature_exclusion_report.csv       excluded columns and reasons
class_distribution.csv             class counts/% for filtered original, train, test
excluded_attack_families.csv       rows/senders excluded per non-Sybil family (extra file)
plots/                             class_distribution.png, sybil_variants.png
requirements.txt                   packages (tested versions in comments)
