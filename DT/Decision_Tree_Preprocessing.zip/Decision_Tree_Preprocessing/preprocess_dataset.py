#!/usr/bin/env python3
"""
Part 1 - Dataset preprocessing for VANET Sybil/attack detection (Decision Tree).

Usage:
    python preprocess_dataset.py                       # expects two_bsm_clean.csv next to this script
    python preprocess_dataset.py --input path/to.csv --output-dir out/

What it does (no model is trained here):
  1. Loads and validates the CSV, writes dataset_inspection_report.txt
  2. Selects target 'label' (0 = Genuine, 1 = attack), excludes leaky/metadata columns
  3. Applies row-wise cleaning (sentinel -> NaN, derived delay features) - no learning involved
  4. Splits 80/20 BY SENDER (reported_id), stratified by label, seed 42
  5. Fits the imputer on TRAIN ONLY and applies it to train and test
  6. Saves datasets, artifacts, reports and plots, then validates the saved files
"""
import argparse
import json
import sys
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer

# --------------------------------------------------------------------------- #
# Configuration (everything that influences results lives here)
# --------------------------------------------------------------------------- #
SEED = 42
TEST_SIZE = 0.20
TARGET = "label"
GROUP_COL = "reported_id"          # sender id: all rows of one sender stay in one split
LEAK_COL = "attack_type"           # fine-grained attack name -> perfectly determines label
FOLD_COL = "fold"                  # dataset author's CV fold assignment (metadata)
DROP_EXACT_DUPLICATES = False      # see report: repeated BSMs are part of DoS behaviour
ABSOLUTE_TIME_COLS = ["bsm1_creation_time", "bsm1_arrival_time",
                      "bsm2_creation_time", "bsm2_arrival_time"]
REQUIRED_COLS = [TARGET, GROUP_COL, LEAK_COL, FOLD_COL] + ABSOLUTE_TIME_COLS + [
    "bsm1_width", "bsm1_length", "bsm2_width", "bsm2_length"]


def log(msg=""):
    print(msg, flush=True)


# --------------------------------------------------------------------------- #
# Phase A - inspection
# --------------------------------------------------------------------------- #
def inspection_report(df, path_in):
    """Build the text of dataset_inspection_report.txt from the raw dataframe."""
    L = []
    add = L.append
    add("DATASET INSPECTION REPORT")
    add("=" * 70)
    add(f"File: {Path(path_in).name} (CSV)   Rows: {len(df)}   Columns: {df.shape[1]}")
    add("")
    add("COLUMNS / DTYPES / MISSING / UNIQUE")
    add(f"{'column':24s}{'dtype':10s}{'missing':>8s}{'miss%':>8s}{'unique':>8s}{'min':>14s}{'max':>14s}")
    for c in df.columns:
        s = df[c]
        num = pd.api.types.is_numeric_dtype(s)
        add(f"{c:24s}{str(s.dtype):10s}{s.isna().sum():8d}{100*s.isna().mean():8.2f}{s.nunique():8d}"
            f"{(f'{s.min():.4g}' if num else ''):>14s}{(f'{s.max():.4g}' if num else ''):>14s}")
    add("")
    add("SAMPLE ROWS (first 3, transposed)")
    add(df.head(3).T.to_string())
    add("")
    dup = df.duplicated()
    feat_cols = [c for c in df.columns if c.startswith("bsm")]
    add("DUPLICATES")
    add(f"Exact duplicate rows (all columns): {dup.sum()} ({100*dup.mean():.2f}%)")
    add(f"  by label: {df[dup][TARGET].value_counts().to_dict()}")
    add(f"  by attack_type (top 5): {df[dup][LEAK_COL].value_counts().head(5).to_dict()}")
    add(f"Duplicate rows on bsm* features only: {df[feat_cols].duplicated().sum()}")
    add("")
    add("CONSTANT / NEAR-CONSTANT NUMERIC COLUMNS (top value share > 95%)")
    const = [c for c in df.columns if df[c].nunique() <= 1]
    add(f"Constant columns: {const if const else 'none'}")
    for c in feat_cols:
        top = df[c].value_counts(normalize=True)
        if top.iloc[0] > 0.95:
            add(f"  {c}: top value {top.index[0]} = {100*top.iloc[0]:.1f}%")
    add("")
    add("INVALID / SUSPICIOUS VALUES")
    add(f"Infinite values: {int(np.isinf(df.select_dtypes('number')).sum().sum())}")
    add(f"bsm1_arrival_time == 0: {(df.bsm1_arrival_time == 0).sum()} rows; "
        f"bsm2_arrival_time == 0: {(df.bsm2_arrival_time == 0).sum()} rows "
        "(arrival earlier than creation -> sentinel, not a real timestamp)")
    p0 = ((df.bsm1_pos_x == 0) & (df.bsm1_pos_y == 0))
    add(f"bsm1 position (0,0): {p0.sum()} rows; of these width==0 & length==0: "
        f"{((df.bsm1_width == 0) & (df.bsm1_length == 0) & p0).sum()} (placeholder BSM)")
    add("Plausibility-check columns use -20 as a floor/sentinel; extreme negative kPACS/kPCS/"
        "kPSCP/kPSCSP values are legitimate inconsistency signals, so they are KEPT (not outliers to remove).")
    add("")
    add("TARGET CANDIDATES")
    add(f"'{TARGET}' values: {df[TARGET].value_counts().to_dict()}")
    add(f"'{LEAK_COL}' has {df[LEAK_COL].nunique()} categories; label vs attack_type crosstab:")
    add(pd.crosstab(df[LEAK_COL], df[TARGET]).to_string())
    add("-> 'label' == 0 iff attack_type == 'Genuine'. attack_type is a perfect proxy of the target (leakage).")
    add("")
    g = df.groupby(GROUP_COL).agg(n=(TARGET, "size"), lab=(TARGET, "nunique"), fold=(FOLD_COL, "nunique"))
    add("IDENTIFIERS / GROUPING")
    add(f"Unique {GROUP_COL}: {g.shape[0]}; rows per sender min/median/max = "
        f"{g.n.min()}/{g.n.median():.0f}/{g.n.max()}")
    add(f"Senders with more than one label: {(g.lab > 1).sum()};  with more than one fold: {(g.fold > 1).sum()}")
    gl = df.groupby(GROUP_COL)[TARGET].first().value_counts().to_dict()
    add(f"Senders per class: {gl}  <-- only {gl.get(0, 0)} genuine senders exist")
    add(f"{GROUP_COL} range: genuine max={df[df[TARGET]==0][GROUP_COL].max()}, "
        f"attack max={df[df[TARGET]==1][GROUP_COL].max()} (very large ids are fabricated Sybil ids -> identifier leakage)")
    add("")
    add("FOLD x LABEL (dataset author's folds)")
    add(pd.crosstab(df[FOLD_COL], df[TARGET]).to_string())
    add("")
    add("CLASS DISTRIBUTION")
    vc = df[TARGET].value_counts().sort_index()
    for k, v in vc.items():
        add(f"  label={k}: {v} ({100*v/len(df):.2f}%)")
    add("Task type: BINARY classification (Genuine vs Attack), strongly imbalanced.")
    add("NOTE: label==1 covers ALL attack families; only 4 attack_types are Sybil variants "
        f"({int(df[LEAK_COL].str.contains('Sybil').sum())} rows).")
    add("")
    add("OUTLIER NOTE")
    add("Heavy-tailed values (e.g. kPSCSP down to -1006) occur almost only in attacks; they carry signal and are not removed.")
    return "\n".join(L)


# --------------------------------------------------------------------------- #
# Phase C/D - deterministic (row-wise) cleaning; nothing learned from data
# --------------------------------------------------------------------------- #
def clean_rows(df):
    """Row-wise, non-learned transformations. Safe to apply before the split."""
    out = df.copy()
    # arrival_time == 0 is a sentinel (arrival < creation) -> treat as missing
    for k in ("bsm1", "bsm2"):
        arr, cre = out[f"{k}_arrival_time"], out[f"{k}_creation_time"]
        out[f"{k}_delay"] = np.where(arr > 0, arr - cre, np.nan)   # network delay (s)
    # relative gap between the two BSMs (absolute clocks are dropped later)
    out["dt_creation_1_2"] = out["bsm1_creation_time"] - out["bsm2_creation_time"]
    # width==0 <=> length==0 <=> placeholder BSM; keep one explicit flag, drop the redundant pair
    for k in ("bsm1", "bsm2"):
        out[f"{k}_placeholder"] = ((out[f"{k}_width"] == 0) & (out[f"{k}_length"] == 0)).astype(int)
    if DROP_EXACT_DUPLICATES:
        out = out.drop_duplicates()
    return out


def stratified_group_split(groups_df, test_size, seed):
    """
    Assign whole senders to train/test. Per class, shuffle senders (seed) and move
    senders to test while it brings the test row count closer to test_size * class rows.
    """
    rng = np.random.RandomState(seed)
    test_ids = []
    for cls, sub in groups_df.groupby(TARGET):
        sub = sub.sample(frac=1.0, random_state=rng).reset_index(drop=True)
        target_rows, acc = test_size * sub.n.sum(), 0
        for _, r in sub.iterrows():
            if abs(acc + r.n - target_rows) < abs(acc - target_rows):
                test_ids.append(r[GROUP_COL])
                acc += r.n
    return set(test_ids)


def main():
    here = Path(__file__).resolve().parent
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default=str(here / "two_bsm_clean.csv"))
    ap.add_argument("--output-dir", default=str(here))
    a = ap.parse_args()
    out = Path(a.output_dir)
    (out / "plots").mkdir(parents=True, exist_ok=True)

    # ---- load & validate ---------------------------------------------------
    try:
        df = pd.read_csv(a.input)
    except FileNotFoundError:
        sys.exit(f"ERROR: input file not found: {a.input}. Place two_bsm_clean.csv next to the script or use --input.")
    except Exception as e:
        sys.exit(f"ERROR: could not read {a.input}: {e}")
    missing = [c for c in REQUIRED_COLS if c not in df.columns]
    if missing:
        sys.exit(f"ERROR: expected columns missing from dataset: {missing}")
    if set(df[TARGET].unique()) != {0, 1}:
        sys.exit(f"ERROR: target '{TARGET}' is not binary 0/1: {df[TARGET].unique()}")
    if not ((df[TARGET] == 0) == (df[LEAK_COL] == "Genuine")).all():
        sys.exit("ERROR: label 0 does not coincide with attack_type == 'Genuine'; target meaning unverified.")
    log(f"Loaded {df.shape[0]} rows x {df.shape[1]} columns from {a.input}")

    # ---- Phase A -----------------------------------------------------------
    (out / "dataset_inspection_report.txt").write_text(inspection_report(df, a.input))
    log("Wrote dataset_inspection_report.txt")
    n_dup = int(df.duplicated().sum())

    # ---- Phase B/C: row-wise cleaning -------------------------------------
    work = clean_rows(df)
    work["row_id"] = df.index.values if not DROP_EXACT_DUPLICATES else work.index.values

    # ---- feature set --------------------------------------------------------
    exclusion = {
        GROUP_COL: "Sender identifier. Used only to build group-wise split; Sybil ids are fabricated (very large), "
                   "so the value itself leaks the class and would not generalise.",
        LEAK_COL: "Fine-grained attack name; label==0 iff 'Genuine'. Direct target leakage (kept only in metadata files).",
        FOLD_COL: "Dataset author's cross-validation fold id; experimental metadata, not a message property.",
        TARGET: "Target column.",
        "row_id": "Technical row index (metadata only).",
    }
    for c in ABSOLUTE_TIME_COLS:
        exclusion[c] = ("Absolute simulation clock; no physical meaning and lets a tree memorise time windows of "
                        "specific scenarios. Replaced by relative features (delay, dt_creation_1_2).")
    for k in ("bsm1", "bsm2"):
        exclusion[f"{k}_width"] = "Perfectly collinear with length and with placeholder flag; replaced by single flag."
        exclusion[f"{k}_length"] = "Perfectly collinear with width and with placeholder flag; replaced by single flag."
    non_features = set(exclusion)
    feature_cols = [c for c in work.columns if c not in non_features]
    log(f"Target: {TARGET} | retained features: {len(feature_cols)} | excluded: {len(non_features)}")

    # ---- Phase E: grouped, stratified split BEFORE any fitted step -------
    gdf = work.groupby(GROUP_COL).agg(n=(TARGET, "size"), **{TARGET: (TARGET, "first")}).reset_index()
    if (work.groupby(GROUP_COL)[TARGET].nunique() > 1).any():
        sys.exit("ERROR: a sender has several labels; group split would be invalid.")
    test_ids = stratified_group_split(gdf, TEST_SIZE, SEED)
    is_test = work[GROUP_COL].isin(test_ids)
    tr, te = work[~is_test].copy(), work[is_test].copy()
    log(f"Split by sender: train {len(tr)} rows / test {len(te)} rows "
        f"({100*len(te)/len(work):.2f}% test); senders train/test = "
        f"{tr[GROUP_COL].nunique()}/{te[GROUP_COL].nunique()}")

    # ---- fit preprocessing on TRAIN only ----------------------------------
    imputer = SimpleImputer(strategy="median", add_indicator=True)
    imputer.fit(tr[feature_cols])
    ind_cols = [f"{feature_cols[i]}_was_missing" for i in imputer.indicator_.features_]
    final_cols = feature_cols + ind_cols

    def transform(d):
        arr = imputer.transform(d[feature_cols])
        return pd.DataFrame(arr, columns=final_cols, index=d.index)

    X_train, X_test = transform(tr), transform(te)
    y_train, y_test = tr[TARGET].astype(int), te[TARGET].astype(int)
    for c in ind_cols:
        X_train[c] = X_train[c].astype(int)
        X_test[c] = X_test[c].astype(int)

    # ---- save datasets ------------------------------------------------------
    X_train.to_csv(out / "X_train.csv", index=False)
    X_test.to_csv(out / "X_test.csv", index=False)
    y_train.to_frame().to_csv(out / "y_train.csv", index=False)
    y_test.to_frame().to_csv(out / "y_test.csv", index=False)
    pd.concat([X_train.reset_index(drop=True), y_train.reset_index(drop=True)], axis=1).to_csv(
        out / "train_processed.csv", index=False)
    pd.concat([X_test.reset_index(drop=True), y_test.reset_index(drop=True)], axis=1).to_csv(
        out / "test_processed.csv", index=False)
    # metadata kept OUT of the feature files (needed for grouped CV / per-attack analysis only)
    meta_cols = ["row_id", GROUP_COL, FOLD_COL, LEAK_COL]
    tr[meta_cols].to_csv(out / "train_metadata.csv", index=False)
    te[meta_cols].to_csv(out / "test_metadata.csv", index=False)

    # ---- artifacts ----------------------------------------------------------
    joblib.dump({"imputer": imputer, "input_columns": feature_cols, "output_columns": final_cols},
                out / "preprocessor.joblib")
    (out / "feature_columns.json").write_text(json.dumps(final_cols, indent=2))
    (out / "target_mapping.json").write_text(json.dumps(
        {"target_column": TARGET, "mapping": {"0": "Genuine (legitimate vehicle)",
                                              "1": "Attack (any attack_type != Genuine, incl. Sybil variants)"}}, indent=2))

    # ---- reports ------------------------------------------------------------
    excl = pd.DataFrame([{"column": k, "reason": v} for k, v in exclusion.items()])
    excl.to_csv(out / "feature_exclusion_report.csv", index=False)

    def dist(d, name):
        vc = d[TARGET].value_counts().sort_index()
        return pd.DataFrame({"dataset": name, "label": vc.index, "count": vc.values,
                             "percent": (100 * vc.values / len(d)).round(3)})
    cd = pd.concat([dist(work, "original"), dist(tr, "train"), dist(te, "test")])
    cd.to_csv(out / "class_distribution.csv", index=False)

    n_sent1, n_sent2 = int((df.bsm1_arrival_time == 0).sum()), int((df.bsm2_arrival_time == 0).sum())
    config = {
        "input_file": Path(a.input).name, "seed": SEED, "test_size": TEST_SIZE,
        "split_strategy": "group-wise by reported_id, stratified by label (greedy, deterministic)",
        "target": TARGET, "group_column": GROUP_COL,
        "drop_exact_duplicates": DROP_EXACT_DUPLICATES, "exact_duplicates_found": n_dup,
        "sentinel_rule": "*_arrival_time == 0 -> delay = NaN",
        "derived_features": ["bsm1_delay", "bsm2_delay", "dt_creation_1_2", "bsm1_placeholder", "bsm2_placeholder"],
        "imputer": {"strategy": "median", "add_indicator": True, "fitted_on": "train only"},
        "scaling": "none (not needed for decision trees)", "resampling": "none (natural class distribution kept)",
        "n_features": len(final_cols), "n_train": len(tr), "n_test": len(te),
        "sklearn_input_columns": feature_cols, "final_columns": final_cols,
    }
    (out / "preprocessing_config.json").write_text(json.dumps(config, indent=2))

    rep = [
        "PREPROCESSING REPORT", "=" * 70,
        f"Original: {df.shape[0]} rows x {df.shape[1]} columns.  Final: train {X_train.shape}, test {X_test.shape}.",
        f"Target: '{TARGET}' (0=Genuine, 1=Attack). Verified: label==0 exactly when attack_type=='Genuine'.",
        "Task: binary Genuine-vs-Attack. NOTE: attacks include non-Sybil families; Sybil-only subset is recoverable via "
        "train/test_metadata.csv (attack_type containing 'Sybil').", "",
        "CLEANING DECISIONS",
        "- Missing values: none in raw data. Sentinel arrival_time==0 "
        f"({n_sent1} rows bsm1, {n_sent2} rows bsm2) converted to NaN delay and median-imputed "
        "(median learned from TRAIN only) with missing-indicator columns so the information is preserved.",
        f"- Exact duplicates: {n_dup} rows, all attacks (mostly DoS: repeated identical BSMs from the same sender). "
        "Kept: repeats are characteristic attack behaviour, and sender-wise splitting keeps them in the same split "
        "(no train/test leakage). Switch DROP_EXACT_DUPLICATES in the script to remove them.",
        "- Outliers: not removed or clipped (security data; extreme plausibility values are attack signal).",
        "- No infinite values; no dtype problems; no categorical input features (attack_type is excluded) -> no encoding.",
        "- Constant columns: none. Collinear width/length replaced by one placeholder flag per BSM.",
        "- No scaling, no resampling (class imbalance preserved).", "",
        "SPLIT",
        f"- 80/20, seed {SEED}, whole senders (reported_id) assigned to a side, stratified by label. A random row split "
        "would put messages of the same sender (up to 303 per sender) in train and test and inflate results.",
        f"- Genuine data come from only 8 senders; test contains {te[te[TARGET]==0][GROUP_COL].nunique()} genuine sender(s) "
        f"({int((y_test==0).sum())} rows). Test-set metrics for the genuine class will be very noisy; "
        "use grouped cross-validation on train (groups = train_metadata.csv reported_id) in Part 2.", "",
        "EXCLUDED COLUMNS", excl.to_string(index=False), "",
        "CLASS DISTRIBUTION", cd.to_string(index=False)]
    (out / "preprocessing_report.txt").write_text("\n".join(rep))

    # ---- plots --------------------------------------------------------------
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    cd.pivot(index="dataset", columns="label", values="count").loc[["original", "train", "test"]].plot.bar(ax=ax[0])
    ax[0].set_title("Class counts (0=Genuine, 1=Attack)")
    ax[0].set_ylabel("rows"); ax[0].tick_params(axis="x", rotation=0)
    df[LEAK_COL].value_counts().sort_values().plot.barh(ax=ax[1])
    ax[1].set_title("Rows per attack_type (original)")
    plt.tight_layout(); plt.savefig(out / "plots" / "class_distribution.png", dpi=120); plt.close()
    fig, ax = plt.subplots(figsize=(5, 3.5))
    pd.Series({"bsm1_arrival==0": n_sent1, "bsm2_arrival==0": n_sent2}).plot.bar(ax=ax)
    ax.set_title("Sentinel (invalid arrival time) rows"); ax.tick_params(axis="x", rotation=0)
    plt.tight_layout(); plt.savefig(out / "plots" / "sentinel_arrival_times.png", dpi=120); plt.close()

    # ---- Phase G: validate by re-reading the saved files ------------------
    log("\nVALIDATION (on saved files)")
    Xtr, Xte = pd.read_csv(out / "X_train.csv"), pd.read_csv(out / "X_test.csv")
    ytr, yte = pd.read_csv(out / "y_train.csv"), pd.read_csv(out / "y_test.csv")
    trp, tep = pd.read_csv(out / "train_processed.csv"), pd.read_csv(out / "test_processed.csv")
    pre = joblib.load(out / "preprocessor.joblib")
    mtr, mte = pd.read_csv(out / "train_metadata.csv"), pd.read_csv(out / "test_metadata.csv")
    checks = {
        "row counts X/y match": len(Xtr) == len(ytr) and len(Xte) == len(yte),
        "train+test == original rows": len(Xtr) + len(Xte) == len(work),
        "columns identical & ordered": list(Xtr.columns) == list(Xte.columns) == json.loads(
            (out / "feature_columns.json").read_text()),
        "target absent from X": TARGET not in Xtr.columns and TARGET not in Xte.columns,
        "no leak/id columns in X": not (set(exclusion) & set(Xtr.columns)),
        "no NaN in X": not Xtr.isna().any().any() and not Xte.isna().any().any(),
        "no inf in X": not np.isinf(Xtr.values).any() and not np.isinf(Xte.values).any(),
        "all X numeric": all(pd.api.types.is_numeric_dtype(t) for t in Xtr.dtypes),
        "processed == X + y": trp.drop(columns=TARGET).equals(Xtr) and tep.drop(columns=TARGET).equals(Xte)
                              and trp[TARGET].equals(ytr[TARGET]) and tep[TARGET].equals(yte[TARGET]),
        "no sender in both splits": set(mtr[GROUP_COL]).isdisjoint(set(mte[GROUP_COL])),
        "labels in {0,1}, both classes in both splits": set(ytr[TARGET]) == {0, 1} == set(yte[TARGET]),
        "imputer fitted on train only (medians match train)": np.allclose(
            pre["imputer"].statistics_,
            tr[feature_cols].median(skipna=True).values, equal_nan=True),
        "preprocessor reloads & reproduces X_test": np.allclose(
            pre["imputer"].transform(te[feature_cols]), Xte.values),
        "metadata aligned with X": len(mtr) == len(Xtr) and len(mte) == len(Xte),
    }
    for k, v in checks.items():
        log(f"  [{'PASS' if v else 'FAIL'}] {k}")
    if not all(checks.values()):
        sys.exit("VALIDATION FAILED")
    log("\n" + cd.to_string(index=False))
    log("\nPart 1 complete. No model was trained.")


if __name__ == "__main__":
    main()
