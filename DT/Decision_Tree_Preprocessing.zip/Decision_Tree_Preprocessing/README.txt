VANET attack detection - Part 1: preprocessing for a Decision Tree
===================================================================
Install:   pip install -r requirements.txt
Run:       python preprocess_dataset.py
           (reads two_bsm_clean.csv next to the script; options: --input FILE --output-dir DIR)
Python 3.10+ recommended. Rerunning gives byte-identical X/y files (seed 42).

KEY DECISIONS (details in preprocessing_report.txt)
- Target: 'label' (0 = Genuine, 1 = Attack of any type, incl. 4 Sybil variants).
- Split: 80/20 by SENDER (reported_id), stratified by label. Only 8 genuine senders exist, so the
  genuine class in the test set is 3 senders / 28 rows -> noisy. Use grouped CV on train in Part 2.
- Leakage/metadata excluded from X: attack_type, reported_id, fold, absolute timestamps, width/length.
- Added features: bsm1_delay, bsm2_delay, dt_creation_1_2, bsm1_placeholder, bsm2_placeholder.
- arrival_time == 0 is a sentinel -> NaN -> median imputation (fit on train only) + missing indicators.
- Duplicates, outliers kept; no scaling; no resampling.

FILES
X_train.csv / X_test.csv           features (59 columns, same order)
y_train.csv / y_test.csv           target (label)
train_processed.csv / test_processed.csv   features + label
train_metadata.csv / test_metadata.csv     row_id, reported_id (groups for GroupKFold), fold, attack_type.
                                   NOT features - use only for grouped CV or per-attack analysis.
preprocessor.joblib                dict: fitted imputer, input_columns, output_columns
                                   usage: pre=joblib.load(...); pre['imputer'].transform(df_features[pre['input_columns']])
                                   (df_features must contain the derived columns, built as in clean_rows())
feature_columns.json               ordered model input columns
target_mapping.json                label meaning
preprocessing_config.json          settings and decisions
dataset_inspection_report.txt      raw-data findings
preprocessing_report.txt           cleaning decisions, exclusions, class distribution
feature_exclusion_report.csv       excluded columns + reasons
class_distribution.csv             counts/% for original, train, test
plots/                             class distribution, sentinel counts
two_bsm_clean.csv                  original dataset (input)
